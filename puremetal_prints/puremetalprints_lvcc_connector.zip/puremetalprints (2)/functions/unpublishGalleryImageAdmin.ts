import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }
    
    const { gallery_image_id } = await req.json();
    
    if (!gallery_image_id) {
      return Response.json({ error: 'gallery_image_id is required' }, { status: 400 });
    }
    
    // Update gallery image
    const galleryImage = await base44.asServiceRole.entities.GalleryImage.update(gallery_image_id, {
      is_active: false
    });
    
    // Note: acceptance remains final if it was already published once
    
    return Response.json({
      success: true,
      gallery_image: galleryImage
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});