// functions/onStripeWebhookTest.ts
import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";
import Stripe from "npm:stripe@17.6.0";

const STRIPE_SECRET_KEY =
  Deno.env.get("STRIPE_SECRET_KEY_TEST") ||
  Deno.env.get("STRIPE_API_KEY_TEST") ||
  Deno.env.get("STRIPE_SECRET_KEY") ||
  Deno.env.get("STRIPE_API_KEY") ||
  "";

const WEBHOOK_SECRET =
  Deno.env.get("STRIPE_WEBHOOK_SECRET_TEST") ||
  Deno.env.get("STRIPE_WEBHOOK_SECRET") ||
  "";

const stripe = new Stripe(STRIPE_SECRET_KEY);

function json(status: number, body: unknown) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });
}

function errMsg(err: unknown): string {
  if (err instanceof Error) return err.message;
  try {
    return JSON.stringify(err);
  } catch {
    return String(err);
  }
}

Deno.serve(async (req: Request) => {
  if (req.method !== "POST") return json(405, { error: "Method not allowed" });

  if (!STRIPE_SECRET_KEY) {
    return json(500, { error: "Missing STRIPE_SECRET_KEY_TEST (or fallback STRIPE_SECRET_KEY)" });
  }
  if (!WEBHOOK_SECRET) {
    return json(500, { error: "Missing STRIPE_WEBHOOK_SECRET_TEST (or fallback STRIPE_WEBHOOK_SECRET)" });
  }

  const signature = req.headers.get("stripe-signature");
  if (!signature) return json(400, { error: "Missing stripe-signature header" });

  const rawBody = await req.text();

  let event: Stripe.Event;
  try {
    event = await stripe.webhooks.constructEventAsync(rawBody, signature, WEBHOOK_SECRET);
  } catch (err: unknown) {
    console.error("Stripe signature verification failed:", errMsg(err));
    return json(400, { error: "Invalid Stripe signature" });
  }

  // Base44 provides service role automatically in hosted functions
  const base44 = createClientFromRequest(req);

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;

        const orderId = session.metadata?.order_id;
        if (!orderId) return json(400, { error: "Missing order_id metadata" });

        if (session.payment_status !== "paid") return json(200, { received: true });

        await base44.asServiceRole.entities.Order.update(orderId, {
          status: "NEEDS_REVIEW",
          stripe_payment_intent: typeof session.payment_intent === "string" ? session.payment_intent : null,
          total: session.amount_total != null ? session.amount_total / 100 : 0,
          shipping: session.total_details?.amount_shipping != null ? session.total_details.amount_shipping / 100 : 0,
          tax: session.total_details?.amount_tax != null ? session.total_details.amount_tax / 100 : 0,
          shipping_address: session.shipping_details?.address
            ? {
                line1: session.shipping_details.address.line1 || "",
                line2: session.shipping_details.address.line2 || "",
                city: session.shipping_details.address.city || "",
                state: session.shipping_details.address.state || "",
                zip: session.shipping_details.address.postal_code || "",
                country: session.shipping_details.address.country || "US",
              }
            : null,
        });

        return json(200, { received: true });
      }

      default:
        return json(200, { received: true });
    }
  } catch (err: unknown) {
    console.error("Webhook handler error:", errMsg(err));
    return json(500, { error: errMsg(err) });
  }
});