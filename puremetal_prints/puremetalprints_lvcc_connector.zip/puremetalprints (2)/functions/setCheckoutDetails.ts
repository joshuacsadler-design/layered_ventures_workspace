// functions/setCheckoutDetails.ts
import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";

function json(status: number, body: unknown) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });
}

function nonEmpty(s: unknown): string | null {
  if (typeof s !== "string") return null;
  const t = s.trim();
  return t.length > 0 ? t : null;
}

function validateShippingAddress(addr: any) {
  const missing: string[] = [];
  if (!nonEmpty(addr?.line1)) missing.push("shipping_address.line1");
  if (!nonEmpty(addr?.city)) missing.push("shipping_address.city");
  if (!nonEmpty(addr?.state)) missing.push("shipping_address.state");
  if (!nonEmpty(addr?.zip)) missing.push("shipping_address.zip");
  if (!nonEmpty(addr?.country)) missing.push("shipping_address.country");
  return missing;
}

function makeOrderNumber(orderId: string) {
  // Stable, readable fallback without needing global sequences
  // Example: PM-20260222-1B5F
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  const tail = (orderId || "").slice(-4).toUpperCase() || "XXXX";
  return `PM-${y}${m}${day}-${tail}`;
}

Deno.serve(async (req: Request) => {
  try {
    if (req.method !== "POST") return json(405, { error: "Method not allowed" });

    const base44 = createClientFromRequest(req);

    const user = await base44.auth.me().catch(() => null);
    if (!user) return json(401, { error: "Unauthorized" });

    const body = await req.json().catch(() => ({} as any));
    const orderId = body?.orderId;
    if (!orderId) return json(400, { error: "orderId required" });

    const clientIn = body?.client || {};
    const shipping_address = body?.shipping_address || {};

    const missingAddr = validateShippingAddress(shipping_address);
    const full_name = nonEmpty(clientIn?.full_name);
    const email = nonEmpty(clientIn?.email);
    const phone = nonEmpty(clientIn?.phone);

    const missing: string[] = [];
    if (!full_name) missing.push("client.full_name");
    if (!email) missing.push("client.email");
    missing.push(...missingAddr);

    if (missing.length > 0) {
      return json(400, {
        error: "Missing required checkout fields",
        missing,
      });
    }

    const order = await base44.entities.Order.get(orderId).catch(() => null);
    if (!order) return json(404, { error: "Order not found" });

    const isAdmin = (user as any)?.role === "admin";
    if (!isAdmin && order.user_id !== user.id) return json(403, { error: "Forbidden" });

    // --- Upsert Client ---
    const svc = base44.asServiceRole;

    let client: any = null;

    // Prefer linking by user_id if Client supports it
    const byUser = await svc.entities.Client.filter({ user_id: user.id }).catch(() => []);
    if (byUser?.length) client = byUser[0];

    // Fallback: try by email if the schema supports it
    if (!client) {
      const byEmail = await svc.entities.Client.filter({ email }).catch(() => []);
      if (byEmail?.length) client = byEmail[0];
    }

    if (client) {
      client = await svc.entities.Client.update(client.id, {
        full_name,
        email,
        ...(phone ? { phone } : {}),
        shipping_address,
      }).catch(() => client);
    } else {
      client = await svc.entities.Client.create({
        user_id: user.id,
        full_name,
        email,
        ...(phone ? { phone } : {}),
        shipping_address,
      });
    }

    const patch: any = {
      client_id: client?.id || null,
      shipping_address,
    };

    // Generate order_number if missing
    if (!order.order_number) {
      patch.order_number = makeOrderNumber(orderId);
    }

    await svc.entities.Order.update(orderId, patch);

    return json(200, {
      ok: true,
      order_id: orderId,
      client_id: client?.id || null,
      order_number: patch.order_number || order.order_number || null,
    });
  } catch (err: any) {
    console.error("setCheckoutDetails error:", err?.message || err);
    return json(500, { error: "Internal Server Error", message: String(err?.message || err) });
  }
});