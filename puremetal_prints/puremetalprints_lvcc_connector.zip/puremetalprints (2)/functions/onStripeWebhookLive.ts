// functions/onStripeWebhookLive.ts
import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";
import Stripe from "npm:stripe@17.6.0";

const STRIPE_SECRET_KEY =
  Deno.env.get("STRIPE_SECRET_KEY_LIVE") ||
  Deno.env.get("STRIPE_API_KEY_LIVE") ||
  Deno.env.get("STRIPE_SECRET_KEY") ||
  Deno.env.get("STRIPE_API_KEY") ||
  "";

const WEBHOOK_SECRET =
  Deno.env.get("STRIPE_WEBHOOK_SECRET_LIVE") ||
  Deno.env.get("STRIPE_WEBHOOK_SECRET") ||
  "";

const stripe = new Stripe(STRIPE_SECRET_KEY);

function json(status: number, body: unknown) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });
}

function errMsg(err: unknown): string {
  if (err instanceof Error) return err.message;
  try {
    return JSON.stringify(err);
  } catch {
    return String(err);
  }
}

function nonEmpty(s: any): string | null {
  if (typeof s !== "string") return null;
  const t = s.trim();
  return t.length ? t : null;
}

function makeOrderNumber(orderId: string) {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  const tail = (orderId || "").slice(-4).toUpperCase() || "XXXX";
  return `PM-${y}${m}${day}-${tail}`;
}

Deno.serve(async (req: Request) => {
  if (req.method !== "POST") return json(405, { error: "Method not allowed" });

  if (!STRIPE_SECRET_KEY) {
    return json(500, { error: "Missing STRIPE_SECRET_KEY_LIVE (or fallback STRIPE_SECRET_KEY)" });
  }
  if (!WEBHOOK_SECRET) {
    return json(500, { error: "Missing STRIPE_WEBHOOK_SECRET_LIVE (or fallback STRIPE_WEBHOOK_SECRET)" });
  }

  const signature = req.headers.get("stripe-signature");
  if (!signature) return json(400, { error: "Missing stripe-signature header" });

  const rawBody = await req.text();

  let event: Stripe.Event;
  try {
    event = await stripe.webhooks.constructEventAsync(rawBody, signature, WEBHOOK_SECRET);
  } catch (err: unknown) {
    console.error("Stripe signature verification failed:", errMsg(err));
    return json(400, { error: "Invalid Stripe signature" });
  }

  const base44 = createClientFromRequest(req);

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;

        const orderId = session.metadata?.order_id;
        if (!orderId) return json(400, { error: "Missing order_id metadata" });

        // Only finalize if paid
        if (session.payment_status !== "paid") return json(200, { received: true });

        const svc = base44.asServiceRole;
        const order = await svc.entities.Order.get(orderId).catch(() => null);
        if (!order) return json(404, { error: "Order not found" });

        // Totals from Stripe (authoritative)
        const total = session.amount_total != null ? session.amount_total / 100 : (order.total || 0);
        const shipping = session.total_details?.amount_shipping != null ? session.total_details.amount_shipping / 100 : (order.shipping || 0);
        const tax = session.total_details?.amount_tax != null ? session.total_details.amount_tax / 100 : (order.tax || 0);
        const subtotal =
          (session as any).amount_subtotal != null
            ? Number((session as any).amount_subtotal) / 100
            : Math.max(0, Number(total || 0) - Number(shipping || 0) - Number(tax || 0));

        const stripeAddress = session.shipping_details?.address
          ? {
              line1: session.shipping_details.address.line1 || "",
              line2: session.shipping_details.address.line2 || "",
              city: session.shipping_details.address.city || "",
              state: session.shipping_details.address.state || "",
              zip: session.shipping_details.address.postal_code || "",
              country: session.shipping_details.address.country || "US",
            }
          : null;

        // Upsert/Link client from Stripe customer details if needed
        let clientId = order.client_id || null;
        const cust = session.customer_details;
        const custName = nonEmpty(cust?.name);
        const custEmail = nonEmpty(cust?.email);
        const custPhone = nonEmpty(cust?.phone);

        if (!clientId && (custName || custEmail)) {
          let client: any = null;

          if (order.user_id) {
            const byUser = await svc.entities.Client.filter({ user_id: order.user_id }).catch(() => []);
            if (byUser?.length) client = byUser[0];
          }

          if (!client && custEmail) {
            const byEmail = await svc.entities.Client.filter({ email: custEmail }).catch(() => []);
            if (byEmail?.length) client = byEmail[0];
          }

          if (client) {
            client = await svc.entities.Client.update(client.id, {
              ...(custName ? { full_name: custName } : {}),
              ...(custEmail ? { email: custEmail } : {}),
              ...(custPhone ? { phone: custPhone } : {}),
              ...(stripeAddress ? { shipping_address: stripeAddress } : {}),
            }).catch(() => client);
          } else {
            client = await svc.entities.Client.create({
              ...(order.user_id ? { user_id: order.user_id } : {}),
              ...(custName ? { full_name: custName } : {}),
              ...(custEmail ? { email: custEmail } : {}),
              ...(custPhone ? { phone: custPhone } : {}),
              ...(stripeAddress ? { shipping_address: stripeAddress } : {}),
            });
          }

          clientId = client?.id || null;
        }

        const patch: any = {
          status: "NEEDS_REVIEW",
          stripe_payment_intent: typeof session.payment_intent === "string" ? session.payment_intent : null,
          total,
          shipping,
          tax,
          subtotal,
        };

        if (stripeAddress && !order.shipping_address) patch.shipping_address = stripeAddress;
        if (clientId && !order.client_id) patch.client_id = clientId;
        if (!order.order_number) patch.order_number = makeOrderNumber(orderId);

        await svc.entities.Order.update(orderId, patch);

        return json(200, { received: true });
      }

      default:
        return json(200, { received: true });
    }
  } catch (err: unknown) {
    console.error("Webhook handler error:", errMsg(err));
    return json(500, { error: errMsg(err) });
  }
});