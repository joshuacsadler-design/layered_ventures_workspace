// functions/addToCart.ts
import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";

const MARKER = "ADD_TO_CART_AUTH_REQUIRED_MULTI_KIND_v1";

const CORS_HEADERS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Max-Age": "86400",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      ...CORS_HEADERS,
      "Content-Type": "application/json; charset=utf-8",
    },
  });
}

function pick(body: any, snake: string, camel?: string) {
  if (!body) return undefined;
  if (body[snake] !== undefined) return body[snake];
  if (camel && body[camel] !== undefined) return body[camel];
  return undefined;
}

function asNonEmptyString(x: any): string | null {
  if (x === null || x === undefined) return null;
  const s = String(x).trim();
  return s.length ? s : null;
}

function asInt(x: any, fallback: number) {
  const n = parseInt(String(x ?? ""), 10);
  return Number.isFinite(n) ? n : fallback;
}

function safeStr(x: any): string {
  return x == null ? "" : String(x);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS_HEADERS });
  if (req.method === "GET") return json({ ok: true, marker: MARKER }, 200);
  if (req.method !== "POST") return json({ ok: false, marker: MARKER, error: "Method not allowed" }, 405);

  try {
    const base44 = createClientFromRequest(req);
    const svc = base44.asServiceRole;

    // ✅ HARD REQUIRE AUTH — no anonymous draft orders
    const user = await base44.auth.me().catch(() => null);
    if (!user?.id) {
      return json(
        {
          ok: false,
          marker: MARKER,
          error: "Authentication required to add items to cart.",
          error_code: "AUTH_REQUIRED",
        },
        401,
      );
    }

    const body = await req.json().catch(() => ({} as any));

    const kindRaw = pick(body, "kind", "kind");
    const kind = asNonEmptyString(kindRaw) || "print";

    // Quantity
    const qtyRaw = pick(body, "quantity", "quantity");
    const qty = Math.max(1, asInt(qtyRaw, 1));

    // ✅ Find or create ONE draft order for this user
    let order: any = null;
    const draftOrders = await svc.entities.Order.filter({ user_id: user.id, status: "DRAFT" }).catch(() => []);
    if (draftOrders?.length) {
      order = draftOrders
        .slice()
        .sort((a: any, b: any) => safeStr(b.created_date).localeCompare(safeStr(a.created_date)))[0];
    } else {
      order = await svc.entities.Order.create({
        user_id: user.id,
        status: "DRAFT",
      });
    }

    // ---------- KIND: PRODUCT ----------
    // Used by Shop.jsx for non-print products using ProductPrice records.
    if (kind === "product") {
      const product_id = asNonEmptyString(pick(body, "product_id", "productId"));
      const product_price_id = asNonEmptyString(pick(body, "product_price_id", "productPriceId"));

      if (!product_id) {
        return json(
          { ok: false, marker: MARKER, error: "Missing product_id", debug: { received_keys: Object.keys(body || {}) } },
          400,
        );
      }
      if (!product_price_id) {
        return json(
          {
            ok: false,
            marker: MARKER,
            error: "Missing product_price_id",
            debug: { received_keys: Object.keys(body || {}) },
          },
          400,
        );
      }

      const product = await svc.entities.Product.get(String(product_id)).catch(() => null);
      if (!product) return json({ ok: false, marker: MARKER, error: "Invalid product" }, 400);

      const price = await svc.entities.ProductPrice.get(String(product_price_id)).catch(() => null);
      if (!price) return json({ ok: false, marker: MARKER, error: "Invalid product price" }, 400);

      if (price.product_id !== product.id) {
        return json(
          {
            ok: false,
            marker: MARKER,
            error: "ProductPrice does not belong to product",
            debug: { product_id: product.id, product_price_id: price.id, price_product_id: price.product_id },
          },
          400,
        );
      }

      // Enforce purchasable (if field exists)
      if (price.purchasable === false) {
        return json({ ok: false, marker: MARKER, error: "This option is not purchasable" }, 400);
      }

      const unit_price_cents = Number(price.price_cents || 0);
      if (!Number.isFinite(unit_price_cents) || unit_price_cents <= 0) {
        return json(
          {
            ok: false,
            marker: MARKER,
            error: "Invalid pricing configuration (product price missing/zero).",
            debug: { product_price_id: price.id, price_cents: price.price_cents ?? null },
          },
          400,
        );
      }

      const line_total_cents = unit_price_cents * qty;

      const title = product.name || product.sku || "Product";
      const sku = price.sku || product.sku || null;
      const label = price.label || price.name || null;

      const item = await svc.entities.OrderItem.create({
        order_id: order.id,
        kind: "product",

        product_id: product.id,
        product_price_id: price.id,

        sku,
        title: label ? `${title} — ${label}` : title,

        quantity: qty,

        unit_price_cents,
        line_total_cents,

        // legacy float fields if any UI expects them
        unit_price: unit_price_cents / 100,
        line_total: line_total_cents / 100,

        status: "PENDING",
      });

      return json(
        {
          ok: true,
          marker: MARKER,
          order_id: order.id,
          item,
        },
        200,
      );
    }

    // ---------- KIND: PRINT ----------
    if (kind === "print") {
      const product_id = asNonEmptyString(pick(body, "product_id", "productId"));
      const size = asNonEmptyString(pick(body, "size", "size"));
      const tier = asNonEmptyString(pick(body, "tier", "tier")) || "standard";
      const mount_key = asNonEmptyString(pick(body, "mount_key", "mountKey"));

      if (!product_id) {
        return json(
          { ok: false, marker: MARKER, error: "Missing product_id", debug: { received_keys: Object.keys(body || {}) } },
          400,
        );
      }

      const product = await svc.entities.Product.get(String(product_id)).catch(() => null);
      if (!product) return json({ ok: false, marker: MARKER, error: "Invalid product" }, 400);

      // Resolve PrintVariant (try by size first, then fallback)
      let chosenVariant: any = null;

      if (size) {
        const variantsBySize = await svc.entities.PrintVariant.filter({
          product_id: product.id,
          size: String(size),
        }).catch(() => []);
        if (variantsBySize?.length) chosenVariant = variantsBySize[0];
      }

      if (!chosenVariant) {
        const variantsAny = await svc.entities.PrintVariant.filter({
          product_id: product.id,
        }).catch(() => []);
        if (variantsAny?.length) chosenVariant = variantsAny[0];
      }

      if (!chosenVariant) {
        return json(
          {
            ok: false,
            marker: MARKER,
            error: "No PrintVariant found for product (create PrintVariant records with pricing).",
            debug: { product_id: product.id, size: size || null },
          },
          400,
        );
      }

      const unit_price_cents =
        tier === "reserve"
          ? Number(chosenVariant.reserve_price_cents)
          : Number(chosenVariant.standard_price_cents);

      if (!Number.isFinite(unit_price_cents) || unit_price_cents <= 0) {
        return json(
          {
            ok: false,
            marker: MARKER,
            error: "Invalid pricing configuration (variant price missing/zero).",
            debug: {
              tier,
              variant_id: chosenVariant.id,
              standard_price_cents: chosenVariant.standard_price_cents ?? null,
              reserve_price_cents: chosenVariant.reserve_price_cents ?? null,
            },
          },
          400,
        );
      }

      const line_total_cents = unit_price_cents * qty;

      const item = await svc.entities.OrderItem.create({
        order_id: order.id,
        kind: "print",

        product_id: product.id,
        print_variant_id: chosenVariant.id,

        sku: product.sku,
        title: product.name,

        quantity: qty,
        ...(size ? { size } : {}),
        tier,
        ...(mount_key ? { mount_key } : {}),

        unit_price_cents,
        line_total_cents,

        unit_price: unit_price_cents / 100,
        line_total: line_total_cents / 100,

        gallery_image_id: pick(body, "gallery_image_id", "galleryImageId") ?? null,
        gallery_pricing_applied: !!pick(body, "gallery_pricing_applied", "galleryPricingApplied"),

        status: "PENDING",
      });

      return json(
        {
          ok: true,
          marker: MARKER,
          order_id: order.id,
          item,
          resolved_variant: { id: chosenVariant.id, size: chosenVariant.size || null },
        },
        200,
      );
    }

    // Unknown kind
    return json(
      {
        ok: false,
        marker: MARKER,
        error: "Invalid kind",
        debug: { kind, received_keys: Object.keys(body || {}) },
      },
      400,
    );
  } catch (error: any) {
    console.error("addToCart error:", error?.message || error);
    return json(
      {
        ok: false,
        marker: MARKER,
        error: error?.message ? String(error.message) : String(error),
      },
      500,
    );
  }
});