Deno.serve(() =>
  Response.json(
    { error: "Deprecated endpoint. Use /onStripeWebhookTest or /onStripeWebhookLive" },
    { status: 403 }
  )
);