// functions/_lvcc.ts
// LVCC connector helpers for PureMetal Prints.
//
// NOTE: LVCC is a separate app (Layered Ventures Command Center). This repo is a lower-level business.
// This module only handles outbound mirroring (snapshots/events) and optional inbound execution hooks.

import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";

export type LvccConfig = {
  enabled: boolean;
  baseUrl: string;
  apiKey: string;
  orgId: string;
  businessId: string;
};

function asString(v: unknown): string {
  if (typeof v === "string") return v;
  if (v == null) return "";
  return String(v);
}

function normalizeBaseUrl(url: string): string {
  return url.trim().replace(/\/+$/, "");
}

export async function getLvccConfigFromSiteContent(req: Request): Promise<LvccConfig> {
  const base44 = createClientFromRequest(req);
  const rows = await base44.asServiceRole.entities.SiteContent.list().catch(() => [] as any[]);

  const map: Record<string, string> = {};
  for (const r of rows || []) {
    if (r?.key) map[String(r.key)] = asString(r.value);
  }

  const enabled = asString(map.lvcc_enabled).toLowerCase() === "true";
  const baseUrl = normalizeBaseUrl(asString(map.lvcc_base_url));
  const apiKey = asString(map.lvcc_api_key).trim();
  const orgId = asString(map.lvcc_org_id).trim();
  const businessId = asString(map.lvcc_business_id).trim();

  return { enabled, baseUrl, apiKey, orgId, businessId };
}

export function assertLvccConfig(cfg: LvccConfig) {
  if (!cfg.enabled) throw new Error("LVCC mirroring is disabled (lvcc_enabled=false)");
  if (!cfg.baseUrl) throw new Error("Missing LVCC base URL (lvcc_base_url)");
  if (!cfg.apiKey) throw new Error("Missing LVCC API key (lvcc_api_key)");
  if (!cfg.orgId) throw new Error("Missing LVCC org id (lvcc_org_id)");
  if (!cfg.businessId) throw new Error("Missing LVCC business id (lvcc_business_id)");
}

export async function postLvccJson(
  cfg: LvccConfig,
  path: string,
  body: unknown,
): Promise<{ status: number; data: any; rawText: string }>{
  const url = `${cfg.baseUrl}${path.startsWith("/") ? "" : "/"}${path}`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-lvcc-api-key": cfg.apiKey,
      "x-lvcc-org-id": cfg.orgId,
      "x-lvcc-business-id": cfg.businessId,
    },
    body: JSON.stringify(body),
  });

  const rawText = await res.text().catch(() => "");
  let data: any = null;
  try {
    data = rawText ? JSON.parse(rawText) : null;
  } catch {
    data = { raw: rawText };
  }

  return { status: res.status, data, rawText };
}
