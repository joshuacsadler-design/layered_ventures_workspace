import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { product_id, size, tier, quantity } = body || {};

    if (!product_id || !size || !tier) {
      return Response.json({ error: "product_id, size, tier required" }, { status: 400 });
    }

    const qty = Math.max(1, Number(quantity || 1));

    const variants = await base44.asServiceRole.entities.PrintVariant.filter({ product_id, size });
    const variant = variants[0];

    if (!variant || !variant.active) {
      return Response.json({ error: "Size not available" }, { status: 400 });
    }

    // Get standard price in cents
    const stdCents = variant.standard_price_cents ?? (variant.standard_price ? Math.round(variant.standard_price * 100) : 0);
    let unit_price_cents = stdCents;

    if (tier === "reserve") {
      // ENFORCE: Reserve only allowed if reserve_enabled=true AND reserve_price_cents>0
      const resCents = variant.reserve_price_cents ?? (variant.reserve_price ? Math.round(variant.reserve_price * 100) : 0);
      if (!variant.reserve_enabled || !resCents || resCents <= 0) {
        return Response.json({ error: "Reserve not offered for this size." }, { status: 400 });
      }
      unit_price_cents = resCents;
    }

    const line_total_cents = unit_price_cents * qty;

    return Response.json({ 
      unit_price_cents, 
      line_total_cents, 
      quantity: qty 
    });
  } catch (e) {
    return Response.json({ error: e?.message ?? "Unknown error", stack: e?.stack }, { status: 500 });
  }
});