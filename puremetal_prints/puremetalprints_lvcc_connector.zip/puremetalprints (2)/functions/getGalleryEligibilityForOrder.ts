import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    const { order_id } = await req.json();
    
    if (!order_id) {
      return Response.json({ error: 'order_id is required' }, { status: 400 });
    }
    
    // Verify order ownership
    const orders = await base44.entities.Order.filter({ id: order_id, user_id: user.id });
    if (orders.length === 0) {
      return Response.json({ error: 'Order not found or access denied' }, { status: 404 });
    }
    
    // Get order items
    const items = await base44.entities.OrderItem.filter({ order_id });
    
    // Get all acceptances for this order
    const acceptances = await base44.entities.GalleryLicenseAcceptance.filter({ order_id });
    
    // Build eligibility map
    const itemsEligibility = items.map(item => {
      const acceptance = acceptances.find(a => a.order_item_id === item.id);
      const isApproved = ['APPROVED', 'IN_PRODUCTION', 'COMPLETED'].includes(item.status);
      
      return {
        item_id: item.id,
        title: item.title,
        is_approved: isApproved,
        opted_in: !!acceptance,
        is_final: acceptance?.is_final || false,
        can_publish: isApproved && !!acceptance,
        license_version: acceptance?.license_version || null,
        accepted_at: acceptance?.accepted_at || null
      };
    });
    
    return Response.json({
      order_id,
      items: itemsEligibility
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});