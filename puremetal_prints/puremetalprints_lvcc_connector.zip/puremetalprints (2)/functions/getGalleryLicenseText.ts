import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

const DEFAULT_LICENSE_TEXT = `By checking this box, I grant PureMetal Studio permission to display this artwork in their public gallery for promotional purposes. I understand this permission is optional and not required to complete my order.

The studio may:
• Display the finished print in their online gallery
• Use the image in marketing materials and social media
• Share the image to showcase their craftsmanship

I retain all copyright and ownership of the original artwork. This permission can be revoked before the work is published to the gallery, but becomes final once published.`;

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const siteContent = await base44.asServiceRole.entities.SiteContent.filter({ key: 'gallery_license_text' });
    const versionContent = await base44.asServiceRole.entities.SiteContent.filter({ key: 'gallery_license_version' });
    
    const licenseText = siteContent[0]?.value || DEFAULT_LICENSE_TEXT;
    const licenseVersion = versionContent[0]?.value ? parseInt(versionContent[0].value) : 1;
    
    return Response.json({
      gallery_license_text: licenseText,
      gallery_license_version: licenseVersion
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});