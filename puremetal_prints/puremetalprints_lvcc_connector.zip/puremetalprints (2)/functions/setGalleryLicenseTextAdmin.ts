import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }
    
    const { gallery_license_text } = await req.json();
    
    if (!gallery_license_text || !gallery_license_text.trim()) {
      return Response.json({ error: 'License text is required' }, { status: 400 });
    }
    
    // Get current version
    const versionContent = await base44.asServiceRole.entities.SiteContent.filter({ key: 'gallery_license_version' });
    const currentVersion = versionContent[0]?.value ? parseInt(versionContent[0].value) : 0;
    const newVersion = currentVersion + 1;
    
    // Update text
    const textContent = await base44.asServiceRole.entities.SiteContent.filter({ key: 'gallery_license_text' });
    if (textContent[0]) {
      await base44.asServiceRole.entities.SiteContent.update(textContent[0].id, { value: gallery_license_text });
    } else {
      await base44.asServiceRole.entities.SiteContent.create({ key: 'gallery_license_text', value: gallery_license_text });
    }
    
    // Update version
    if (versionContent[0]) {
      await base44.asServiceRole.entities.SiteContent.update(versionContent[0].id, { value: newVersion.toString() });
    } else {
      await base44.asServiceRole.entities.SiteContent.create({ key: 'gallery_license_version', value: newVersion.toString() });
    }
    
    return Response.json({
      gallery_license_text,
      gallery_license_version: newVersion
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});