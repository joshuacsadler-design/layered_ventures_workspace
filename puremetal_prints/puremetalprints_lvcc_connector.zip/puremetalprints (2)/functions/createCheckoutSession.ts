// functions/createCheckoutSession.ts
import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";
import Stripe from "npm:stripe@17.6.0";

const STRIPE_MODE = (Deno.env.get("STRIPE_MODE") || "test").toLowerCase();

function pickStripeSecretKey(): string {
  const testKey =
    Deno.env.get("STRIPE_SECRET_KEY_TEST") ||
    Deno.env.get("STRIPE_API_KEY_TEST") ||
    "";

  const liveKey =
    Deno.env.get("STRIPE_SECRET_KEY_LIVE") ||
    Deno.env.get("STRIPE_API_KEY_LIVE") ||
    "";

  const legacyFallback =
    Deno.env.get("STRIPE_API_KEY") ||
    Deno.env.get("STRIPE_SECRET_KEY") ||
    "";

  if (STRIPE_MODE === "live") return liveKey || legacyFallback;
  return testKey || legacyFallback;
}

const STRIPE_SECRET_KEY = pickStripeSecretKey();
const PUBLIC_SITE_ORIGIN = (Deno.env.get("PUBLIC_SITE_ORIGIN") || "").trim();

if (!STRIPE_SECRET_KEY) {
  console.error("Missing Stripe secret key. Set STRIPE_MODE and provide STRIPE_SECRET_KEY_TEST/STRIPE_SECRET_KEY_LIVE.");
}

const stripe = new Stripe(STRIPE_SECRET_KEY);

function json(status: number, body: unknown) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });
}

function resolvePublicOrigin(req: Request): string {
  if (PUBLIC_SITE_ORIGIN) return PUBLIC_SITE_ORIGIN.replace(/\/+$/, "");
  return new URL(req.url).origin;
}

function nonEmpty(s: any): string | null {
  if (typeof s !== "string") return null;
  const t = s.trim();
  return t.length ? t : null;
}

function validateShippingAddress(addr: any) {
  const missing: string[] = [];
  if (!nonEmpty(addr?.line1)) missing.push("shipping_address.line1");
  if (!nonEmpty(addr?.city)) missing.push("shipping_address.city");
  if (!nonEmpty(addr?.state)) missing.push("shipping_address.state");
  if (!nonEmpty(addr?.zip)) missing.push("shipping_address.zip");
  if (!nonEmpty(addr?.country)) missing.push("shipping_address.country");
  return missing;
}

Deno.serve(async (req: Request) => {
  try {
    if (req.method !== "POST") return json(405, { error: "Method not allowed" });

    const base44 = createClientFromRequest(req);

    const user = await base44.auth.me().catch(() => null);
    if (!user) return json(401, { error: "Unauthorized" });

    const { orderId } = await req.json().catch(() => ({} as any));
    if (!orderId) return json(400, { error: "Order ID required" });

    const order = await base44.entities.Order.get(orderId).catch(() => null);
    if (!order) return json(404, { error: "Order not found" });

    const isAdmin = (user as any)?.role === "admin";
    if (!isAdmin && order.user_id !== user.id) return json(403, { error: "Forbidden" });

    const missing: string[] = [];
    if (!order.client_id) missing.push("client_id");
    const addrMissing = validateShippingAddress(order.shipping_address);
    missing.push(...addrMissing);

    if (missing.length > 0) {
      return json(400, {
        error: "Checkout details incomplete. Please provide contact + shipping info.",
        missing,
      });
    }

    const items = await base44.entities.OrderItem.filter({ order_id: orderId }).catch(() => []);
    if (!items?.length) return json(400, { error: "Order has no items" });

    // Compute subtotal from items (cents authoritative)
    let subtotalCents = 0;
    for (const it of items) {
      const qty = Number(it.quantity || 1);
      const unit = Number(it.unit_price_cents || 0);
      if (!Number.isFinite(qty) || qty <= 0) return json(400, { error: "Invalid quantity in OrderItem" });
      if (!Number.isFinite(unit) || unit <= 0) return json(400, { error: "Invalid unit_price_cents in OrderItem" });
      subtotalCents += qty * unit;
    }

    // Shipping/tax placeholders (you can replace with real calculator later)
    const shippingCents = 0;
    const taxCents = 0;
    const totalCents = Math.max(0, subtotalCents + shippingCents + taxCents);

    // Persist totals BEFORE payment
    await base44.asServiceRole.entities.Order.update(orderId, {
      subtotal: subtotalCents / 100,
      shipping: shippingCents / 100,
      tax: taxCents / 100,
      total: totalCents / 100,
    }).catch((e: any) => {
      console.error("Order totals update failed:", e?.message || e);
      return null;
    });

    const line_items = items.map((it: any) => {
      const qty = Number(it.quantity || 1);
      const unit = Number(it.unit_price_cents || 0);

      const name =
        it.name ||
        it.title ||
        it.sku ||
        (it.kind === "print" ? "Metal Print" : "Item");

      return {
        quantity: qty,
        price_data: {
          currency: "usd",
          unit_amount: unit,
          product_data: { name },
        },
      };
    });

    const publicOrigin = resolvePublicOrigin(req);

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items,

      // Backstop: Stripe also collects shipping address + phone
      shipping_address_collection: { allowed_countries: ["US"] },
      phone_number_collection: { enabled: true },

      // include order_id so CheckoutSuccess can link directly to the order
      success_url: `${publicOrigin}/checkout-success?order_id=${encodeURIComponent(orderId)}&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${publicOrigin}/cart`,
      metadata: {
        order_id: orderId,
        user_id: user.id,
        stripe_mode: STRIPE_MODE,
        public_origin: publicOrigin,
      },
    });

    await base44.asServiceRole.entities.Order.update(orderId, {
      stripe_session_id: session.id,
    }).catch((e: any) => {
      console.error("Order stripe_session_id update failed:", e?.message || e);
      return null;
    });

    return json(200, { url: session.url });
  } catch (err: any) {
    console.error("createCheckoutSession error:", err?.message || err);
    return json(500, { error: "Internal Server Error" });
  }
});
