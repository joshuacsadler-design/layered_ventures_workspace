// functions/adminOrdersBundle.ts
import { createClientFromRequest } from "npm:@base44/sdk@0.8.18";

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

Deno.serve(async (req: Request) => {
  try {
    if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

    // Base44-hosted function: auth from request, service role via base44.asServiceRole
    const base44 = createClientFromRequest(req);

    const me = await base44.auth.me().catch(() => null);
    if (!me) return json({ error: "Unauthorized" }, 401);
    if ((me as any).role !== "admin") return json({ error: "Forbidden" }, 403);

    const body = await req.json().catch(() => ({} as any));
    const limitRaw = (body as any)?.limit ?? 200;
    const limit = Math.max(1, Math.min(Number(limitRaw) || 200, 500));

    const [orders, clients, items, proofs, files] = await Promise.all([
      base44.asServiceRole.entities.Order.list("-created_date", limit),
      base44.asServiceRole.entities.Client.list(),
      base44.asServiceRole.entities.OrderItem.list(),
      base44.asServiceRole.entities.Proof.list(),
      base44.asServiceRole.entities.File.list(),
    ]);

    return json({ data: { orders, clients, items, proofs, files } });
  } catch (err) {
    console.error("adminOrdersBundle crashed:", (err as any)?.message || err);
    return json(
      {
        error: "adminOrdersBundle crashed",
        message: String((err as any)?.message || err || "Unknown error"),
      },
      500,
    );
  }
});