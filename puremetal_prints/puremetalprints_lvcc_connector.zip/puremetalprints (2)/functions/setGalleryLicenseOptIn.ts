import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    const { order_id, order_item_id, opt_in, proof_id } = await req.json();
    
    if (!order_id) {
      return Response.json({ error: 'order_id is required' }, { status: 400 });
    }
    
    // Verify order ownership
    const orders = await base44.entities.Order.filter({ id: order_id, user_id: user.id });
    if (orders.length === 0) {
      return Response.json({ error: 'Order not found or access denied' }, { status: 404 });
    }
    
    // Check existing acceptance
    const existingAcceptances = await base44.entities.GalleryLicenseAcceptance.filter({
      order_id,
      ...(order_item_id ? { order_item_id } : {})
    });
    
    const existingAcceptance = existingAcceptances[0];
    
    if (opt_in === false) {
      // User wants to revoke
      if (existingAcceptance?.is_final) {
        return Response.json({ 
          error: 'License is final once published. Cannot revoke permission.' 
        }, { status: 409 });
      }
      
      // Delete acceptance if exists
      if (existingAcceptance) {
        await base44.asServiceRole.entities.GalleryLicenseAcceptance.delete(existingAcceptance.id);
      }
      
      return Response.json({
        opted_in: false,
        license_version: null,
        accepted_at: null,
        is_final: false
      });
    }
    
    // User wants to opt in
    if (existingAcceptance?.is_final) {
      // Already final, return existing
      return Response.json({
        opted_in: true,
        license_version: existingAcceptance.license_version,
        accepted_at: existingAcceptance.accepted_at,
        is_final: true
      });
    }
    
    // Get current license text and version
    const { data: licenseData } = await base44.functions.invoke('getGalleryLicenseText', {});
    const { gallery_license_text, gallery_license_version } = licenseData;
    
    if (existingAcceptance) {
      // Update existing (not final)
      await base44.asServiceRole.entities.GalleryLicenseAcceptance.update(existingAcceptance.id, {
        license_text: gallery_license_text,
        license_version: gallery_license_version,
        accepted_at: new Date().toISOString(),
        proof_id: proof_id || existingAcceptance.proof_id
      });
      
      return Response.json({
        opted_in: true,
        license_version: gallery_license_version,
        accepted_at: new Date().toISOString(),
        is_final: false
      });
    }
    
    // Create new acceptance
    const acceptance = await base44.asServiceRole.entities.GalleryLicenseAcceptance.create({
      order_id,
      order_item_id: order_item_id || null,
      user_id: user.id,
      proof_id: proof_id || null,
      license_text: gallery_license_text,
      license_version: gallery_license_version,
      accepted_at: new Date().toISOString(),
      is_final: false
    });
    
    return Response.json({
      opted_in: true,
      license_version: gallery_license_version,
      accepted_at: acceptance.accepted_at,
      is_final: false
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});