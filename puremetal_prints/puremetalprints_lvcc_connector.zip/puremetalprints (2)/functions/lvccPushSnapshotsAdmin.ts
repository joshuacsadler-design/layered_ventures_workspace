// functions/lvccPushSnapshotsAdmin.ts
// Manual admin-triggered push of operational snapshots to LVCC.

import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";
import { assertLvccConfig, getLvccConfigFromSiteContent, postLvccJson } from "./_lvcc.ts";

function json(status: number, body: unknown) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });
}

function toIsoDay(d: Date): string {
  // YYYY-MM-DD in UTC
  const yyyy = d.getUTCFullYear();
  const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(d.getUTCDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function startOfUtcDay(d: Date): Date {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), 0, 0, 0, 0));
}

function startOfUtcMonth(d: Date): Date {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1, 0, 0, 0, 0));
}

function safeNum(v: any): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

Deno.serve(async (req: Request) => {
  try {
    if (req.method !== "POST") return json(405, { error: "Method not allowed" });

    const base44 = createClientFromRequest(req);

    const user = await base44.auth.me().catch(() => null);
    if (!user || (user as any)?.role !== "admin") return json(403, { error: "Forbidden" });

    const cfg = await getLvccConfigFromSiteContent(req);
    assertLvccConfig(cfg);

    // Gather source data (keep it cheap: last 250 orders + all products)
    const [orders, products] = await Promise.all([
      base44.asServiceRole.entities.Order.list("-created_date", 250).catch(() => [] as any[]),
      base44.asServiceRole.entities.Product.list().catch(() => [] as any[]),
    ]);

    const now = new Date();
    const todayStart = startOfUtcDay(now);
    const sevenDaysStart = new Date(todayStart.getTime() - 7 * 24 * 60 * 60 * 1000);
    const monthStart = startOfUtcMonth(now);

    const paidLikeStatus = new Set([
      "NEEDS_REVIEW",
      "APPROVED",
      "PROOF_DELIVERED",
      "IN_PRODUCTION",
      "COMPLETED",
      "SHIPPED",
    ]);

    const orderStatusCounts: Record<string, number> = {};
    let revenueToday = 0;
    let revenue7d = 0;
    let revenueMtd = 0;

    for (const o of orders || []) {
      const status = String(o?.status || "UNKNOWN");
      orderStatusCounts[status] = (orderStatusCounts[status] || 0) + 1;

      const created = o?.created_date ? new Date(o.created_date) : null;
      if (!created || Number.isNaN(created.getTime())) continue;

      // Treat as revenue-bearing only if Stripe indicates paid OR it has a paid-like status.
      const isPaid = Boolean(o?.stripe_payment_intent) || paidLikeStatus.has(status);
      if (!isPaid) continue;

      const total = safeNum(o?.total);
      if (created >= todayStart) revenueToday += total;
      if (created >= sevenDaysStart) revenue7d += total;
      if (created >= monthStart) revenueMtd += total;
    }

    const inventory = (products || []).map((p: any) => ({
      id: p?.id,
      sku: p?.sku,
      name: p?.name,
      type: p?.type,
      active: Boolean(p?.active),
      show_in_shop: Boolean(p?.show_in_shop),
      in_stock: Boolean(p?.in_stock),
      stock_mode: p?.stock_mode || null,
      updated_date: p?.updated_date || null,
    }));

    const payload = {
      schema_version: "1.0",
      source_system: "puremetal_prints",
      org_id: cfg.orgId,
      business_id: cfg.businessId,
      generated_at: new Date().toISOString(),
      window: {
        today_utc: toIsoDay(now),
      },
      snapshots: {
        revenue: {
          currency: "USD",
          today: Number(revenueToday.toFixed(2)),
          last_7d: Number(revenue7d.toFixed(2)),
          mtd: Number(revenueMtd.toFixed(2)),
        },
        orders: {
          total_seen: (orders || []).length,
          status_counts: orderStatusCounts,
        },
        inventory: {
          total_products: inventory.length,
          items: inventory,
        },
      },
    };

    const res = await postLvccJson(cfg, "/ingest/snapshots", payload);

    if (res.status < 200 || res.status >= 300) {
      return json(502, {
        error: "LVCC responded with non-2xx",
        lvcc_status: res.status,
        lvcc_body: res.data,
      });
    }

    return json(200, {
      status: "ok",
      lvcc_status: res.status,
      lvcc_body: res.data,
      sent: {
        revenue: payload.snapshots.revenue,
        orders_total_seen: payload.snapshots.orders.total_seen,
        inventory_total_products: payload.snapshots.inventory.total_products,
      },
    });
  } catch (err: any) {
    console.error("lvccPushSnapshotsAdmin error:", err?.message || err);
    return json(500, { error: err?.message || "Internal Server Error" });
  }
});
