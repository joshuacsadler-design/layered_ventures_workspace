import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }
    
    const { 
      order_item_id, 
      proof_id, 
      title, 
      file_id,
      configured_size,
      configured_tier,
      configured_mount_key,
      gallery_discount_pct 
    } = await req.json();
    
    if (!order_item_id && !proof_id) {
      return Response.json({ error: 'order_item_id or proof_id required' }, { status: 400 });
    }
    
    // Find acceptance
    const acceptances = await base44.asServiceRole.entities.GalleryLicenseAcceptance.filter({
      ...(order_item_id ? { order_item_id } : {}),
      ...(proof_id && !order_item_id ? { proof_id } : {})
    });
    
    const acceptance = acceptances[0];
    
    if (!acceptance) {
      return Response.json({ 
        error: 'No gallery license acceptance found. Client must grant permission first.' 
      }, { status: 400 });
    }
    
    // Get order item details if needed
    let orderItem = null;
    let actualFileId = file_id;
    let actualTitle = title;
    let actualSize = configured_size;
    let actualTier = configured_tier;
    let actualMount = configured_mount_key;
    
    if (order_item_id) {
      const items = await base44.asServiceRole.entities.OrderItem.filter({ id: order_item_id });
      orderItem = items[0];
      
      if (!orderItem) {
        return Response.json({ error: 'Order item not found' }, { status: 404 });
      }
      
      // Use order item details if not provided
      actualTitle = actualTitle || orderItem.title;
      actualSize = actualSize || orderItem.size;
      actualTier = actualTier || orderItem.tier;
      actualMount = actualMount || orderItem.mount_key;
      
      // Get proof file if not provided
      if (!actualFileId && proof_id) {
        const proofs = await base44.asServiceRole.entities.Proof.filter({ id: proof_id });
        if (proofs[0]) {
          actualFileId = proofs[0].file_id;
        }
      }
    }
    
    if (!actualFileId) {
      return Response.json({ error: 'file_id is required' }, { status: 400 });
    }
    
    // Check if already published
    const existingGalleryImages = await base44.asServiceRole.entities.GalleryImage.filter({
      order_item_id: order_item_id || null
    });
    
    let galleryImage;
    
    if (existingGalleryImages[0]) {
      // Update existing
      galleryImage = await base44.asServiceRole.entities.GalleryImage.update(existingGalleryImages[0].id, {
        title: actualTitle,
        file_id: actualFileId,
        is_active: true,
        licensed: true,
        license_acceptance_id: acceptance.id,
        configured_size: actualSize,
        configured_tier: actualTier,
        configured_mount_key: actualMount,
        gallery_discount_pct: gallery_discount_pct || 15
      });
    } else {
      // Create new
      galleryImage = await base44.asServiceRole.entities.GalleryImage.create({
        title: actualTitle,
        file_id: actualFileId,
        is_active: true,
        licensed: true,
        license_acceptance_id: acceptance.id,
        order_id: acceptance.order_id,
        order_item_id: order_item_id || null,
        proof_id: proof_id || null,
        configured_size: actualSize,
        configured_tier: actualTier,
        configured_mount_key: actualMount,
        gallery_discount_pct: gallery_discount_pct || 15,
        sort_order: 0
      });
    }
    
    // Lock acceptance
    if (!acceptance.is_final) {
      await base44.asServiceRole.entities.GalleryLicenseAcceptance.update(acceptance.id, {
        published_at: new Date().toISOString(),
        is_final: true
      });
    }
    
    return Response.json({
      success: true,
      gallery_image: galleryImage
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});