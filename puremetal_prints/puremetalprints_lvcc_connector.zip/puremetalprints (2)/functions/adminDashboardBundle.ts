// functions/adminDashboardBundle.ts
import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";

function json(status: number, body: unknown) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });
}

Deno.serve(async (req: Request) => {
  try {
    if (req.method !== "POST") return json(405, { error: "Method not allowed" });

    const base44 = createClientFromRequest(req);

    const user = await base44.auth.me().catch(() => null);
    if (!user || (user as any)?.role !== "admin") return json(403, { error: "Forbidden" });

    // Service role queries MUST be server-side (never in browser)
    const [orders, items, proofs, cancellationRequests] = await Promise.all([
      base44.asServiceRole.entities.Order.list("-created_date", 100),
      base44.asServiceRole.entities.OrderItem.list(),
      base44.asServiceRole.entities.Proof.list(),
      base44.asServiceRole.entities.CancellationRequest.filter({ status: "PENDING" }),
    ]);

    return json(200, { orders, items, proofs, cancellationRequests });
  } catch (err: any) {
    console.error("adminDashboardBundle error:", err?.message || err);
    return json(500, { error: "Internal Server Error" });
  }
});