import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Max-Age": "86400",
};

function json(body: any, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json; charset=utf-8" },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS_HEADERS });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return json({ error: "Unauthorized" }, 401);

    const form = await req.formData();
    const file = form.get("file");
    const product_id = String(form.get("product_id") || "");
    const size = String(form.get("size") || "");
    const tier = String(form.get("tier") || "standard");
    const mount_key = String(form.get("mount_key") || "");
    const quantity = Math.max(1, parseInt(String(form.get("quantity") || "1"), 10) || 1);

    if (!file || typeof (file as any).name !== "string") {
      return json({ error: "file required" }, 400);
    }
    if (!product_id) return json({ error: "product_id required" }, 400);
    if (!size) return json({ error: "size required" }, 400);

    const svc = base44.asServiceRole;

    // Find/create draft order for user
    const drafts = await svc.entities.Order.filter({ user_id: user.id, status: "DRAFT" });
    const order =
      drafts && drafts.length > 0
        ? drafts[0]
        : await svc.entities.Order.create({ user_id: user.id, status: "DRAFT" });

    // Resolve print variant (product_id + size first, fallback to any)
    let variant = null as any;

    const bySize = await svc.entities.PrintVariant.filter({ product_id, size });
    if (bySize && bySize.length > 0) variant = bySize[0];

    if (!variant) {
      const any = await svc.entities.PrintVariant.filter({ product_id });
      if (any && any.length > 0) variant = any[0];
    }

    if (!variant) {
      return json({ error: "No PrintVariant found for product/size. Create PrintVariant rows." }, 400);
    }

    const base_price_cents =
      tier === "reserve" ? variant.reserve_price_cents : variant.standard_price_cents;

    if (!Number.isFinite(base_price_cents) || base_price_cents <= 0) {
      return json(
        {
          error: "Invalid pricing configuration on PrintVariant",
          debug: {
            standard_price_cents: variant.standard_price_cents ?? null,
            reserve_price_cents: variant.reserve_price_cents ?? null,
          },
        },
        400
      );
    }

    const unit_price_cents = base_price_cents;
    const line_total_cents = unit_price_cents * quantity;

    // Create order item FIRST (so we can attach file to it)
    const item = await svc.entities.OrderItem.create({
      order_id: order.id,
      kind: "print",
      product_id,
      print_variant_id: variant.id,
      sku: "", // optional
      title: "",
      quantity,
      size,
      tier,
      mount_key,

      unit_price_cents,
      line_total_cents,
      unit_price: unit_price_cents / 100,
      line_total: line_total_cents / 100,

      status: "PENDING",
    });

    // Upload client original file
    const upload = await base44.integrations.Core.UploadFile({ file });
    const originalUrl = upload.file_url;

    await svc.entities.File.create({
      order_item_id: item.id,
      kind: "CLIENT_ORIGINAL",
      file_url: originalUrl,
      filename: (file as any).name,
      source_file_id: null,
      is_delivered_to_client: false,
      metadata: { uploaded_by: user.id },
    });

    return json({ ok: true, order_id: order.id, order_item_id: item.id }, 200);
  } catch (e: any) {
    return json({ error: e?.message || String(e) }, 500);
  }
});
