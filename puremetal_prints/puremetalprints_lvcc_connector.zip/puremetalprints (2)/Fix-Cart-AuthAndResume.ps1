# Fix-Cart-AuthAndResume.ps1
# Run from repo root:  powershell -ExecutionPolicy Bypass -File .\Fix-Cart-AuthAndResume.ps1

$ErrorActionPreference = "Stop"

function Write-FileUtf8NoBom($path, $content) {
  $dir = Split-Path -Parent $path
  if (!(Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
  $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($path, $content, $utf8NoBom)
}

function Patch-File($path, $find, $replace) {
  if (!(Test-Path $path)) { throw "Missing file: $path" }
  $txt = Get-Content $path -Raw
  if ($txt -notmatch [regex]::Escape($find)) {
    throw "Pattern not found in $path. Expected to find:`n$find"
  }
  $txt2 = $txt.Replace($find, $replace)
  Write-FileUtf8NoBom $path $txt2
}

Write-Host "==> 1) Ensure src/lib/pendingCart.js exists (canonical)..." -ForegroundColor Cyan

$pendingCartPath = "src/lib/pendingCart.js"
$pendingCart = @'
import { base44 } from "@/api/base44Client";

const KEY = "pm_pending_cart_add";

export async function requireAuthOrQueueCartAdd(payload, returnUrl = "/cart") {
  // If already authed, proceed immediately
  const authed = await base44.auth.isAuthenticated();
  if (authed) return payload;

  // Queue payload, then redirect to login
  localStorage.setItem(KEY, JSON.stringify({ payload, returnUrl }));
  base44.auth.redirectToLogin(window.location.href);

  // Throw a sentinel error so callers can ignore it
  const err = new Error("AUTH_REDIRECT");
  err.code = "AUTH_REDIRECT";
  throw err;
}

export async function runQueuedCartAddIfAny(invokeFn) {
  const raw = localStorage.getItem(KEY);
  if (!raw) return null;

  try {
    const { payload, returnUrl } = JSON.parse(raw);
    localStorage.removeItem(KEY);
    const result = await invokeFn(payload);
    return { result, returnUrl: returnUrl || "/cart" };
  } catch (e) {
    localStorage.removeItem(KEY);
    throw e;
  }
}
'@
Write-FileUtf8NoBom $pendingCartPath $pendingCart
Write-Host "   Wrote $pendingCartPath" -ForegroundColor Green

Write-Host "==> 2) Patch src/pages/CreatePrint.jsx to queue cart add if not logged in..." -ForegroundColor Cyan
$createPath = "src/pages/CreatePrint.jsx"
$createTxt = Get-Content $createPath -Raw

# Add imports if missing
if ($createTxt -notmatch 'requireAuthOrQueueCartAdd') {
  # Insert two imports right after base44 import
  $createTxt = $createTxt.Replace(
    'import { base44 } from "@/api/base44Client";',
    'import { base44 } from "@/api/base44Client";' + "`n" +
    'import { requireAuthOrQueueCartAdd } from "@/lib/pendingCart";' + "`n" +
    'import { toast } from "@/components/ui/use-toast";'
  )
}

# Replace mutationFn block
$findCreate = @'
  const addToCart = useMutation({
    mutationFn: async () => {
      const resp = await base44.functions.invoke("addToCart", {
        kind: "print",
        product_id: product.id,
        size,
        tier,
        mount_key: mountKey,
        quantity,
        gallery_image_id: isLocked ? galleryId : null,
        gallery_pricing_applied: isLocked,
      });
      return resp.data;
    },
    onSuccess: () => navigate("/cart"),
  });
'@

$replaceCreate = @'
  const addToCart = useMutation({
    mutationFn: async () => {
      const payload = await requireAuthOrQueueCartAdd({
        kind: "print",
        product_id: product.id,
        size,
        tier,
        mount_key: mountKey,
        quantity,
        gallery_image_id: isLocked ? galleryId : null,
        gallery_pricing_applied: isLocked,
      }, "/cart");

      const resp = await base44.functions.invoke("addToCart", payload);
      return resp.data;
    },
    onSuccess: () => {
      toast({ title: "Added to cart" });
      navigate("/cart");
    },
    onError: (err) => {
      // Ignore the intentional redirect error
      if (err?.message === "AUTH_REDIRECT" || err?.code === "AUTH_REDIRECT") return;
      toast({
        variant: "destructive",
        title: "Could not add to cart",
        description: err?.message || "Please try again.",
      });
    },
  });
'@

if ($createTxt -notmatch [regex]::Escape($findCreate)) {
  throw "CreatePrint.jsx did not match the expected addToCart block. I won't guess. Paste the addToCart block and I'll regenerate a script."
}
$createTxt = $createTxt.Replace($findCreate, $replaceCreate)
Write-FileUtf8NoBom $createPath $createTxt
Write-Host "   Patched $createPath" -ForegroundColor Green

Write-Host "==> 3) Patch src/pages/Shop.jsx similarly..." -ForegroundColor Cyan
$shopPath = "src/pages/Shop.jsx"
$shopTxt = Get-Content $shopPath -Raw

if ($shopTxt -notmatch 'requireAuthOrQueueCartAdd') {
  $shopTxt = $shopTxt.Replace(
    'import { base44 } from "@/api/base44Client";',
    'import { base44 } from "@/api/base44Client";' + "`n" +
    'import { requireAuthOrQueueCartAdd } from "@/lib/pendingCart";' + "`n" +
    'import { toast } from "@/components/ui/use-toast";'
  )
}

$findShop = @'
  const addToCartMutation = useMutation({
    mutationFn: async ({ product, product_price_id }) => {
      const resp = await base44.functions.invoke("addToCart", {
        kind: "product",
        product_id: product.id,
        product_price_id,
        quantity: 1,
      });
      return resp.data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["cart"] });
      navigate("/cart");
    },
  });
'@

$replaceShop = @'
  const addToCartMutation = useMutation({
    mutationFn: async ({ product, product_price_id }) => {
      const payload = await requireAuthOrQueueCartAdd({
        kind: "product",
        product_id: product.id,
        product_price_id,
        quantity: 1,
      }, "/cart");

      const resp = await base44.functions.invoke("addToCart", payload);
      return resp.data;
    },
    onSuccess: () => {
      toast({ title: "Added to cart" });
      qc.invalidateQueries({ queryKey: ["cart"] });
      navigate("/cart");
    },
    onError: (err) => {
      if (err?.message === "AUTH_REDIRECT" || err?.code === "AUTH_REDIRECT") return;
      toast({
        variant: "destructive",
        title: "Could not add to cart",
        description: err?.message || "Please try again.",
      });
    },
  });
'@

if ($shopTxt -notmatch [regex]::Escape($findShop)) {
  throw "Shop.jsx did not match the expected addToCartMutation block. I won't guess. Paste the addToCartMutation block and I'll regenerate a script."
}
$shopTxt = $shopTxt.Replace($findShop, $replaceShop)
Write-FileUtf8NoBom $shopPath $shopTxt
Write-Host "   Patched $shopPath" -ForegroundColor Green

Write-Host "==> 4) Patch src/Layout.jsx to auto-run queued cart add after login..." -ForegroundColor Cyan
$layoutPath = "src/Layout.jsx"
$layoutTxt = Get-Content $layoutPath -Raw

if ($layoutTxt -notmatch 'runQueuedCartAddIfAny') {
  # Replace the very simple Layout.jsx with an upgraded version (safe, small file)
  $newLayout = @'
import React, { useEffect } from "react";
import Navbar from "./components/layout/Navbar";
import Footer from "./components/layout/Footer";
import { runQueuedCartAddIfAny } from "@/lib/pendingCart";
import { base44 } from "@/api/base44Client";
import { toast } from "@/components/ui/use-toast";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

function CartResumeGate() {
  const { isAuthenticated, isLoadingAuth } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    // Only attempt after auth has finished loading.
    if (isLoadingAuth) return;
    if (!isAuthenticated) return;

    (async () => {
      try {
        const res = await runQueuedCartAddIfAny(async (payload) => {
          const resp = await base44.functions.invoke("addToCart", payload);
          return resp.data;
        });

        if (res?.returnUrl) {
          toast({ title: "Added to cart" });
          navigate(res.returnUrl);
        }
      } catch (e) {
        // If something goes wrong, don't brick the app—just inform.
        toast({
          variant: "destructive",
          title: "Cart action failed",
          description: e?.message || "Please try again.",
        });
      }
    })();
  }, [isAuthenticated, isLoadingAuth, navigate]);

  return null;
}

export default function Layout({ children, currentPageName }) {
  const isAdmin = currentPageName?.startsWith("Admin");
  const isPrintPage = currentPageName === "ProductionSheet";

  if (isPrintPage) {
    return <div className="min-h-screen">{children}</div>;
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: "var(--pm-bg)" }}>
      <Navbar />
      <CartResumeGate />
      <main className="flex-1">{children}</main>
      {!isAdmin && <Footer />}
    </div>
  );
}
'@
  Write-FileUtf8NoBom $layoutPath $newLayout
  Write-Host "   Replaced $layoutPath with CartResumeGate-enabled Layout" -ForegroundColor Green
} else {
  Write-Host "   Layout already contains runQueuedCartAddIfAny; skipping replacement." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "DONE." -ForegroundColor Green
Write-Host "Next: run `npm run dev` and test guest add-to-cart -> redirect -> login -> auto-add -> /cart." -ForegroundColor Cyan
