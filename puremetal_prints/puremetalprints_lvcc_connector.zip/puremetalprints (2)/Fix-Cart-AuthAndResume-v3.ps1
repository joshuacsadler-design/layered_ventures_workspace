# Fix-Cart-AuthAndResume-v3.ps1
# Run from repo root:
# powershell -ExecutionPolicy Bypass -File .\Fix-Cart-AuthAndResume-v3.ps1

$ErrorActionPreference = "Stop"

function Write-FileUtf8NoBom($path, $content) {
  $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($path, $content, $utf8NoBom)
}

function Ensure-File($path, $content) {
  $dir = Split-Path -Parent $path
  if (!(Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
  Write-FileUtf8NoBom $path $content
}

function Ensure-Imports($path) {
  $txt = Get-Content $path -Raw

  if ($txt -notmatch 'from\s+"@/api/base44Client"') {
    throw "Expected base44Client import not found in $path"
  }

  if ($txt -notmatch 'from\s+"@/lib/pendingCart"') {
    $txt = $txt -replace '(import\s+\{\s*base44\s*\}\s+from\s+"@/api/base44Client";)', "`$1`nimport { requireAuthOrQueueCartAdd } from `"`@/lib/pendingCart`";"
  }

  if ($txt -notmatch 'use-toast') {
    $txt = $txt -replace '(import\s+\{\s*base44\s*\}\s+from\s+"@/api/base44Client";[^\r\n]*\r?\n(?:import.*\r?\n)*)', "`$1import { toast } from `"`@/components/ui/use-toast`";`n"
  }

  Write-FileUtf8NoBom $path $txt
}

function Patch-MutationInvoke($path, $mutationName) {
  $txt = Get-Content $path -Raw

  # Find: const <mutationName> = useMutation({ ... base44.functions.invoke("addToCart", { PAYLOAD }) ... });
  $pattern = "const\s+$mutationName\s*=\s*useMutation\(\s*\{\s*[\s\S]*?base44\.functions\.invoke\(\s*`"addToCart`"\s*,\s*\{([\s\S]*?)\}\s*\)[\s\S]*?\}\s*\)\s*;"
  $m = [regex]::Match($txt, $pattern)
  if (!$m.Success) {
    throw "Could not find $mutationName useMutation addToCart invoke block in $path"
  }

  $payloadInner = $m.Groups[1].Value.TrimEnd()

  # Replace ONLY the invoke(...) call inside that matched region
  $matchedRegion = $m.Value
  $invokePattern = 'base44\.functions\.invoke\(\s*"addToCart"\s*,\s*\{[\s\S]*?\}\s*\)'
  $newInvoke = @"
base44.functions.invoke("addToCart", await requireAuthOrQueueCartAdd({
$payloadInner
}, "/cart"))
"@

  $region2 = [regex]::Replace($matchedRegion, $invokePattern, $newInvoke, 1)

  # Ensure onSuccess toast + navigate/cart invalidate logic remains; inject toast if missing
  if ($region2 -match 'onSuccess\s*:') {
    # If there's already a toast call, leave it; otherwise inject toast at start of onSuccess block
    if ($region2 -notmatch 'toast\(') {
      $region2 = [regex]::Replace(
        $region2,
        'onSuccess\s*:\s*\(\s*\)\s*=>\s*\{',
        'onSuccess: () => {`n      toast({ title: "Added to cart" });',
        1
      )
    }
  }

  # Ensure onError exists and ignores AUTH_REDIRECT
  if ($region2 -notmatch 'onError\s*:') {
    # Add onError right before the closing of useMutation object (best-effort)
    $region2 = $region2 -replace '\}\s*\)\s*;\s*$', @"
    ,
    onError: (err) => {
      if (err?.message === "AUTH_REDIRECT" || err?.code === "AUTH_REDIRECT") return;
      toast({
        variant: "destructive",
        title: "Could not add to cart",
        description: err?.message || "Please try again.",
      });
    }
  });
"@
  } else {
    # Patch existing onError to ignore AUTH_REDIRECT if not already
    if ($region2 -notmatch 'AUTH_REDIRECT') {
      $region2 = [regex]::Replace(
        $region2,
        'onError\s*:\s*\(\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*\)\s*=>\s*\{',
        'onError: ($1) => {`n      if ($1?.message === "AUTH_REDIRECT" || $1?.code === "AUTH_REDIRECT") return;',
        1
      )
    }
  }

  $txt2 = $txt.Replace($matchedRegion, $region2)
  Write-FileUtf8NoBom $path $txt2
}

function Ensure-PendingCart() {
  $content = @'
import { base44 } from "@/api/base44Client";

const KEY = "pm_pending_cart_add";

export async function requireAuthOrQueueCartAdd(payload, returnUrl = "/cart") {
  const authed = await base44.auth.isAuthenticated();
  if (authed) return payload;

  localStorage.setItem(KEY, JSON.stringify({ payload, returnUrl }));
  base44.auth.redirectToLogin(window.location.href);

  const err = new Error("AUTH_REDIRECT");
  err.code = "AUTH_REDIRECT";
  throw err;
}

export async function runQueuedCartAddIfAny(invokeFn) {
  const raw = localStorage.getItem(KEY);
  if (!raw) return null;

  const { payload, returnUrl } = JSON.parse(raw);
  localStorage.removeItem(KEY);

  const result = await invokeFn(payload);
  return { result, returnUrl: returnUrl || "/cart" };
}
'@
  Ensure-File "src/lib/pendingCart.js" $content
}

function Patch-LayoutResume() {
  $path = "src/Layout.jsx"
  if (!(Test-Path $path)) {
    Write-Host "Layout.jsx not found, skipping layout patch." -ForegroundColor Yellow
    return
  }
  $txt = Get-Content $path -Raw
  if ($txt -match 'runQueuedCartAddIfAny') {
    Write-Host "Layout already has resume logic (or previously patched). Skipping." -ForegroundColor Yellow
    return
  }

  $newLayout = @'
import React, { useEffect } from "react";
import Navbar from "./components/layout/Navbar";
import Footer from "./components/layout/Footer";
import { runQueuedCartAddIfAny } from "@/lib/pendingCart";
import { base44 } from "@/api/base44Client";
import { toast } from "@/components/ui/use-toast";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

function CartResumeGate() {
  const { isAuthenticated, isLoadingAuth } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (isLoadingAuth) return;
    if (!isAuthenticated) return;

    (async () => {
      try {
        const res = await runQueuedCartAddIfAny(async (payload) => {
          const resp = await base44.functions.invoke("addToCart", payload);
          return resp.data;
        });

        if (res?.returnUrl) {
          toast({ title: "Added to cart" });
          navigate(res.returnUrl);
        }
      } catch (e) {
        toast({
          variant: "destructive",
          title: "Cart action failed",
          description: e?.message || "Please try again.",
        });
      }
    })();
  }, [isAuthenticated, isLoadingAuth, navigate]);

  return null;
}

export default function Layout({ children, currentPageName }) {
  const isAdmin = currentPageName?.startsWith("Admin");
  const isPrintPage = currentPageName === "ProductionSheet";

  if (isPrintPage) {
    return <div className="min-h-screen">{children}</div>;
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: "var(--pm-bg)" }}>
      <Navbar />
      <CartResumeGate />
      <main className="flex-1">{children}</main>
      {!isAdmin && <Footer />}
    </div>
  );
}
'@
  Write-FileUtf8NoBom $path $newLayout
}

Write-Host "==> Writing canonical src/lib/pendingCart.js..." -ForegroundColor Cyan
Ensure-PendingCart
Write-Host "   OK" -ForegroundColor Green

Write-Host "==> Patching CreatePrint.jsx..." -ForegroundColor Cyan
Ensure-Imports "src/pages/CreatePrint.jsx"
Patch-MutationInvoke "src/pages/CreatePrint.jsx" "addToCart"
Write-Host "   OK" -ForegroundColor Green

Write-Host "==> Patching Shop.jsx..." -ForegroundColor Cyan
Ensure-Imports "src/pages/Shop.jsx"
Patch-MutationInvoke "src/pages/Shop.jsx" "addToCartMutation"
Write-Host "   OK" -ForegroundColor Green

Write-Host "==> Patching Layout.jsx (auto-resume queued add)..." -ForegroundColor Cyan
Patch-LayoutResume
Write-Host "   OK (or skipped)" -ForegroundColor Green

Write-Host ""
Write-Host "DONE. Now run: npm install; npm run dev" -ForegroundColor Green
Write-Host "Test: Incognito -> Add to cart -> Redirect -> Login -> Auto-add -> /cart" -ForegroundColor Cyan
