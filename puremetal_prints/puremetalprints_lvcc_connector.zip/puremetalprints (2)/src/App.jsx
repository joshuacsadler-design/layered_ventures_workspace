import React, { useEffect, useMemo } from "react";
import { Toaster } from "@/components/ui/toaster";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClientInstance } from "@/lib/query-client";
import NavigationTracker from "@/lib/NavigationTracker";
import { pagesConfig } from "./pages.config";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Navigate,
  useLocation,
} from "react-router-dom";
import PageNotFound from "./lib/PageNotFound";
import { AuthProvider, useAuth } from "@/lib/AuthContext";
import UserNotRegisteredError from "@/components/UserNotRegisteredError";

// Explicit page import (pages.config.js is auto-generated and may not include this)
import CheckoutSuccess from "@/pages/CheckoutSuccess";

const { Pages, Layout, mainPage } = pagesConfig;

const mainPageKey = mainPage ?? Object.keys(Pages || {})[0];
const MainPage = mainPageKey && Pages?.[mainPageKey] ? Pages[mainPageKey] : null;

const LayoutWrapper = ({ children, currentPageName }) =>
  Layout ? (
    <Layout currentPageName={currentPageName}>{children}</Layout>
  ) : (
    <>{children}</>
  );

// Convert "CreatePrint" -> "create-print", "AdminSiteContent" -> "admin-site-content"
function toKebabCase(s) {
  return String(s)
    .replace(/([a-z0-9])([A-Z])/g, "$1-$2")
    .replace(/_/g, "-")
    .toLowerCase();
}

// Map page key -> route path
function routeForPageKey(key) {
  if (!key) return "/";
  if (key === "/") return "/";

  // If someone already used "/something" as a key, keep it.
  if (String(key).startsWith("/")) return String(key);

  // Default: kebab-case routes
  return `/${toKebabCase(key)}`;
}

// Prefer the "real" CreatePrint page component over any alias/redirect page
function pickCreatePrintPage(PagesObj) {
  return (
    PagesObj?.CreatePrint ||
    PagesObj?.["create-print"] ||
    PagesObj?.["/create-print"] ||
    PagesObj?.Create_Print ||
    PagesObj?.["create_print"] ||
    null
  );
}

// Redirect helper that preserves ?query and #hash
function LegacyRedirect({ to }) {
  const location = useLocation();
  const dest = `${to}${location.search || ""}${location.hash || ""}`;
  return <Navigate to={dest} replace />;
}

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // ✅ Hooks must run before any early returns
  const CreatePrintPage = useMemo(() => pickCreatePrintPage(Pages || {}), []);

  // Never navigate during render
  useEffect(() => {
    if (authError?.type === "auth_required") {
      navigateToLogin();
    }
  }, [authError?.type, navigateToLogin]);

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin" />
      </div>
    );
  }

  if (authError) {
    if (authError.type === "user_not_registered") return <UserNotRegisteredError />;
    if (authError.type === "auth_required") return null; // redirect happens in useEffect
  }

  return (
    <Routes>
      {/* Main page always at "/" */}
      <Route
        path="/"
        element={
          <LayoutWrapper currentPageName="/">
            {MainPage ? <MainPage /> : <PageNotFound />}
          </LayoutWrapper>
        }
      />

      {/* ✅ Checkout success (explicit, not dependent on pages.config.js) */}
      <Route
        path="/checkout-success"
        element={
          <LayoutWrapper currentPageName="/checkout-success">
            <CheckoutSuccess />
          </LayoutWrapper>
        }
      />
      {/* Legacy variants */}
      <Route path="/CheckoutSuccess" element={<LegacyRedirect to="/checkout-success" />} />
      <Route path="/checkoutsuccess" element={<LegacyRedirect to="/checkout-success" />} />
      <Route path="/checkout_success" element={<LegacyRedirect to="/checkout-success" />} />

      {/* Canonical CreatePrint route (ALWAYS real page, NOT redirect component) */}
      <Route
        path="/create-print"
        element={
          <LayoutWrapper currentPageName="/create-print">
            {CreatePrintPage ? <CreatePrintPage /> : <PageNotFound />}
          </LayoutWrapper>
        }
      />

      {/* Optional legacy aliases -> canonical */}
      <Route path="/CreatePrint" element={<LegacyRedirect to="/create-print" />} />
      <Route path="/createprint" element={<LegacyRedirect to="/create-print" />} />
      <Route path="/create_print" element={<LegacyRedirect to="/create-print" />} />

      {/* All other pages */}
      {Object.entries(Pages || {}).flatMap(([key, Page]) => {
        const canonicalPath = routeForPageKey(key);

        // Skip duplicate "/" and skip any page-key that maps to "/create-print" (handled above)
        if (canonicalPath === "/") return [];
        if (canonicalPath === "/create-print") return [];

        // Add legacy PascalCase route (/OrderDetail) -> canonical (/order-detail)
        const wantsLegacy =
          typeof key === "string" &&
          !key.startsWith("/") &&
          /[A-Z]/.test(key) &&
          `/${key}` !== canonicalPath;

        const routes = [
          <Route
            key={key}
            path={canonicalPath}
            element={
              <LayoutWrapper currentPageName={canonicalPath}>
                <Page />
              </LayoutWrapper>
            }
          />,
        ];

        if (wantsLegacy) {
          routes.push(
            <Route
              key={`${key}__legacy`}
              path={`/${key}`}
              element={<LegacyRedirect to={canonicalPath} />}
            />
          );
        }

        return routes;
      })}

      {/* 404 */}
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <NavigationTracker />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  );
}

export default App;