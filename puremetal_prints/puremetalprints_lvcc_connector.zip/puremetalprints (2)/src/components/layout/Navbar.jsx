import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { createPageUrl } from "@/utils";
import {
  ShoppingCart,
  Menu,
  X,
  User,
  LogOut,
  Shield,
  ChevronDown,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Navbar() {
  const [user, setUser] = useState(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isAuth, setIsAuth] = useState(false);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const authenticated = await base44.auth.isAuthenticated();
    setIsAuth(authenticated);
    if (authenticated) {
      const me = await base44.auth.me();
      setUser(me);
    }
  };

  const { data: cartBadge } = useQuery({
    queryKey: ["cart-badge"],
    queryFn: async () => {
      const response = await base44.functions.invoke("getCartBadgeCount", {});
      return response.data;
    },
    enabled: isAuth,
    refetchInterval: 5000,
  });

  const cartCount = cartBadge?.count || 0;

  const navLinks = [
    { label: "Gallery", page: "Gallery" },
    { label: "Create Print", href: "/CreatePrint" },
    { label: "Shop", page: "Shop" },
    { label: "Contact", page: "Contact" },
  ];

  return (
    <nav
      className="sticky top-0 z-50 border-b backdrop-blur-xl"
      style={{
        borderColor: "var(--pm-border)",
        backgroundColor: "rgba(250,250,250,0.85)",
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to={createPageUrl("Home")} className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-neutral-900 dark:bg-white flex items-center justify-center">
              <span className="text-white dark:text-black font-bold text-sm">
                PM
              </span>
            </div>
            <span
              className="font-semibold text-lg tracking-tight hidden sm:block"
              style={{ color: "var(--pm-text)" }}
            >
              PureMetal Prints
            </span>
          </Link>

          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.page || link.href}
                to={link.href || createPageUrl(link.page)}
                className="px-3 py-2 text-sm font-medium rounded-lg transition-colors hover:bg-neutral-100 dark:hover:bg-neutral-800"
                style={{ color: "var(--pm-text-muted)" }}
              >
                {link.label}
              </Link>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <Link
              to={createPageUrl("Cart")}
              className="relative p-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            >
              <ShoppingCart className="w-5 h-5" style={{ color: "var(--pm-text)" }} />
              {isAuth && cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-5 h-5 flex items-center justify-center text-[10px] font-bold text-white bg-neutral-900 dark:bg-white dark:text-black rounded-full">
                  {cartCount > 9 ? "9+" : cartCount}
                </span>
              )}
            </Link>

            {isAuth ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="gap-1.5">
                    <div className="w-7 h-7 rounded-full bg-neutral-200 dark:bg-neutral-700 flex items-center justify-center">
                      <span className="text-xs font-medium">
                        {user?.full_name?.[0] || "U"}
                      </span>
                    </div>
                    <ChevronDown className="w-3.5 h-3.5 opacity-50" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <div className="px-2 py-1.5">
                    <p className="text-sm font-medium">{user?.full_name}</p>
                    <p className="text-xs text-muted-foreground">{user?.email}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link
                      to={createPageUrl("Account")}
                      className="flex items-center gap-2"
                    >
                      <User className="w-4 h-4" /> My Account
                    </Link>
                  </DropdownMenuItem>
                  {user?.role === "admin" && (
                    <DropdownMenuItem asChild>
                      <Link
                        to={createPageUrl("AdminDashboard")}
                        className="flex items-center gap-2"
                      >
                        <Shield className="w-4 h-4" /> Admin
                      </Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={() => {
                      base44.auth.logout("/");
                    }}
                    className="flex items-center gap-2 text-red-600"
                  >
                    <LogOut className="w-4 h-4" /> Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button
                size="sm"
                onClick={() => base44.auth.redirectToLogin()}
                className="bg-neutral-900 text-white hover:bg-neutral-800 dark:bg-white dark:text-black dark:hover:bg-neutral-200"
              >
                Sign In
              </Button>
            )}

            <button
              className="md:hidden p-2"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {mobileOpen && (
        <div
          className="md:hidden border-t px-4 py-3 space-y-1"
          style={{
            borderColor: "var(--pm-border)",
            backgroundColor: "var(--pm-surface)",
          }}
        >
          {navLinks.map((link) => (
            <Link
              key={link.page || link.href}
              to={link.href || createPageUrl(link.page)}
              onClick={() => setMobileOpen(false)}
              className="block px-3 py-2 text-sm font-medium rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800"
            >
              {link.label}
            </Link>
          ))}
        </div>
      )}
    </nav>
  );
}
