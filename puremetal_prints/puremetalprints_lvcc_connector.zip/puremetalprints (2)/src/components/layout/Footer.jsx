import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";

export default function Footer() {
  return (
    <footer className="border-t mt-auto" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-7 h-7 rounded-lg bg-neutral-900 dark:bg-white flex items-center justify-center">
                <span className="text-white dark:text-black font-bold text-xs">PM</span>
              </div>
              <span className="font-semibold tracking-tight">PureMetal Prints</span>
            </div>
            <p className="text-sm" style={{ color: "var(--pm-text-muted)" }}>
              Premium metal prints crafted with precision and care. Transform your images into stunning wall art.
            </p>
          </div>
          <div>
            <h4 className="text-sm font-semibold mb-3 uppercase tracking-wider" style={{ color: "var(--pm-text-muted)" }}>Quick Links</h4>
            <div className="space-y-2">
              <Link to={createPageUrl("Gallery")} className="block text-sm hover:underline" style={{ color: "var(--pm-text-muted)" }}>Gallery</Link>
              <Link to={createPageUrl("CreatePrint")} className="block text-sm hover:underline" style={{ color: "var(--pm-text-muted)" }}>Create a Print</Link>
              <Link to={createPageUrl("Shop")} className="block text-sm hover:underline" style={{ color: "var(--pm-text-muted)" }}>Shop Accessories</Link>
              <Link to={createPageUrl("Contact")} className="block text-sm hover:underline" style={{ color: "var(--pm-text-muted)" }}>Contact Us</Link>
            </div>
          </div>
          <div>
            <h4 className="text-sm font-semibold mb-3 uppercase tracking-wider" style={{ color: "var(--pm-text-muted)" }}>Support</h4>
            <p className="text-sm" style={{ color: "var(--pm-text-muted)" }}>puremetalprints@outlook.com</p>
            {/* Domain support email */}
            {/*<p className="text-sm" style={{ color: "var(--pm-text-muted)" }}>support@puremetalprints.pro</p>*/}
            {/* Phone number display */}
            {/* <p className="text-sm mt-1" style={{ color: "var(--pm-text-muted)" }}>(555) 123-4567</p> */}
          </div>
        </div>
        <div className="mt-8 pt-8 border-t text-center" style={{ borderColor: "var(--pm-border)" }}>
          <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>
            © {new Date().getFullYear()} PureMetal Prints. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}