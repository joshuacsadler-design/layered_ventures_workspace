import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import AdminLayout from "@/components/admin/AdminLayout";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Loader2 } from "lucide-react";

export default function AdminSiteContent() {
  const qc = useQueryClient();
  const [contentState, setContentState] = useState({});

  const { data, isLoading } = useQuery({
    queryKey: ["site-content-admin"],
    queryFn: async () => {
      const resp = await base44.functions.invoke("getSiteContentAdmin", {});
      
      // Also fetch license text
      const licenseResp = await base44.functions.invoke("getGalleryLicenseText", {});
      
      setContentState({
        ...(resp.data.siteContent || {}),
        gallery_license_text: licenseResp.data.gallery_license_text,
        gallery_license_version: licenseResp.data.gallery_license_version
      });
      return resp.data;
    },
  });

  const updateContent = useMutation({
    mutationFn: async (updates) => {
      // Save regular content
      await base44.functions.invoke("updateSiteContentAdmin", updates);
      
      // Save license text separately if provided
      if (updates.siteContent?.gallery_license_text) {
        await base44.functions.invoke("setGalleryLicenseTextAdmin", {
          gallery_license_text: updates.siteContent.gallery_license_text
        });
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["site-content-admin"] });
      alert("Content saved successfully");
    },
  });

  const pushLvccSnapshots = useMutation({
    mutationFn: async () => {
      const resp = await base44.functions.invoke("lvccPushSnapshotsAdmin", {});
      return resp.data;
    },
    onSuccess: (data) => {
      alert(`LVCC sync complete: ${data?.status || "ok"}`);
    },
    onError: (e) => {
      alert(`LVCC sync failed: ${e?.message || "Unknown error"}`);
    },
  });

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin" />
        </div>
      </AdminLayout>
    );
  }

  const handleSave = () => {
    updateContent.mutate({ siteContent: contentState });
  };

  return (
    <AdminLayout>
      <div className="space-y-6 max-w-4xl">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Site Content</h1>
            <p className="text-sm text-muted-foreground mt-1">Manage hero visuals, announcements, and text</p>
          </div>
          <Button onClick={handleSave} disabled={updateContent.isPending}>
            {updateContent.isPending ? "Saving..." : "Save Changes"}
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Text Content</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Hero Caption</Label>
              <Input
                value={contentState.hero_caption ?? ""}
                onChange={(e) => setContentState({ ...contentState, hero_caption: e.target.value })}
              />
            </div>
            <div>
              <Label>Gallery Helper Text</Label>
              <Textarea
                value={contentState.gallery_helper ?? ""}
                onChange={(e) => setContentState({ ...contentState, gallery_helper: e.target.value })}
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Layered Ventures Command Center (LVCC)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between gap-4">
              <div>
                <Label>Enable LVCC Mirroring</Label>
                <p className="text-xs text-muted-foreground">
                  When enabled, PureMetal Prints can push operational snapshots to LVCC for monitoring.
                </p>
              </div>
              <Switch
                checked={String(contentState.lvcc_enabled || "").toLowerCase() === "true"}
                onCheckedChange={(checked) =>
                  setContentState({ ...contentState, lvcc_enabled: checked ? "true" : "false" })
                }
              />
            </div>

            <div>
              <Label>LVCC Base URL</Label>
              <Input
                value={contentState.lvcc_base_url ?? ""}
                onChange={(e) => setContentState({ ...contentState, lvcc_base_url: e.target.value })}
                placeholder="https://lvcc.yourdomain.com"
              />
              <p className="text-xs text-muted-foreground mt-1">
                We will POST snapshots to: <span className="font-mono">{(contentState.lvcc_base_url || "").replace(/\/+$/, "")}/ingest/snapshots</span>
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>LVCC Org ID</Label>
                <Input
                  value={contentState.lvcc_org_id ?? ""}
                  onChange={(e) => setContentState({ ...contentState, lvcc_org_id: e.target.value })}
                  placeholder="org_puremetal"
                />
              </div>
              <div>
                <Label>LVCC Business ID</Label>
                <Input
                  value={contentState.lvcc_business_id ?? ""}
                  onChange={(e) => setContentState({ ...contentState, lvcc_business_id: e.target.value })}
                  placeholder="biz_prints"
                />
              </div>
            </div>

            <div>
              <Label>LVCC API Key</Label>
              <Input
                type="password"
                value={contentState.lvcc_api_key ?? ""}
                onChange={(e) => setContentState({ ...contentState, lvcc_api_key: e.target.value })}
                placeholder="Paste the LVCC key here"
              />
              <p className="text-xs text-muted-foreground mt-1">
                This key is stored in Site Content for now. Treat it like a password.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                onClick={() => pushLvccSnapshots.mutate()}
                disabled={pushLvccSnapshots.isPending}
              >
                {pushLvccSnapshots.isPending ? "Syncing..." : "Sync to LVCC Now"}
              </Button>
              <p className="text-xs text-muted-foreground">
                Manual test sync. If LVCC isn’t live yet, this will fail (which is fine).
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Legal / Agreements</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Gallery License Agreement (v{contentState.gallery_license_version || 1})</Label>
              <p className="text-xs text-muted-foreground mb-2">
                This text is shown to clients when they opt-in to gallery publishing. Version increments on each save.
              </p>
              <Textarea
                value={contentState.gallery_license_text ?? ""}
                onChange={(e) => setContentState({ ...contentState, gallery_license_text: e.target.value })}
                rows={10}
                placeholder="Gallery license agreement text..."
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Hero Images</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Hero image management: {(data?.heroImages ?? []).length} images configured.
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              Detailed hero visual editor coming soon. For now, manage via Gallery admin.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Announcements</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Announcements: {(data?.announcements ?? []).length} configured.
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              Detailed announcement editor coming soon.
            </p>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}