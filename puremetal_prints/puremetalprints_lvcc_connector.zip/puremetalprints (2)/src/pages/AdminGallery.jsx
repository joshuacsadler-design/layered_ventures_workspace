import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Upload, Trash2, GripVertical, Shield, ShieldAlert } from "lucide-react";
import AdminLayout from "@/components/admin/AdminLayout";
import PMBadge from "@/components/ui/PMBadge";

export default function AdminGallery() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();
  const [showArchived, setShowArchived] = useState(false);

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      const me = await base44.auth.me();
      if (me.role !== "admin") { window.location.href = "/"; return; }
      setUser(me);
    })();
  }, []);

  const { data: allGalleryImages = [], isLoading } = useQuery({
    queryKey: ["admin-gallery-images"],
    queryFn: () => base44.asServiceRole.entities.GalleryImage.list('-sort_order'),
    enabled: !!user,
  });

  const galleryImages = allGalleryImages.filter(img => showArchived || img.is_active);

  const { data: files = [] } = useQuery({
    queryKey: ["admin-gallery-files"],
    queryFn: () => base44.asServiceRole.entities.File.filter({ kind: 'GALLERY' }),
    enabled: !!user,
  });

  const { data: approvedItems = [] } = useQuery({
    queryKey: ["admin-approved-items"],
    queryFn: async () => {
      const items = await base44.asServiceRole.entities.OrderItem.filter({ 
        status: 'APPROVED'
      });
      
      const acceptances = await base44.asServiceRole.entities.GalleryLicenseAcceptance.list();
      const acceptanceMap = {};
      acceptances.forEach(acc => {
        acceptanceMap[acc.order_item_id] = acc;
      });
      
      return items.map(item => ({
        ...item,
        acceptance: acceptanceMap[item.id] || null,
        licensed: !!acceptanceMap[item.id],
        is_final: acceptanceMap[item.id]?.is_final || false
      })).slice(0, 20);
    },
    enabled: !!user,
  });

  const uploadImageMutation = useMutation({
    mutationFn: async (file) => {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      const fileRecord = await base44.asServiceRole.entities.File.create({
        order_item_id: null,
        kind: 'GALLERY',
        file_url: file_url,
        filename: file.name,
        source_file_id: null,
        is_delivered_to_client: false,
        metadata: { uploaded_by: user.id },
      });

      const title = prompt("Enter image title:");
      if (!title) return;

      const allImages = await base44.asServiceRole.entities.GalleryImage.list();

      await base44.asServiceRole.entities.GalleryImage.create({
        title: title,
        file_id: fileRecord.id,
        is_default_hero: false,
        is_active: true,
        sort_order: allImages.length,
        default_size: '8x10',
        default_material: 'standard',
        allow_reserve_upsell: true,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-gallery-images"]);
      queryClient.invalidateQueries(["admin-gallery-files"]);
    },
  });

  const updateImageMutation = useMutation({
    mutationFn: async ({ imageId, data }) => {
      await base44.asServiceRole.entities.GalleryImage.update(imageId, data);
    },
    onSuccess: () => queryClient.invalidateQueries(["admin-gallery-images"]),
  });

  const deleteImageMutation = useMutation({
    mutationFn: async (imageId) => {
      const image = allGalleryImages.find(img => img.id === imageId);
      if (image?.is_default_hero) {
        alert('Cannot delete default hero. Mark as inactive instead.');
        return;
      }
      await base44.asServiceRole.entities.GalleryImage.delete(imageId);
    },
    onSuccess: () => queryClient.invalidateQueries(["admin-gallery-images"]),
  });

  const publishFromOrderMutation = useMutation({
    mutationFn: async ({ order_item_id, title, file_id, size, tier, mount }) => {
      const { data } = await base44.functions.invoke('publishGalleryImageAdmin', {
        order_item_id,
        title,
        file_id,
        configured_size: size,
        configured_tier: tier,
        configured_mount_key: mount
      });
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-gallery-images"]);
      queryClient.invalidateQueries(["admin-approved-items"]);
      alert('Published to gallery successfully');
    },
    onError: (error) => {
      alert(error.message || 'Failed to publish');
    }
  });

  const handleUploadImage = (e) => {
    const file = e.target.files?.[0];
    if (file) uploadImageMutation.mutate(file);
  };

  const getFileUrl = (fileId) => {
    const file = files.find(f => f.id === fileId);
    return file?.file_url;
  };

  if (!user) return <div className="flex items-center justify-center min-h-screen"><Loader2 className="w-8 h-8 animate-spin" /></div>;

  return (
    <AdminLayout 
      title="Gallery Management"
      actions={
        <div className="flex gap-2">
          <div className="flex items-center gap-2">
            <Switch checked={showArchived} onCheckedChange={setShowArchived} />
            <span className="text-sm">Show Archived</span>
          </div>
          <label className="cursor-pointer">
            <Button asChild>
              <span><Upload className="w-4 h-4 mr-2" /> Upload Image</span>
            </Button>
            <input type="file" accept="image/*" className="hidden" onChange={handleUploadImage} />
          </label>
        </div>
      }
    >
      <div className="space-y-6">
        {/* Source Orders Section */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Approved Orders (Candidates for Publishing)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {approvedItems.length === 0 ? (
                <p className="text-sm text-muted-foreground">No approved items yet</p>
              ) : (
                approvedItems.map(item => {
                  const isPublished = allGalleryImages.some(gi => gi.order_item_id === item.id && gi.is_active);
                  
                  return (
                    <div key={item.id} className="flex items-center justify-between p-3 border rounded" style={{ borderColor: "var(--pm-border)" }}>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{item.title}</p>
                        <p className="text-xs text-muted-foreground">{item.size} · {item.tier}</p>
                        <div className="flex gap-2 mt-1">
                          <PMBadge variant="success">Approved</PMBadge>
                          {item.licensed ? (
                            <PMBadge variant="gold">
                              <Shield className="w-3 h-3 mr-1" />
                              Licensed
                            </PMBadge>
                          ) : (
                            <PMBadge variant="error">
                              <ShieldAlert className="w-3 h-3 mr-1" />
                              NOT LICENSED
                            </PMBadge>
                          )}
                          {isPublished && <PMBadge variant="purple">Published</PMBadge>}
                        </div>
                      </div>
                      <Button
                        size="sm"
                        onClick={async () => {
                          const proofs = await base44.asServiceRole.entities.Proof.filter({ 
                            order_item_id: item.id, 
                            is_selected: true 
                          });
                          const proof = proofs[0];
                          if (!proof) {
                            alert('No selected proof found');
                            return;
                          }
                          publishFromOrderMutation.mutate({
                            order_item_id: item.id,
                            title: item.title,
                            file_id: proof.file_id,
                            size: item.size,
                            tier: item.tier,
                            mount: item.mount_key
                          });
                        }}
                        disabled={!item.licensed || isPublished || publishFromOrderMutation.isPending}
                      >
                        {isPublished ? 'Published' : 'Publish'}
                      </Button>
                    </div>
                  );
                })
              )}
            </div>
            {!item.licensed && (
              <p className="text-xs text-muted-foreground mt-3">
                Items marked "NOT LICENSED" cannot be published. Client must grant gallery permission first.
              </p>
            )}
          </CardContent>
        </Card>

        {/* Existing Gallery Images */}
        <h2 className="text-lg font-semibold">Published Gallery Images</h2>

        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {galleryImages.map((image) => {
              const fileUrl = getFileUrl(image.file_id);
              
              return (
                <Card key={image.id}>
                  <CardContent className="p-4">
                    <div className="aspect-square bg-neutral-100 dark:bg-neutral-800 rounded overflow-hidden mb-3">
                      {fileUrl && (
                        <img src={fileUrl} alt={image.title} className="w-full h-full object-cover" />
                      )}
                    </div>
                    
                    <div className="space-y-3">
                      <div>
                        <Input
                          value={image.title}
                          onChange={(e) => updateImageMutation.mutate({ imageId: image.id, data: { title: e.target.value } })}
                          className="font-medium"
                        />
                      </div>

                      <div className="flex items-center gap-2 text-sm">
                        <Switch
                          checked={image.is_active}
                          onCheckedChange={(checked) => updateImageMutation.mutate({ imageId: image.id, data: { is_active: checked } })}
                        />
                        <span>Active</span>
                      </div>

                      <div className="flex gap-2 flex-wrap">
                        {image.is_default_hero && (
                          <PMBadge variant="gold">Default Hero</PMBadge>
                        )}
                        {!image.is_active && (
                          <PMBadge variant="default">Archived</PMBadge>
                        )}
                        {image.licensed && (
                          <PMBadge variant="success">
                            <Shield className="w-3 h-3 mr-1" />
                            Licensed
                          </PMBadge>
                        )}
                        {image.order_item_id && !image.licensed && (
                          <PMBadge variant="error">
                            <ShieldAlert className="w-3 h-3 mr-1" />
                            NOT LICENSED
                          </PMBadge>
                        )}
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div>
                          <p className="text-muted mb-1">Size</p>
                          <Select
                            value={image.default_size}
                            onValueChange={(value) => updateImageMutation.mutate({ imageId: image.id, data: { default_size: value } })}
                          >
                            <SelectTrigger className="h-8">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="6x8">6x8</SelectItem>
                              <SelectItem value="8x10">8x10</SelectItem>
                              <SelectItem value="8x12">8x12</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <p className="text-muted mb-1">Material</p>
                          <Select
                            value={image.default_material}
                            onValueChange={(value) => updateImageMutation.mutate({ imageId: image.id, data: { default_material: value } })}
                          >
                            <SelectTrigger className="h-8">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="standard">Standard</SelectItem>
                              <SelectItem value="puremetalreserve">Reserve</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 text-sm">
                        <Switch
                          checked={image.allow_reserve_upsell}
                          onCheckedChange={(checked) => updateImageMutation.mutate({ imageId: image.id, data: { allow_reserve_upsell: checked } })}
                        />
                        <span>Allow Reserve Upsell</span>
                      </div>

                      {!image.is_default_hero && (
                        <Button
                          variant="destructive"
                          size="sm"
                          className="w-full"
                          onClick={() => deleteImageMutation.mutate(image.id)}
                        >
                          <Trash2 className="w-3 h-3 mr-1" /> Delete
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}

            {galleryImages.length === 0 && (
              <div className="col-span-full text-center py-20">
                <p style={{ color: "var(--pm-text-muted)" }}>No gallery images yet. Upload to get started.</p>
              </div>
            )}
          </div>
        )}
      </div>
    </AdminLayout>
  );
}