import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/components/utils";
import { ArrowRight, Sparkles, Shield, Truck, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery } from "@tanstack/react-query";

const features = [
  {
    icon: Sparkles,
    title: "Premium Quality",
    desc: "HD printing on premium aluminum with vivid, lasting colors.",
  },
  {
    icon: Shield,
    title: "Client Proofing",
    desc: "Review and approve digital proofs before production begins.",
  },
  {
    icon: Truck,
    title: "Safe Delivery",
    desc: "Custom packaging ensures your prints arrive in perfect condition.",
  },
];

export default function Home() {
  const [currentHeroIndex, setCurrentHeroIndex] = useState(0);
  const [heroCaption, setHeroCaption] = useState(
    "Transform your memories into stunning metal prints that last a lifetime."
  );

  const { data: siteContent = [] } = useQuery({
    queryKey: ["home-site-content"],
    queryFn: async () => {
      try {
        return await base44.entities.SiteContent.list();
      } catch {
        return [];
      }
    },
  });

  const { data: heroImages = [] } = useQuery({
    queryKey: ["home-hero-images"],
    queryFn: async () => {
      try {
        const images = await base44.entities.GalleryImage.filter({
          is_active: true,
        });
        return images.sort(
          (a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0)
        );
      } catch {
        return [];
      }
    },
  });

  const { data: heroFiles = [] } = useQuery({
    queryKey: ["home-hero-files"],
    queryFn: async () => {
      try {
        return await base44.entities.File.filter({ kind: "GALLERY" });
      } catch {
        return [];
      }
    },
    enabled: heroImages.length > 0,
  });

  const { data: announcements = [] } = useQuery({
    queryKey: ["home-announcements"],
    queryFn: async () => {
      try {
        return await base44.entities.Announcement.filter({
          is_active: true,
        });
      } catch {
        return [];
      }
    },
  });

  const [dismissedAnnouncements, setDismissedAnnouncements] = useState([]);

  useEffect(() => {
    const caption = siteContent.find((c) => c.key === "hero_caption");
    if (caption) setHeroCaption(caption.value);
  }, [siteContent]);

  useEffect(() => {
    if (heroImages.length > 1) {
      const interval = setInterval(() => {
        setCurrentHeroIndex(
          (prev) => (prev + 1) % heroImages.length
        );
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [heroImages.length]);

  const activeAnnouncements = announcements.filter(
    (a) => !dismissedAnnouncements.includes(a.id)
  );

  const currentHeroImage = heroImages[currentHeroIndex];
  const currentHeroFile = currentHeroImage
    ? heroFiles.find((f) => f.id === currentHeroImage.file_id)
    : null;

  const heroImageUrl =
    currentHeroFile?.file_url ||
    "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80";

  return (
    <div>
      <AnimatePresence>
        {activeAnnouncements.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 max-w-md w-full mx-4"
          >
            <div className="bg-amber-50 border border-amber-200 rounded-xl shadow-lg p-4">
              {activeAnnouncements.map((announcement) => (
                <div
                  key={announcement.id}
                  className="flex items-start justify-between gap-3 mb-2 last:mb-0"
                >
                  <div className="flex-1">
                    <p className="font-semibold text-sm">
                      {announcement.title}
                    </p>
                    <p className="text-xs mt-1">
                      {announcement.message}
                    </p>
                  </div>
                  <button
                    onClick={() =>
                      setDismissedAnnouncements([
                        ...dismissedAnnouncements,
                        announcement.id,
                      ])
                    }
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-sm font-semibold uppercase tracking-widest mb-4">
                Premium Metal Prints
              </p>
              <h1 className="text-4xl md:text-6xl font-bold tracking-tight leading-tight">
                Your Images,
                <br />
                <span className="bg-gradient-to-r from-purple-600 to-amber-500 bg-clip-text text-transparent">
                  Forged in Metal
                </span>
              </h1>
              <p className="mt-6 text-lg max-w-lg">
                {heroCaption}
              </p>
              <div className="mt-8 flex gap-3">
                <Link to={createPageUrl("CreatePrint")}>
                  <Button size="lg" className="gap-2">
                    Start Creating <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
                <Link to={createPageUrl("Gallery")}>
                  <Button size="lg" variant="outline">
                    Browse Gallery
                  </Button>
                </Link>
              </div>
            </div>

            <div className="relative">
              <motion.div
                key={currentHeroIndex}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <div className="aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl">
                  <img
                    src={heroImageUrl}
                    alt="Metal print showcase"
                    className="w-full h-full object-cover"
                  />
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}