import React, { useMemo } from "react";
import { useLocation, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";

function resolveReturnUrl(location) {
  const params = new URLSearchParams(location.search);

  const nextParam = params.get("next");
  const fromUrlParam = params.get("from_url");
  const raw = nextParam || fromUrlParam;

  if (!raw) return `${window.location.origin}/`;

  let url;
  try {
    url = raw.startsWith("http")
      ? raw
      : `${window.location.origin}${raw.startsWith("/") ? raw : `/${raw}`}`;
  } catch {
    url = `${window.location.origin}/`;
  }

  try {
    const u = new URL(url);
    if (u.pathname.toLowerCase() === "/login") return `${window.location.origin}/`;
  } catch {
    return `${window.location.origin}/`;
  }

  return url;
}

export default function Login() {
  const location = useLocation();
  const returnUrl = useMemo(() => resolveReturnUrl(location), [location]);

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4">
      <div className="max-w-md w-full rounded-2xl border p-6 bg-white dark:bg-neutral-900">
        <h1 className="text-xl font-semibold">Sign in</h1>

        <p className="mt-2 text-sm text-muted-foreground">
          You’ll be redirected to secure Base44 authentication and then returned to:
          <span className="block mt-2 font-mono text-xs break-all">{returnUrl}</span>
        </p>

        <div className="mt-6 flex gap-3">
          <Button
            className="bg-neutral-900 text-white hover:bg-neutral-800 dark:bg-white dark:text-black"
            onClick={() => base44.auth.redirectToLogin(returnUrl)}
          >
            Continue to Sign In
          </Button>

          <Button variant="outline" asChild>
            <Link to="/">Go Home</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}