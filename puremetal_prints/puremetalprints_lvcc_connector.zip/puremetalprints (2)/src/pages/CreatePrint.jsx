import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { saveResumeDraft, loadResumeDraft, clearResumeDraft } from "@/lib/resumeDraft";

const DEFAULT_PRODUCT_ID = "69891cd87542815000d6f958"; // TODO: replace if your app selects product dynamically

function getAppId() {
  return import.meta.env.VITE_BASE44_APP_ID || import.meta.env.VITE_APP_ID || "";
}

function buildFnUrl(fnName) {
  const appId = getAppId();
  if (!appId) return `${window.location.origin}/api/functions/${fnName}`;
  return `${window.location.origin}/api/apps/${appId}/functions/${fnName}`;
}

function getAuthHeader() {
  const keys = ["base44_access_token", "base44.token", "token", "access_token", "auth_token"];
  for (const k of keys) {
    const v = localStorage.getItem(k);
    if (v && String(v).trim().length > 0) return `Bearer ${v}`;
  }
  return "";
}

export default function CreatePrint() {
  const navigate = useNavigate();
  const location = useLocation();

  const [selectedSize, setSelectedSize] = useState("6x8");
  const [selectedTier, setSelectedTier] = useState("standard");
  const [selectedMountKey, setSelectedMountKey] = useState("PURESHADOW_BLACK");
  const [quantity, setQuantity] = useState(1);

  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);

  const [gateOpen, setGateOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [resumeBusy, setResumeBusy] = useState(false);

  const price = useMemo(() => {
    if (selectedSize === "6x8") return 20.0;
    if (selectedSize === "8x12") return 35.0;
    if (selectedSize === "12x18") return 55.0;
    return 20.0;
  }, [selectedSize]);

  useEffect(() => {
    return () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
    };
  }, [previewUrl]);

  async function getUserOrNull() {
    try {
      const u = await base44.auth.me();
      return u || null;
    } catch (_e) {
      return null;
    }
  }

  async function requireLoginWithResume() {
    const meta = {
      product_id: DEFAULT_PRODUCT_ID,
      size: selectedSize,
      tier: selectedTier,
      mount_key: selectedMountKey,
      quantity: quantity,
    };

    await saveResumeDraft({ meta, file: selectedFile });

    // IMPORTANT: do NOT navigate to /login — use Base44 auth redirect
    const returnUrl = `${window.location.origin}/CreatePrint?resume=1`;
    base44.auth.redirectToLogin(returnUrl);
  }

  async function callAddToCartWithUpload(file, meta) {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("product_id", meta.product_id);
    fd.append("size", meta.size);
    fd.append("tier", meta.tier);
    fd.append("mount_key", meta.mount_key);
    fd.append("quantity", String(meta.quantity || 1));

    const url = buildFnUrl("addToCartWithUpload");

    const auth = getAuthHeader();
    const headers = {};
    if (auth) headers["Authorization"] = auth;

    const resp = await fetch(url, {
      method: "POST",
      headers,
      body: fd,
      credentials: "include",
    });

    const dataText = await resp.text();
    let data;
    try {
      data = JSON.parse(dataText);
    } catch (_e) {
      data = { error: dataText };
    }

    if (!resp.ok) {
      throw new Error(data?.error || "Add to cart failed");
    }

    return data;
  }

  async function handleAddToCart() {
    if (!selectedFile) {
      alert("Please choose an image before adding to cart.");
      return;
    }

    setBusy(true);
    try {
      const user = await getUserOrNull();
      if (!user) {
        setGateOpen(true);
        return;
      }

      const meta = {
        product_id: DEFAULT_PRODUCT_ID,
        size: selectedSize,
        tier: selectedTier,
        mount_key: selectedMountKey,
        quantity: quantity,
      };

      await callAddToCartWithUpload(selectedFile, meta);
      await clearResumeDraft();
      navigate("/Checkout");
    } catch (e) {
      alert(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  }

  async function handleUploadClick() {
    if (!selectedFile) {
      alert("Choose an image file first.");
      return;
    }

    const user = await getUserOrNull();
    if (!user) {
      setGateOpen(true);
      return;
    }

    alert("You're signed in. Click Add to cart to upload and continue to checkout.");
  }

  useEffect(() => {
    const run = async () => {
      const params = new URLSearchParams(location.search);
      if (params.get("resume") !== "1") return;

      setResumeBusy(true);
      try {
        const user = await getUserOrNull();
        if (!user) return;

        const draft = await loadResumeDraft();
        if (!draft) return;

        const { meta, file } = draft;

        setSelectedSize(meta.size);
        setSelectedTier(meta.tier);
        setSelectedMountKey(meta.mount_key);
        setQuantity(meta.quantity || 1);

        setSelectedFile(file);
        const url = URL.createObjectURL(file);
        setPreviewUrl(url);

        await callAddToCartWithUpload(file, meta);
        await clearResumeDraft();

        params.delete("resume");
        const qs = params.toString();
        const newUrl = qs ? `${location.pathname}?${qs}` : location.pathname;
        window.history.replaceState({}, document.title, newUrl);

        navigate("/Checkout");
      } catch (e) {
        alert(e?.message || String(e));
      } finally {
        setResumeBusy(false);
      }
    };

    run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const total = useMemo(() => {
    const q = Math.max(1, Number(quantity) || 1);
    return (price * q).toFixed(2);
  }, [price, quantity]);

  return (
    <div style={{ maxWidth: 980, margin: "0 auto", padding: 24 }}>
      <h1 style={{ fontSize: 28, fontWeight: 700, marginBottom: 12 }}>Create Print</h1>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
        <div style={{ border: "1px solid #ddd", borderRadius: 12, padding: 16 }}>
          <h2 style={{ fontSize: 18, fontWeight: 700, marginBottom: 10 }}>1) Choose Image</h2>

          <input
            type="file"
            accept="image/*"
            onChange={(e) => {
              const f = e.target.files && e.target.files[0];
              if (!f) return;
              setSelectedFile(f);
              if (previewUrl) URL.revokeObjectURL(previewUrl);
              setPreviewUrl(URL.createObjectURL(f));
            }}
          />

          <div style={{ marginTop: 12 }}>
            {previewUrl ? (
              <div style={{ borderRadius: 12, overflow: "hidden", border: "1px solid #eee" }}>
                <img src={previewUrl} alt="preview" style={{ width: "100%", display: "block" }} />
              </div>
            ) : (
              <div style={{ fontSize: 13, opacity: 0.8 }}>
                Your photo is not uploaded until you create an account and add to cart.
              </div>
            )}
          </div>

          <button
            onClick={handleUploadClick}
            disabled={!selectedFile || busy || resumeBusy}
            style={{
              marginTop: 12,
              padding: "10px 12px",
              borderRadius: 10,
              border: "1px solid #ccc",
              cursor: !selectedFile || busy || resumeBusy ? "not-allowed" : "pointer",
              width: "100%",
            }}
          >
            Upload (requires account)
          </button>
        </div>

        <div style={{ border: "1px solid #ddd", borderRadius: 12, padding: 16 }}>
          <h2 style={{ fontSize: 18, fontWeight: 700, marginBottom: 10 }}>2) Configure</h2>

          <div style={{ display: "grid", gap: 10 }}>
            <label style={{ display: "grid", gap: 6 }}>
              <span style={{ fontSize: 13, opacity: 0.8 }}>Size</span>
              <select value={selectedSize} onChange={(e) => setSelectedSize(e.target.value)}>
                <option value="6x8">6x8</option>
                <option value="8x12">8x12</option>
                <option value="12x18">12x18</option>
              </select>
            </label>

            <label style={{ display: "grid", gap: 6 }}>
              <span style={{ fontSize: 13, opacity: 0.8 }}>Tier</span>
              <select value={selectedTier} onChange={(e) => setSelectedTier(e.target.value)}>
                <option value="standard">Standard</option>
                <option value="reserve">Reserve</option>
              </select>
            </label>

            <label style={{ display: "grid", gap: 6 }}>
              <span style={{ fontSize: 13, opacity: 0.8 }}>Mount</span>
              <select value={selectedMountKey} onChange={(e) => setSelectedMountKey(e.target.value)}>
                <option value="PURESHADOW_BLACK">PureShadow Black</option>
              </select>
            </label>

            <label style={{ display: "grid", gap: 6 }}>
              <span style={{ fontSize: 13, opacity: 0.8 }}>Quantity</span>
              <input
                type="number"
                min={1}
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value || "1", 10) || 1))}
              />
            </label>

            <div style={{ marginTop: 8, paddingTop: 10, borderTop: "1px solid #eee" }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ opacity: 0.8 }}>Estimated total</span>
                <strong>${total}</strong>
              </div>
              <div style={{ fontSize: 12, opacity: 0.7, marginTop: 6 }}>
                Final price is calculated from your PrintVariant pricing in checkout.
              </div>
            </div>

            <button
              onClick={handleAddToCart}
              disabled={!selectedFile || busy || resumeBusy}
              style={{
                marginTop: 6,
                padding: "12px 14px",
                borderRadius: 10,
                border: "1px solid #111",
                background: "#111",
                color: "white",
                cursor: !selectedFile || busy || resumeBusy ? "not-allowed" : "pointer",
              }}
            >
              {busy ? "Working..." : "Add to cart"}
            </button>
          </div>
        </div>
      </div>

      {gateOpen && (
        <div style={{ marginTop: 16, padding: 14, border: "1px solid #f0c36d", borderRadius: 10, background: "#fff7e6" }}>
          <div style={{ fontWeight: 700, marginBottom: 6 }}>Account required</div>
          <div style={{ fontSize: 13, opacity: 0.85 }}>
            To upload and order, you’ll need to sign in. We’ll save your selections so you can resume right after login.
          </div>
          <div style={{ display: "flex", gap: 10, marginTop: 10 }}>
            <button
              onClick={requireLoginWithResume}
              style={{ padding: "10px 12px", borderRadius: 10, border: "1px solid #111", background: "#111", color: "white" }}
            >
              Sign in & resume
            </button>
            <button
              onClick={() => setGateOpen(false)}
              style={{ padding: "10px 12px", borderRadius: 10, border: "1px solid #ccc", background: "white" }}
            >
              Not now
            </button>
          </div>
        </div>
      )}
    </div>
  );
}