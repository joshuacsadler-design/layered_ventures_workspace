import React, { useEffect, useMemo, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Loader2 } from "lucide-react";

export default function CheckoutSuccess() {
  const location = useLocation();
  const params = useMemo(() => new URLSearchParams(location.search), [location.search]);

  // Preferred: we can pass order_id in the URL (best reliability)
  const orderIdFromUrl = params.get("order_id") || params.get("orderId") || params.get("id");

  // Fallback: Stripe checkout session_id
  const sessionId = params.get("session_id");

  const [resolvedOrderId, setResolvedOrderId] = useState(orderIdFromUrl || null);
  const [resolving, setResolving] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function resolveOrderIdFromSession() {
      // If we already have an order id, we're done
      if (orderIdFromUrl) return;

      // If there's no session_id, we can't resolve
      if (!sessionId) return;

      setResolving(true);
      try {
        const auth = await base44.auth.isAuthenticated();
        if (!auth) {
          // no user session; can't safely look up
          return;
        }

        const user = await base44.auth.me();

        // Try a few common field names; whichever exists/works will resolve.
        const candidates = [
          { stripe_checkout_session_id: sessionId },
          { stripe_session_id: sessionId },
          { checkout_session_id: sessionId },
          { session_id: sessionId },
        ];

        for (const where of candidates) {
          try {
            const found = await base44.entities.Order.filter(
              { ...where, user_id: user.id },
              "-created_date"
            );
            if (found?.[0]?.id) {
              if (!cancelled) setResolvedOrderId(found[0].id);
              break;
            }
          } catch (e) {
            // If this field doesn't exist or filter fails, try next candidate
            continue;
          }
        }
      } catch (e) {
        console.error("CheckoutSuccess: failed to resolve order from session_id:", e);
      } finally {
        if (!cancelled) setResolving(false);
      }
    }

    resolveOrderIdFromSession();

    return () => {
      cancelled = true;
    };
  }, [orderIdFromUrl, sessionId]);

  const viewOrderHref = resolvedOrderId ? `/order-detail?id=${resolvedOrderId}` : null;

  return (
    <div className="min-h-[60vh] flex items-center justify-center px-4">
      <div className="max-w-lg w-full border rounded-2xl p-6 bg-white dark:bg-neutral-900">
        <h1 className="text-2xl font-semibold tracking-tight">Payment received</h1>
        <p className="mt-2 text-sm opacity-80">
          Thank you — your order is confirmed. We’ll review it and begin production.
        </p>

        {(sessionId || orderIdFromUrl) ? (
          <div className="mt-4 text-xs opacity-70 break-all space-y-2">
            {orderIdFromUrl ? (
              <div>
                <div className="font-semibold">Order</div>
                <div>{orderIdFromUrl}</div>
              </div>
            ) : null}

            {sessionId ? (
              <div>
                <div className="font-semibold">Session</div>
                <div>{sessionId}</div>
              </div>
            ) : null}
          </div>
        ) : null}

        {resolving ? (
          <div className="mt-5 flex items-center gap-2 text-sm opacity-80">
            <Loader2 className="w-4 h-4 animate-spin" />
            Resolving your order…
          </div>
        ) : null}

        <div className="mt-6 flex flex-wrap gap-3">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-xl px-4 py-2 text-sm font-medium border"
          >
            Go Home
          </Link>

          {viewOrderHref ? (
            <Link
              to={viewOrderHref}
              className="inline-flex items-center justify-center rounded-xl px-4 py-2 text-sm font-medium border"
            >
              View Order
            </Link>
          ) : (
            <Link
              to="/account"
              className="inline-flex items-center justify-center rounded-xl px-4 py-2 text-sm font-medium border"
            >
              View Orders
            </Link>
          )}
        </div>

        <p className="mt-6 text-xs opacity-70">
          If you don’t see updates immediately, refresh in a moment — the payment confirmation is
          finalized by the webhook.
        </p>
      </div>
    </div>
  );
}