import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { requireAuthOrQueueCartAdd } from "@/lib/pendingCart";
import { toast } from "@/components/ui/use-toast";

export default function Shop() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [selectedPrices, setSelectedPrices] = useState({});

  const { data, isLoading } = useQuery({
    queryKey: ["catalog-public"],
    queryFn: async () => (await base44.functions.invoke("getCatalogPublic", {})).data,
  });

  const addToCartMutation = useMutation({
    mutationFn: async ({ product, product_price_id }) => {
      const payload = await requireAuthOrQueueCartAdd(
        {
          kind: "product",
          product_id: product.id,
          product_price_id,
          quantity: 1,
        },
        "/Cart"
      );

      const resp = await base44.functions.invoke("addToCart", payload);
      return resp.data;
    },
    onSuccess: () => {
      toast({ title: "Added to cart" });
      qc.invalidateQueries({ queryKey: ["cart"] });
      navigate("/Cart");
    },
    onError: (err) => {
      if (err?.message === "AUTH_REDIRECT" || err?.code === "AUTH_REDIRECT") return;
      toast({
        variant: "destructive",
        title: "Could not add to cart",
        description: err?.message || "Please try again.",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  const printProduct = data?.printProduct;
  const nonPrintProducts = data?.nonPrintProducts ?? [];
  const productPrices = data?.productPrices ?? [];

  const getPricesForProduct = (productId) => {
    return productPrices.filter((pp) => pp.product_id === productId && pp.purchasable);
  };

  const getSelectedPrice = (productId) => {
    return selectedPrices[productId] || null;
  };

  const setSelectedPrice = (productId, priceId) => {
    setSelectedPrices({ ...selectedPrices, [productId]: priceId });
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-12 space-y-8">
      <div>
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Shop</h1>
        <p className="mt-2 text-lg text-muted-foreground">
          Professional metal prints and accessories.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {printProduct && (
          <Card className="flex flex-col">
            <CardHeader>
              <CardTitle>{printProduct.name}</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col justify-between gap-4">
              <div className="text-sm text-muted-foreground">
                {printProduct.short_description ??
                  "Upload your image and choose size, edition, and mount."}
              </div>
              <Button onClick={() => navigate("/CreatePrint")}>Start Creating</Button>
            </CardContent>
          </Card>
        )}

        {nonPrintProducts.map((product) => {
          const prices = getPricesForProduct(product.id);
          const selectedPriceId = getSelectedPrice(product.id);
          const hasMultiplePrices = prices.length > 1;
          const singlePrice = prices.length === 1 ? prices[0] : null;
          const minPrice = prices.length > 0 ? Math.min(...prices.map((p) => p.price_cents)) : 0;

          return (
            <Card key={product.id} className="flex flex-col">
              <CardHeader>
                <CardTitle>{product.name}</CardTitle>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col justify-between gap-4">
                <div className="text-sm text-muted-foreground">
                  {product.short_description ?? product.description ?? ""}
                </div>

                {prices.length === 0 ? (
                  <Button disabled>Temporarily unavailable</Button>
                ) : (
                  <>
                    {hasMultiplePrices && (
                      <div>
                        <label className="text-sm font-medium mb-2 block">Select Option</label>
                        <select
                          className="w-full border rounded-md p-2"
                          value={selectedPriceId || ""}
                          onChange={(e) => setSelectedPrice(product.id, e.target.value)}
                        >
                          <option value="">Choose...</option>
                          {prices.map((pp) => (
                            <option key={pp.id} value={pp.id}>
                              {pp.label || pp.sku} - ${(pp.price_cents / 100).toFixed(2)}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}

                    <div className="text-lg font-semibold">
                      {hasMultiplePrices
                        ? `From $${(minPrice / 100).toFixed(2)}`
                        : `$${(((singlePrice?.price_cents || 0) / 100).toFixed(2))}`}
                    </div>

                    <Button
                      onClick={() => {
                        const priceId = hasMultiplePrices ? selectedPriceId : singlePrice?.id;
                        if (!priceId) {
                          alert("Please select an option");
                          return;
                        }
                        addToCartMutation.mutate({ product, product_price_id: priceId });
                      }}
                      disabled={
                        addToCartMutation.isPending || (hasMultiplePrices && !selectedPriceId)
                      }
                    >
                      {addToCartMutation.isPending ? "Adding..." : "Add to cart"}
                    </Button>
                  </>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
