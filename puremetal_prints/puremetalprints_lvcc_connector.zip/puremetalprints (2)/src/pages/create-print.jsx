import { useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";

export default function CreatePrintRedirect() {
  const nav = useNavigate();
  const loc = useLocation();

  useEffect(() => {
    nav(`/CreatePrint${loc.search}`, { replace: true });
  }, [nav, loc.search]);

  return null;
}