// src/pages/Checkout.jsx
import React, { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";

import { Loader2, Tag, AlertCircle, CreditCard, ShieldCheck, Truck } from "lucide-react";

function extractBase44Error(err) {
  const msg =
    err?.response?.data?.error ||
    err?.response?.data?.message ||
    err?.data?.error ||
    err?.data?.message ||
    err?.message ||
    String(err);

  const status =
    err?.response?.status ||
    err?.status ||
    err?.response?.data?.status ||
    undefined;

  return { status, message: msg };
}

function isNonEmpty(s) {
  return typeof s === "string" && s.trim().length > 0;
}

function validateAddress(address) {
  const missing = [];
  if (!isNonEmpty(address.line1)) missing.push("Address line 1");
  if (!isNonEmpty(address.city)) missing.push("City");
  if (!isNonEmpty(address.state)) missing.push("State");
  if (!isNonEmpty(address.zip)) missing.push("ZIP");
  if (!isNonEmpty(address.country)) missing.push("Country");
  return missing;
}

export default function Checkout() {
  const navigate = useNavigate();

  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);

  const [licensingAccepted, setLicensingAccepted] = useState(false);
  const [galleryOptIn, setGalleryOptIn] = useState(false);

  // Contact + shipping details
  const [contact, setContact] = useState({
    full_name: "",
    email: "",
    phone: "",
  });

  const [address, setAddress] = useState({
    line1: "",
    line2: "",
    city: "",
    state: "",
    zip: "",
    country: "US",
  });

  const [promoCode, setPromoCode] = useState("");
  const [promoApplied, setPromoApplied] = useState(null);

  const queryClient = useQueryClient();

  useEffect(() => {
    const run = async () => {
      const me = await base44.auth.me().catch(() => null);
      if (!me) {
        const returnUrl = `${window.location.origin}/Checkout`;
        base44.auth.redirectToLogin(returnUrl);
        return;
      }
      setUser(me);

      // Prefill email/name when possible
      setContact((prev) => ({
        ...prev,
        full_name: prev.full_name || me?.full_name || me?.name || "",
        email: prev.email || me?.email || "",
      }));
    };
    run();
  }, []);

  const { data: draftOrders = [] } = useQuery({
    queryKey: ["checkout-orders", user?.id],
    queryFn: () => base44.entities.Order.filter({ user_id: user.id, status: "DRAFT" }),
    enabled: !!user,
  });

  const order = draftOrders?.[0] || null;

  const { data: items = [] } = useQuery({
    queryKey: ["checkout-items", order?.id],
    queryFn: () => base44.entities.OrderItem.filter({ order_id: order.id }),
    enabled: !!order?.id,
  });

  // Licensing only required for print items (revenue-critical fix)
  const requiresLicense = useMemo(() => {
    return (items || []).some((i) => i?.kind === "print");
  }, [items]);

  const applyPromoMutation = useMutation({
    mutationFn: async (code) => {
      const response = await base44.functions.invoke("applyCouponToDraftOrder", { code });
      return response.data;
    },
    onSuccess: (data) => {
      setPromoApplied(data);
      queryClient.invalidateQueries({ queryKey: ["checkout-orders"] });
      alert(`Promo applied: ${data.coupon_name}`);
    },
    onError: (error) => {
      console.error("applyCouponToDraftOrder error:", error);
      alert(`Promo error: ${error?.message || String(error)}`);
    },
  });

  const subtotal = useMemo(() => {
    return items.reduce((s, i) => {
      const unit =
        i.unit_price_cents != null
          ? Number(i.unit_price_cents) / 100
          : i.unit_price != null
          ? Number(i.unit_price)
          : 0;
      const qty = i.quantity != null ? Number(i.quantity) : 1;
      return s + unit * qty;
    }, 0);
  }, [items]);

  const discount = promoApplied?.discount || 0;

  // Shipping/tax estimates (business can later replace with real shipping calculator)
  const shippingEst = 0;
  const taxEst = 0;

  const total = Math.max(0, subtotal - discount + shippingEst + taxEst);

  const handleApplyPromo = () => {
    if (!promoCode.trim()) return;
    applyPromoMutation.mutate(promoCode.trim());
  };

  // Save checkout details (client + shipping) BEFORE creating Stripe session
  const saveDetailsMutation = useMutation({
    mutationFn: async () => {
      if (!order?.id) throw new Error("No draft order found.");
      const resp = await base44.functions.invoke("setCheckoutDetails", {
        orderId: order.id,
        client: {
          full_name: contact.full_name,
          email: contact.email,
          phone: contact.phone,
        },
        shipping_address: address,
        gallery_opt_in: !!galleryOptIn,

        // If the cart does not contain print items, licensing is not applicable.
        // We send true to avoid storing a misleading false on non-print orders.
        licensing_accepted: requiresLicense ? !!licensingAccepted : true,
      });
      return resp.data;
    },
  });

  const createSessionMutation = useMutation({
    mutationFn: async () => {
      if (!order?.id) throw new Error("No draft order found.");
      const resp = await base44.functions.invoke("createCheckoutSession", { orderId: order.id });
      return resp.data;
    },
  });

  const handleCheckout = async () => {
    // Licensing gate should only apply if prints are in the cart.
    if (requiresLicense && !licensingAccepted) return;

    if (!order?.id) {
      alert("No items in cart");
      return;
    }

    // Validate client + shipping fields
    const missing = [];
    if (!isNonEmpty(contact.full_name)) missing.push("Full name");
    if (!isNonEmpty(contact.email)) missing.push("Email");
    // phone optional but recommended

    const addrMissing = validateAddress(address);
    missing.push(...addrMissing);

    if (missing.length > 0) {
      alert(`Please complete:\n\n- ${missing.join("\n- ")}`);
      return;
    }

    setLoading(true);
    try {
      // 1) Persist client + shipping data to Order (and link/create Client)
      await saveDetailsMutation.mutateAsync();

      // 2) Create Stripe session (server will hard-validate too)
      const { url } = await createSessionMutation.mutateAsync();
      if (!url) throw new Error("No checkout URL returned.");
      window.location.href = url;
    } catch (err) {
      const info = extractBase44Error(err);
      console.error("Checkout FAILED:", err);
      alert(
        `Checkout failed${info.status ? ` (HTTP ${info.status})` : ""}:\n\n${info.message}\n\nOpen DevTools Console for full details.`,
      );
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div style={{ maxWidth: 900, margin: "0 auto", padding: 24 }}>
        <p>Checking authentication…</p>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 900, margin: "0 auto", padding: 24 }}>
      <h1 style={{ fontSize: 28, fontWeight: 700, marginBottom: 12 }}>Checkout</h1>

      <div style={{ display: "grid", gap: 14 }}>
        <div style={{ border: "1px solid #e5e5e5", borderRadius: 12, padding: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
            <CreditCard className="w-4 h-4" />
            <h2 style={{ fontSize: 18, fontWeight: 700 }}>Your Cart</h2>
          </div>

          {items.length === 0 ? (
            <div style={{ opacity: 0.75 }}>Your cart is empty.</div>
          ) : (
            <div style={{ display: "grid", gap: 10 }}>
              {items.map((i) => (
                <div
                  key={i.id}
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    borderBottom: "1px solid #f0f0f0",
                    paddingBottom: 8,
                  }}
                >
                  <div>
                    <div style={{ fontWeight: 600 }}>{i.title || i.sku || "Item"}</div>
                    <div style={{ fontSize: 12, opacity: 0.75 }}>Qty: {i.quantity ?? 1}</div>
                  </div>
                  <div style={{ fontWeight: 700 }}>
                    $
                    {(
                      ((i.unit_price_cents != null ? Number(i.unit_price_cents) / 100 : Number(i.unit_price || 0)) *
                        (i.quantity ?? 1)) ||
                      0
                    ).toFixed(2)}
                  </div>
                </div>
              ))}

              <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
                <span style={{ opacity: 0.8 }}>Subtotal</span>
                <strong>${subtotal.toFixed(2)}</strong>
              </div>

              {discount > 0 && (
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ opacity: 0.8 }}>Discount</span>
                  <strong>-${discount.toFixed(2)}</strong>
                </div>
              )}

              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ opacity: 0.8 }}>Shipping (est.)</span>
                <strong>${shippingEst.toFixed(2)}</strong>
              </div>

              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ opacity: 0.8 }}>Tax (est.)</span>
                <strong>${taxEst.toFixed(2)}</strong>
              </div>

              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ opacity: 0.8 }}>Total (est.)</span>
                <strong>${total.toFixed(2)}</strong>
              </div>
            </div>
          )}
        </div>

        <div style={{ border: "1px solid #e5e5e5", borderRadius: 12, padding: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
            <Truck className="w-4 h-4" />
            <h2 style={{ fontSize: 18, fontWeight: 700 }}>Contact & Shipping</h2>
          </div>

          <div style={{ display: "grid", gap: 10 }}>
            <div>
              <Label>Full Name</Label>
              <Input
                value={contact.full_name}
                onChange={(e) => setContact((p) => ({ ...p, full_name: e.target.value }))}
                placeholder="Full name"
              />
            </div>

            <div>
              <Label>Email</Label>
              <Input
                value={contact.email}
                onChange={(e) => setContact((p) => ({ ...p, email: e.target.value }))}
                placeholder="Email"
              />
            </div>

            <div>
              <Label>Phone (recommended)</Label>
              <Input
                value={contact.phone}
                onChange={(e) => setContact((p) => ({ ...p, phone: e.target.value }))}
                placeholder="Phone"
              />
            </div>

            <div>
              <Label>Address line 1</Label>
              <Input value={address.line1} onChange={(e) => setAddress((p) => ({ ...p, line1: e.target.value }))} />
            </div>

            <div>
              <Label>Address line 2</Label>
              <Input value={address.line2} onChange={(e) => setAddress((p) => ({ ...p, line2: e.target.value }))} />
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              <div>
                <Label>City</Label>
                <Input value={address.city} onChange={(e) => setAddress((p) => ({ ...p, city: e.target.value }))} />
              </div>
              <div>
                <Label>State</Label>
                <Input value={address.state} onChange={(e) => setAddress((p) => ({ ...p, state: e.target.value }))} />
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              <div>
                <Label>ZIP</Label>
                <Input value={address.zip} onChange={(e) => setAddress((p) => ({ ...p, zip: e.target.value }))} />
              </div>
              <div>
                <Label>Country</Label>
                <Input
                  value={address.country}
                  onChange={(e) => setAddress((p) => ({ ...p, country: e.target.value }))}
                  placeholder="US"
                />
              </div>
            </div>
          </div>
        </div>

        <div style={{ border: "1px solid #e5e5e5", borderRadius: 12, padding: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
            <Tag className="w-4 h-4" />
            <h2 style={{ fontSize: 18, fontWeight: 700 }}>Promo Code</h2>
          </div>

          <div style={{ display: "flex", gap: 10 }}>
            <Input value={promoCode} onChange={(e) => setPromoCode(e.target.value)} placeholder="Enter code" />
            <Button onClick={handleApplyPromo} disabled={applyPromoMutation.isPending}>
              {applyPromoMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Apply"}
            </Button>
          </div>
        </div>

        {/* Licensing should only appear when required (prints in cart) */}
        {requiresLicense && (
          <div style={{ border: "1px solid #e5e5e5", borderRadius: 12, padding: 16 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
              <ShieldCheck className="w-4 h-4" />
              <h2 style={{ fontSize: 18, fontWeight: 700 }}>Licensing</h2>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <Checkbox checked={licensingAccepted} onCheckedChange={(v) => setLicensingAccepted(!!v)} />
              <Label>I confirm I have the rights to print this image.</Label>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 10 }}>
              <Checkbox checked={galleryOptIn} onCheckedChange={(v) => setGalleryOptIn(!!v)} />
              <Label>Allow PureMetal Prints to showcase my print in the gallery (optional).</Label>
            </div>

            {!licensingAccepted && (
              <div style={{ display: "flex", gap: 8, marginTop: 10, color: "#b45309" }}>
                <AlertCircle className="w-4 h-4" />
                <span style={{ fontSize: 12 }}>You must accept licensing to continue.</span>
              </div>
            )}
          </div>
        )}

        <Button
          onClick={handleCheckout}
          disabled={
            loading ||
            items.length === 0 ||
            (requiresLicense && !licensingAccepted) ||
            saveDetailsMutation.isPending
          }
        >
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Proceed to Payment"}
        </Button>
      </div>
    </div>
  );
}