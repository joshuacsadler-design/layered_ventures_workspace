import React, { useEffect } from "react";
import Navbar from "./components/layout/Navbar";
import Footer from "./components/layout/Footer";
import { runQueuedCartAddIfAny } from "@/lib/pendingCart";
import { base44 } from "@/api/base44Client";
import { toast } from "@/components/ui/use-toast";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

function CartResumeGate() {
  const { isAuthenticated, isLoadingAuth } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (isLoadingAuth) return;
    if (!isAuthenticated) return;

    (async () => {
      try {
        const res = await runQueuedCartAddIfAny(async (payload) => {
          const resp = await base44.functions.invoke("addToCart", payload);
          return resp.data;
        });

        if (res?.returnUrl) {
          toast({ title: "Added to cart" });
          navigate(res.returnUrl);
        }
      } catch (e) {
        toast({
          variant: "destructive",
          title: "Cart action failed",
          description: e?.message || "Please try again.",
        });
      }
    })();
  }, [isAuthenticated, isLoadingAuth, navigate]);

  return null;
}

export default function Layout({ children, currentPageName }) {
  const isAdmin = currentPageName?.startsWith("Admin");
  const isPrintPage = currentPageName === "ProductionSheet";

  if (isPrintPage) {
    return <div className="min-h-screen">{children}</div>;
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: "var(--pm-bg)" }}>
      <Navbar />
      <CartResumeGate />
      <main className="flex-1">{children}</main>
      {!isAdmin && <Footer />}
    </div>
  );
}