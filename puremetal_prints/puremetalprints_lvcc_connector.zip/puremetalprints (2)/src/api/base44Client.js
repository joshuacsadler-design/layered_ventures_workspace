// src/api/base44Client.js
import { createClient } from "@base44/sdk";
import { appParams } from "@/lib/app-params";

// NOTE:
// We intentionally do NOT force authentication globally.
// Anonymous browsing must work (Home page is public).
// If a request is unauthorized (401/403), we do NOT auto-redirect here.
// Protected pages should explicitly call base44.auth.redirectToLogin(...).

const { appId, token, functionsVersion, appBaseUrl } = appParams;

// Optional: normalize token (Base44 SDK expects a string token if present)
const normalizedToken = token && String(token).trim().length > 0 ? String(token) : undefined;

// IMPORTANT:
// Do NOT pin functionsVersion in production. Pinning can cause 404 "Deployment does not exist"
// if the version points at an old/nonexistent deployment.
// We allow functionsVersion ONLY as a temporary URL override in DEV.
const allowPinnedFunctionsVersion =
  !!import.meta.env.DEV && functionsVersion && String(functionsVersion).trim().length > 0;

const clientConfig = {
  appId,
  token: normalizedToken,
  appBaseUrl,

  // CRITICAL: do not force-auth the entire app
  requiresAuth: false,

  ...(allowPinnedFunctionsVersion ? { functionsVersion: String(functionsVersion) } : {}),

  // CRITICAL: swallow expected "logged out" errors so the SDK doesn't try to redirect
  options: {
    onError: (err) => {
      const status = err?.status || err?.response?.status;
      if (status === 401 || status === 403) {
        // Logged out / forbidden for non-public entities is normal on public pages.
        // Do NOT redirect here.
        return;
      }
      // Keep logging for real errors
      // eslint-disable-next-line no-console
      console.error("Base44 SDK error:", err);
    },
  },
};

export const base44 = createClient(clientConfig);
window.base44Debug = base44;