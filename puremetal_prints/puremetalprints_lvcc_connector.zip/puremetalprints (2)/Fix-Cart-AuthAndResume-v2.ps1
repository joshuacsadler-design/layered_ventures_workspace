# Fix-Cart-AuthAndResume-v2.ps1
# Run from repo root:
#   powershell -ExecutionPolicy Bypass -File .\Fix-Cart-AuthAndResume-v2.ps1

$ErrorActionPreference = "Stop"

function Write-FileUtf8NoBom($path, $content) {
  $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($path, $content, $utf8NoBom)
}

function Ensure-Import($path, $importLine, $anchorRegex) {
  $txt = Get-Content $path -Raw
  if ($txt -match [regex]::Escape($importLine)) { return $txt }
  $m = [regex]::Match($txt, $anchorRegex, [System.Text.RegularExpressions.RegexOptions]::Multiline)
  if (!$m.Success) { throw "Couldn't find import anchor in $path to insert: $importLine" }
  $insertAt = $m.Index + $m.Length
  return $txt.Insert($insertAt, "`n$importLine")
}

function Ensure-Imports($path) {
  $txt = Get-Content $path -Raw

  # Ensure base44 import exists (we anchor after it if possible)
  if ($txt -notmatch 'from\s+"@/api/base44Client"') {
    throw "Expected base44Client import not found in $path"
  }

  # Insert pendingCart + toast near base44 import if missing
  if ($txt -notmatch 'from\s+"@/lib/pendingCart"') {
    $txt = $txt -replace '(import\s+\{\s*base44\s*\}\s+from\s+"@/api/base44Client";)', "`$1`nimport { requireAuthOrQueueCartAdd } from `"`@/lib/pendingCart`";"
  }

  if ($txt -notmatch 'use-toast') {
    # only add toast import if file uses toast later (we will)
    $txt = $txt -replace '(import\s+\{\s*base44\s*\}\s+from\s+"@/api/base44Client";[^\r\n]*\r?\n(?:import.*\r?\n)*)', "`$1import { toast } from `"`@/components/ui/use-toast`";`n"
  }

  Write-FileUtf8NoBom $path $txt
}

function Patch-CreatePrint($path) {
  $txt = Get-Content $path -Raw

  # Find the addToCart useMutation block, replace mutationFn + onSuccess + onError
  # This is intentionally flexible: it looks for "const addToCart = useMutation({ ... })"
  $pattern = '(const\s+addToCart\s*=\s*useMutation\(\{\s*)([\s\S]*?)(\}\)\s*;)'
  $m = [regex]::Match($txt, $pattern)
  if (!$m.Success) { throw "Could not find addToCart useMutation block in $path" }

  $block = $m.Groups[2].Value

  # Replace/insert mutationFn: we try to locate "mutationFn: async" and replace its body.
  if ($block -notmatch 'mutationFn\s*:\s*async') {
    throw "addToCart useMutation block found, but no mutationFn: async in $path"
  }

  # Extract payload keys from existing invoke("addToCart", { ... })
  $invokeMatch = [regex]::Match($block, 'base44\.functions\.invoke\(\s*["'']addToCart["'']\s*,\s*\{([\s\S]*?)\}\s*\)')
  if (!$invokeMatch.Success) {
    throw "Found addToCart mutation, but couldn't locate base44.functions.invoke('addToCart', {...}) in $path"
  }
  $payloadInner = $invokeMatch.Groups[1].Value.Trim()

  $newMutationFn = @"
mutationFn: async () => {
      const payload = await requireAuthOrQueueCartAdd({
$payloadInner
      }, "/cart");

      const resp = await base44.functions.invoke("addToCart", payload);
      return resp.data;
    },
"@

  # Replace the existing mutationFn block (from "mutationFn:" up to the next top-level comma after the function)
  $block2 = [regex]::Replace(
    $block,
    'mutationFn\s*:\s*async\s*\(\s*\)\s*=>\s*\{[\s\S]*?\}\s*,',
    $newMutationFn,
    1
  )

  # Force onSuccess to toast + navigate
  if ($block2 -match 'onSuccess\s*:') {
    $block2 = [regex]::Replace(
      $block2,
      'onSuccess\s*:\s*\([\s\S]*?\)\s*=>\s*\{[\s\S]*?\}\s*,',
@"
onSuccess: () => {
      toast({ title: "Added to cart" });
      navigate("/cart");
    },
"@,
      1
    )
  } else {
    $block2 = $block2 + @"
    onSuccess: () => {
      toast({ title: "Added to cart" });
      navigate("/cart");
    },
"@
  }

  # Add onError handler if missing
  if ($block2 -notmatch 'onError\s*:') {
    $block2 = $block2 + @"
    onError: (err) => {
      if (err?.message === "AUTH_REDIRECT" || err?.code === "AUTH_REDIRECT") return;
      toast({
        variant: "destructive",
        title: "Could not add to cart",
        description: err?.message || "Please try again.",
      });
    },
"@
  }

  $txt2 = $txt.Substring(0, $m.Groups[2].Index) + $block2 + $txt.Substring($m.Groups[2].Index + $m.Groups[2].Length)
  Write-FileUtf8NoBom $path $txt2
}

function Patch-Shop($path) {
  $txt = Get-Content $path -Raw

  $pattern = '(const\s+addToCartMutation\s*=\s*useMutation\(\{\s*)([\s\S]*?)(\}\)\s*;)'
  $m = [regex]::Match($txt, $pattern)
  if (!$m.Success) { throw "Could not find addToCartMutation useMutation block in $path" }

  $block = $m.Groups[2].Value

  $invokeMatch = [regex]::Match($block, 'base44\.functions\.invoke\(\s*["'']addToCart["'']\s*,\s*\{([\s\S]*?)\}\s*\)')
  if (!$invokeMatch.Success) {
    throw "Found addToCartMutation, but couldn't locate base44.functions.invoke('addToCart', {...}) in $path"
  }
  $payloadInner = $invokeMatch.Groups[1].Value.Trim()

  $newMutationFn = @"
mutationFn: async (args) => {
      // preserve original destructuring via existing payload inner block
      const payload = await requireAuthOrQueueCartAdd({
$payloadInner
      }, "/cart");

      const resp = await base44.functions.invoke("addToCart", payload);
      return resp.data;
    },
"@

  $block2 = [regex]::Replace(
    $block,
    'mutationFn\s*:\s*async\s*\([\s\S]*?\)\s*=>\s*\{[\s\S]*?\}\s*,',
    $newMutationFn,
    1
  )

  # Ensure onSuccess shows toast + keep existing invalidations if present
  if ($block2 -match 'onSuccess\s*:') {
    $block2 = [regex]::Replace(
      $block2,
      'onSuccess\s*:\s*\([\s\S]*?\)\s*=>\s*\{',
      'onSuccess: () => {`n      toast({ title: "Added to cart" });',
      1
    )
  } else {
    $block2 = $block2 + @"
    onSuccess: () => {
      toast({ title: "Added to cart" });
      navigate("/cart");
    },
"@
  }

  # Add onError if missing
  if ($block2 -notmatch 'onError\s*:') {
    $block2 = $block2 + @"
    onError: (err) => {
      if (err?.message === "AUTH_REDIRECT" || err?.code === "AUTH_REDIRECT") return;
      toast({
        variant: "destructive",
        title: "Could not add to cart",
        description: err?.message || "Please try again.",
      });
    },
"@
  }

  $txt2 = $txt.Substring(0, $m.Groups[2].Index) + $block2 + $txt.Substring($m.Groups[2].Index + $m.Groups[2].Length)
  Write-FileUtf8NoBom $path $txt2
}

function Ensure-PendingCartFile() {
  $path = "src/lib/pendingCart.js"
  $content = @'
import { base44 } from "@/api/base44Client";

const KEY = "pm_pending_cart_add";

export async function requireAuthOrQueueCartAdd(payload, returnUrl = "/cart") {
  const authed = await base44.auth.isAuthenticated();
  if (authed) return payload;

  localStorage.setItem(KEY, JSON.stringify({ payload, returnUrl }));
  base44.auth.redirectToLogin(window.location.href);

  const err = new Error("AUTH_REDIRECT");
  err.code = "AUTH_REDIRECT";
  throw err;
}

export async function runQueuedCartAddIfAny(invokeFn) {
  const raw = localStorage.getItem(KEY);
  if (!raw) return null;

  const { payload, returnUrl } = JSON.parse(raw);
  localStorage.removeItem(KEY);
  const result = await invokeFn(payload);
  return { result, returnUrl: returnUrl || "/cart" };
}
'@
  if (!(Test-Path "src/lib")) { New-Item -ItemType Directory -Path "src/lib" | Out-Null }
  Write-FileUtf8NoBom $path $content
}

function Patch-Layout() {
  $path = "src/Layout.jsx"
  if (!(Test-Path $path)) {
    Write-Host "Layout.jsx not found, skipping layout patch." -ForegroundColor Yellow
    return
  }

  $txt = Get-Content $path -Raw
  if ($txt -match 'CartResumeGate' -and $txt -match 'runQueuedCartAddIfAny') {
    Write-Host "Layout already patched, skipping." -ForegroundColor Yellow
    return
  }

  $newLayout = @'
import React, { useEffect } from "react";
import Navbar from "./components/layout/Navbar";
import Footer from "./components/layout/Footer";
import { runQueuedCartAddIfAny } from "@/lib/pendingCart";
import { base44 } from "@/api/base44Client";
import { toast } from "@/components/ui/use-toast";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

function CartResumeGate() {
  const { isAuthenticated, isLoadingAuth } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (isLoadingAuth) return;
    if (!isAuthenticated) return;

    (async () => {
      try {
        const res = await runQueuedCartAddIfAny(async (payload) => {
          const resp = await base44.functions.invoke("addToCart", payload);
          return resp.data;
        });

        if (res?.returnUrl) {
          toast({ title: "Added to cart" });
          navigate(res.returnUrl);
        }
      } catch (e) {
        toast({
          variant: "destructive",
          title: "Cart action failed",
          description: e?.message || "Please try again.",
        });
      }
    })();
  }, [isAuthenticated, isLoadingAuth, navigate]);

  return null;
}

export default function Layout({ children, currentPageName }) {
  const isAdmin = currentPageName?.startsWith("Admin");
  const isPrintPage = currentPageName === "ProductionSheet";

  if (isPrintPage) {
    return <div className="min-h-screen">{children}</div>;
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: "var(--pm-bg)" }}>
      <Navbar />
      <CartResumeGate />
      <main className="flex-1">{children}</main>
      {!isAdmin && <Footer />}
    </div>
  );
}
'@
  Write-FileUtf8NoBom $path $newLayout
}

Write-Host "==> Writing canonical pendingCart.js..." -ForegroundColor Cyan
Ensure-PendingCartFile
Write-Host "   OK" -ForegroundColor Green

Write-Host "==> Patching CreatePrint.jsx (regex)..." -ForegroundColor Cyan
Ensure-Imports "src/pages/CreatePrint.jsx"
Patch-CreatePrint "src/pages/CreatePrint.jsx"
Write-Host "   OK" -ForegroundColor Green

Write-Host "==> Patching Shop.jsx (regex)..." -ForegroundColor Cyan
Ensure-Imports "src/pages/Shop.jsx"
Patch-Shop "src/pages/Shop.jsx"
Write-Host "   OK" -ForegroundColor Green

Write-Host "==> Patching Layout.jsx (resume queued cart add)..." -ForegroundColor Cyan
Patch-Layout
Write-Host "   OK (or skipped)" -ForegroundColor Green

Write-Host ""
Write-Host "DONE. Now run: npm install; npm run dev" -ForegroundColor Green
Write-Host "Test: incognito -> add to cart -> redirect to login -> login -> auto-add -> /cart" -ForegroundColor Cyan
