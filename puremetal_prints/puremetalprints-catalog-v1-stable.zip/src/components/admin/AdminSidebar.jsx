import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Home, Package, Users, ShoppingCart, Settings, LayoutDashboard, XCircle, Truck, FileText, Image, Box, Wrench, Tag } from "lucide-react";

const navItems = [
  { label: "Dashboard", page: "AdminDashboard", icon: LayoutDashboard },
  { label: "Orders", page: "AdminOrders", icon: Package },
  { label: "Products", page: "AdminProducts", icon: ShoppingCart },
  { label: "Gallery Manager", page: "AdminGallery", icon: Image },
  { label: "Mounts", page: "AdminMounts", icon: Box },
  { label: "Services", page: "AdminServices", icon: Wrench },
  { label: "Coupons", page: "AdminCoupons", icon: Tag },
  { label: "Site Content", page: "AdminSiteContent", icon: FileText },
  { label: "Shipping", page: "AdminShipping", icon: Truck },
  { label: "Cancellations", page: "AdminCancellations", icon: XCircle },
  { label: "Clients", page: "AdminClients", icon: Users },
  { label: "Settings", page: "AdminSettings", icon: Settings },
];

export default function AdminSidebar() {
  const location = useLocation();
  const currentPage = location.pathname.split('/').pop()?.split('?')[0] || '';

  return (
    <aside className="w-64 border-r flex-shrink-0 flex flex-col" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}>
      <div className="p-6 border-b" style={{ borderColor: "var(--pm-border)" }}>
        <Link to={createPageUrl("Home")} className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-neutral-900 dark:bg-white flex items-center justify-center">
            <span className="text-white dark:text-black font-bold text-sm">PM</span>
          </div>
          <div>
            <p className="font-semibold text-sm">PureMetal Prints</p>
            <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>Admin Portal</p>
          </div>
        </Link>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => {
          const isActive = currentPage === item.page;
          return (
            <Link
              key={item.page}
              to={createPageUrl(item.page)}
              className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                isActive
                  ? "bg-neutral-900 text-white dark:bg-white dark:text-black font-medium"
                  : "hover:bg-neutral-100 dark:hover:bg-neutral-800"
              }`}
            >
              <item.icon className="w-4 h-4" />
              <span className="text-sm">{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t" style={{ borderColor: "var(--pm-border)" }}>
        <Link
          to={createPageUrl("Home")}
          className="flex items-center gap-2 px-3 py-2 text-sm rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
          style={{ color: "var(--pm-text-muted)" }}
        >
          <Home className="w-4 h-4" />
          <span>View Site</span>
        </Link>
      </div>
    </aside>
  );
}