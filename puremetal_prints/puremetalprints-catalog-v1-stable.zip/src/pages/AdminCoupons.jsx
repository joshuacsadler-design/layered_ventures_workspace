import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Plus, X } from "lucide-react";
import AdminLayout from "@/components/admin/AdminLayout";
import PMBadge from "@/components/ui/PMBadge";

export default function AdminCoupons() {
  const [user, setUser] = useState(null);
  const [creating, setCreating] = useState(false);
  
  const [newCoupon, setNewCoupon] = useState({
    name: '',
    discount_type: 'PERCENT',
    percent_off: 0,
    amount_off: 0,
    min_order_amount: null,
    max_redemptions: null,
    active: true,
  });

  const queryClient = useQueryClient();

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      const me = await base44.auth.me();
      if (me.role !== "admin") { window.location.href = "/"; return; }
      setUser(me);
    })();
  }, []);

  const { data: coupons = [], isLoading } = useQuery({
    queryKey: ["admin-coupons"],
    queryFn: () => base44.asServiceRole.entities.Coupon.list(),
    enabled: !!user,
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      const response = await base44.functions.invoke("createCouponAdmin", data);
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-coupons"]);
      setCreating(false);
      setNewCoupon({
        name: '',
        discount_type: 'PERCENT',
        percent_off: 0,
        amount_off: 0,
        min_order_amount: null,
        max_redemptions: null,
        active: true,
      });
      alert("Coupon created!");
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      await base44.asServiceRole.entities.Coupon.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-coupons"]);
    },
  });

  const handleCreate = () => {
    if (!newCoupon.name) {
      alert("Coupon name is required");
      return;
    }
    createMutation.mutate(newCoupon);
  };

  if (!user) return <div className="flex items-center justify-center min-h-screen"><Loader2 className="w-8 h-8 animate-spin" /></div>;

  return (
    <AdminLayout 
      title="Coupons"
      actions={
        <Button onClick={() => setCreating(true)} size="sm">
          <Plus className="w-4 h-4 mr-2" />
          New Coupon
        </Button>
      }
    >
      <div className="space-y-6">
        {creating && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Create New Coupon</CardTitle>
                <Button variant="ghost" size="icon" onClick={() => setCreating(false)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">Name *</label>
                <Input
                  value={newCoupon.name}
                  onChange={(e) => setNewCoupon({ ...newCoupon, name: e.target.value })}
                  placeholder="Spring Sale 2026"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Discount Type</label>
                <Select value={newCoupon.discount_type} onValueChange={(v) => setNewCoupon({ ...newCoupon, discount_type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PERCENT">Percent Off</SelectItem>
                    <SelectItem value="AMOUNT">Amount Off</SelectItem>
                    <SelectItem value="FREE_SHIPPING">Free Shipping</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {newCoupon.discount_type === 'PERCENT' && (
                <div>
                  <label className="text-sm font-medium">Percent Off (%)</label>
                  <Input
                    type="number"
                    value={newCoupon.percent_off}
                    onChange={(e) => setNewCoupon({ ...newCoupon, percent_off: parseFloat(e.target.value) })}
                  />
                </div>
              )}
              {newCoupon.discount_type === 'AMOUNT' && (
                <div>
                  <label className="text-sm font-medium">Amount Off ($)</label>
                  <Input
                    type="number"
                    step="0.01"
                    value={newCoupon.amount_off}
                    onChange={(e) => setNewCoupon({ ...newCoupon, amount_off: parseFloat(e.target.value) })}
                  />
                </div>
              )}
              <div>
                <label className="text-sm font-medium">Min Order Amount ($)</label>
                <Input
                  type="number"
                  step="0.01"
                  value={newCoupon.min_order_amount || ''}
                  onChange={(e) => setNewCoupon({ ...newCoupon, min_order_amount: e.target.value ? parseFloat(e.target.value) : null })}
                  placeholder="Optional"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Max Redemptions</label>
                <Input
                  type="number"
                  value={newCoupon.max_redemptions || ''}
                  onChange={(e) => setNewCoupon({ ...newCoupon, max_redemptions: e.target.value ? parseInt(e.target.value) : null })}
                  placeholder="Unlimited"
                />
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  checked={newCoupon.active}
                  onCheckedChange={(v) => setNewCoupon({ ...newCoupon, active: v })}
                />
                <span className="text-sm">Active</span>
              </div>
              <div className="flex gap-2">
                <Button onClick={handleCreate} disabled={createMutation.isPending}>
                  {createMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                  Create
                </Button>
                <Button variant="outline" onClick={() => setCreating(false)}>Cancel</Button>
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Coupons ({coupons.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin" />
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ borderBottom: "1px solid var(--pm-border)" }}>
                      <th className="text-left py-2 px-3">Code</th>
                      <th className="text-left py-2 px-3">Name</th>
                      <th className="text-left py-2 px-3">Type</th>
                      <th className="text-left py-2 px-3">Value</th>
                      <th className="text-left py-2 px-3">Redemptions</th>
                      <th className="text-left py-2 px-3">Active</th>
                    </tr>
                  </thead>
                  <tbody>
                    {coupons.map((coupon) => (
                      <tr key={coupon.id} style={{ borderBottom: "1px solid var(--pm-border)" }}>
                        <td className="py-2 px-3 font-mono text-xs font-semibold">{coupon.code}</td>
                        <td className="py-2 px-3">{coupon.name}</td>
                        <td className="py-2 px-3">
                          <PMBadge variant="purple">{coupon.discount_type}</PMBadge>
                        </td>
                        <td className="py-2 px-3">
                          {coupon.discount_type === 'PERCENT' && `${coupon.percent_off}%`}
                          {coupon.discount_type === 'AMOUNT' && `$${coupon.amount_off}`}
                          {coupon.discount_type === 'FREE_SHIPPING' && 'Free Ship'}
                        </td>
                        <td className="py-2 px-3">
                          {coupon.redemption_count} / {coupon.max_redemptions || '∞'}
                        </td>
                        <td className="py-2 px-3">
                          <Switch
                            checked={coupon.active}
                            onCheckedChange={(v) => updateMutation.mutate({ id: coupon.id, data: { active: v } })}
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}