import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Loader2, RefreshCw, Plus, X } from "lucide-react";
import AdminLayout from "@/components/admin/AdminLayout";
import PMBadge from "@/components/ui/PMBadge";

export default function AdminMounts() {
  const [user, setUser] = useState(null);
  const [creating, setCreating] = useState(false);
  
  const [newMount, setNewMount] = useState({
    brand_slug: 'PURESHADOW',
    mount_type: '',
    label: '',
    description: '',
    price_addon: 0,
    active: true,
    sort_order: 0,
  });

  const queryClient = useQueryClient();

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      const me = await base44.auth.me();
      if (me.role !== "admin") { window.location.href = "/"; return; }
      setUser(me);
    })();
  }, []);

  const { data: mounts = [], isLoading } = useQuery({
    queryKey: ["admin-mounts"],
    queryFn: () => base44.asServiceRole.entities.MountOffering.list(),
    enabled: !!user,
  });

  const seedDefaults = useMutation({
    mutationFn: async () => {
      const response = await base44.functions.invoke("ensureMountDefaults", {});
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-mounts"]);
      alert("Mount defaults created!");
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      const response = await base44.functions.invoke("createMountAdmin", data);
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-mounts"]);
      setCreating(false);
      setNewMount({
        brand_slug: 'PURESHADOW',
        mount_type: '',
        label: '',
        description: '',
        price_addon: 0,
        active: true,
        sort_order: 0,
      });
      alert("Mount created!");
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      await base44.asServiceRole.entities.MountOffering.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-mounts"]);
    },
  });

  const handleCreate = () => {
    if (!newMount.mount_type || !newMount.label) {
      alert("Mount type and label are required");
      return;
    }
    createMutation.mutate(newMount);
  };

  useEffect(() => {
    if (user && mounts.length === 0 && !isLoading) {
      seedDefaults.mutate();
    }
  }, [user, mounts, isLoading]);

  if (!user) return <div className="flex items-center justify-center min-h-screen"><Loader2 className="w-8 h-8 animate-spin" /></div>;

  return (
    <AdminLayout 
      title="Mount Offerings"
      actions={
        <div className="flex gap-2">
          <Button onClick={() => seedDefaults.mutate()} disabled={seedDefaults.isPending} variant="outline" size="sm">
            {seedDefaults.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
            Restore Defaults
          </Button>
          <Button onClick={() => setCreating(true)} size="sm">
            <Plus className="w-4 h-4 mr-2" />
            New Mount
          </Button>
        </div>
      }
    >
      <div className="space-y-6">
        {creating && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Create New Mount</CardTitle>
                <Button variant="ghost" size="icon" onClick={() => setCreating(false)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Brand Slug</label>
                  <Input
                    value={newMount.brand_slug}
                    onChange={(e) => setNewMount({ ...newMount, brand_slug: e.target.value.toUpperCase() })}
                    placeholder="PURESHADOW"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Mount Type *</label>
                  <Input
                    value={newMount.mount_type}
                    onChange={(e) => setNewMount({ ...newMount, mount_type: e.target.value.toUpperCase() })}
                    placeholder="FLOAT"
                  />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium">Label *</label>
                <Input
                  value={newMount.label}
                  onChange={(e) => setNewMount({ ...newMount, label: e.target.value })}
                  placeholder="PureShadow Float Mount"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Description</label>
                <Input
                  value={newMount.description}
                  onChange={(e) => setNewMount({ ...newMount, description: e.target.value })}
                  placeholder="Optional description"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Price Add-on ($)</label>
                  <Input
                    type="number"
                    step="0.01"
                    value={newMount.price_addon}
                    onChange={(e) => setNewMount({ ...newMount, price_addon: parseFloat(e.target.value) })}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Sort Order</label>
                  <Input
                    type="number"
                    value={newMount.sort_order}
                    onChange={(e) => setNewMount({ ...newMount, sort_order: parseInt(e.target.value) })}
                  />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  checked={newMount.active}
                  onCheckedChange={(v) => setNewMount({ ...newMount, active: v })}
                />
                <span className="text-sm">Active</span>
              </div>
              <div className="flex gap-2">
                <Button onClick={handleCreate} disabled={createMutation.isPending}>
                  {createMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                  Create
                </Button>
                <Button variant="outline" onClick={() => setCreating(false)}>Cancel</Button>
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Mounts ({mounts.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin" />
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ borderBottom: "1px solid var(--pm-border)" }}>
                      <th className="text-left py-2 px-3">Key</th>
                      <th className="text-left py-2 px-3">SKU</th>
                      <th className="text-left py-2 px-3">Label</th>
                      <th className="text-left py-2 px-3">Price Add-on</th>
                      <th className="text-left py-2 px-3">Sort Order</th>
                      <th className="text-left py-2 px-3">Active</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mounts.map((mount) => (
                      <tr key={mount.id} style={{ borderBottom: "1px solid var(--pm-border)" }}>
                        <td className="py-2 px-3 font-mono text-xs">{mount.key}</td>
                        <td className="py-2 px-3 font-mono text-xs">{mount.sku}</td>
                        <td className="py-2 px-3">
                          <Input
                            value={mount.label}
                            onChange={(e) => updateMutation.mutate({ id: mount.id, data: { label: e.target.value } })}
                            className="w-48"
                          />
                        </td>
                        <td className="py-2 px-3">
                          <div className="flex items-center gap-2">
                            <span>$</span>
                            <Input
                              type="number"
                              step="0.01"
                              value={mount.price_addon}
                              onChange={(e) => updateMutation.mutate({ id: mount.id, data: { price_addon: parseFloat(e.target.value) } })}
                              className="w-20"
                            />
                          </div>
                        </td>
                        <td className="py-2 px-3">
                          <Input
                            type="number"
                            value={mount.sort_order}
                            onChange={(e) => updateMutation.mutate({ id: mount.id, data: { sort_order: parseInt(e.target.value) } })}
                            className="w-16"
                          />
                        </td>
                        <td className="py-2 px-3">
                          <Switch
                            checked={mount.active}
                            onCheckedChange={(v) => updateMutation.mutate({ id: mount.id, data: { active: v } })}
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}