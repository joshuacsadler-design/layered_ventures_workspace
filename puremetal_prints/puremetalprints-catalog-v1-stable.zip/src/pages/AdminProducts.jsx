import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, RefreshCw, Plus, X } from "lucide-react";
import AdminLayout from "@/components/admin/AdminLayout";
import PMBadge from "@/components/ui/PMBadge";

export default function AdminProducts() {
  const [user, setUser] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [creatingProduct, setCreatingProduct] = useState(false);
  const [creatingVariant, setCreatingVariant] = useState(false);
  
  const [newProduct, setNewProduct] = useState({
    type: 'print',
    name: '',
    description: '',
    active: true
  });

  const [newVariant, setNewVariant] = useState({
    size: '8x10',
    tier: 'standard',
    price: 0,
    active: true
  });

  const queryClient = useQueryClient();

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      const me = await base44.auth.me();
      if (me.role !== "admin") { window.location.href = "/"; return; }
      setUser(me);
    })();
  }, []);

  const { data: allProducts = [] } = useQuery({
    queryKey: ["admin-all-products"],
    queryFn: () => base44.asServiceRole.entities.Product.list(),
    enabled: !!user,
  });

  const { data: allPrices = [] } = useQuery({
    queryKey: ["admin-all-prices"],
    queryFn: () => base44.asServiceRole.entities.ProductPrice.list(),
    enabled: !!user,
  });

  const seedPrintDefaults = useMutation({
    mutationFn: async () => {
      const response = await base44.functions.invoke("ensurePrintProductDefaults", {});
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-all-products"]);
      queryClient.invalidateQueries(["admin-all-prices"]);
      alert("Print defaults synced!");
    },
  });

  const seedMountDefaults = useMutation({
    mutationFn: async () => {
      const response = await base44.functions.invoke("ensureMountDefaults", {});
      return response.data;
    },
    onSuccess: () => {
      alert("Mount defaults created!");
    },
  });

  const createProductMutation = useMutation({
    mutationFn: async (data) => {
      const response = await base44.functions.invoke("createProductAdmin", data);
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-all-products"]);
      setCreatingProduct(false);
      setNewProduct({ type: 'print', name: '', description: '', active: true });
      alert("Product created!");
    },
  });

  const addVariantMutation = useMutation({
    mutationFn: async (data) => {
      const response = await base44.functions.invoke("addVariantAdmin", data);
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-all-prices"]);
      setCreatingVariant(false);
      setNewVariant({ size: '8x10', tier: 'standard', price: 0, active: true });
      alert("Variant added!");
    },
  });

  const updateProductMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      await base44.asServiceRole.entities.Product.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-all-products"]);
    },
  });

  const updatePriceMutation = useMutation({
    mutationFn: async ({ priceId, newPrice }) => {
      await base44.asServiceRole.entities.ProductPrice.update(priceId, { price: parseFloat(newPrice) });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-all-prices"]);
    },
  });

  const handleCreateProduct = () => {
    if (!newProduct.name) {
      alert("Product name is required");
      return;
    }
    createProductMutation.mutate(newProduct);
  };

  const handleAddVariant = () => {
    if (!selectedProduct) {
      alert("Select a product first");
      return;
    }
    addVariantMutation.mutate({
      productId: selectedProduct.id,
      ...newVariant,
    });
  };

  const productPrices = selectedProduct 
    ? allPrices.filter(p => p.product_id === selectedProduct.id)
    : [];

  if (!user) return <div className="flex items-center justify-center min-h-screen"><Loader2 className="w-8 h-8 animate-spin" /></div>;

  return (
    <AdminLayout 
      title="Products & Pricing"
      actions={
        <div className="flex gap-2">
          <Button onClick={() => seedPrintDefaults.mutate()} disabled={seedPrintDefaults.isPending} variant="outline" size="sm">
            {seedPrintDefaults.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
            Seed Prints
          </Button>
          <Button onClick={() => seedMountDefaults.mutate()} disabled={seedMountDefaults.isPending} variant="outline" size="sm">
            {seedMountDefaults.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
            Seed Mounts
          </Button>
          <Button onClick={() => setCreatingProduct(true)} size="sm">
            <Plus className="w-4 h-4 mr-2" />
            New Product
          </Button>
        </div>
      }
    >
      <div className="space-y-6">
        {creatingProduct && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Create New Product</CardTitle>
                <Button variant="ghost" size="icon" onClick={() => setCreatingProduct(false)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Type</label>
                  <Select value={newProduct.type} onValueChange={(v) => setNewProduct({ ...newProduct, type: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="print">Print</SelectItem>
                      <SelectItem value="service">Service</SelectItem>
                      <SelectItem value="addon">Add-on</SelectItem>
                      <SelectItem value="mount">Mount</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium">Name *</label>
                  <Input
                    value={newProduct.name}
                    onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                    placeholder="Product Name"
                  />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium">Description</label>
                <Input
                  value={newProduct.description}
                  onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                  placeholder="Optional description"
                />
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  checked={newProduct.active}
                  onCheckedChange={(v) => setNewProduct({ ...newProduct, active: v })}
                />
                <span className="text-sm">Active</span>
              </div>
              <div className="flex gap-2">
                <Button onClick={handleCreateProduct} disabled={createProductMutation.isPending}>
                  {createProductMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                  Create
                </Button>
                <Button variant="outline" onClick={() => setCreatingProduct(false)}>Cancel</Button>
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Products ({allProducts.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr style={{ borderBottom: "1px solid var(--pm-border)" }}>
                    <th className="text-left py-2 px-3">SKU</th>
                    <th className="text-left py-2 px-3">Name</th>
                    <th className="text-left py-2 px-3">Type</th>
                    <th className="text-left py-2 px-3">Active</th>
                    <th className="text-left py-2 px-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {allProducts.map((product) => (
                    <tr key={product.id} style={{ borderBottom: "1px solid var(--pm-border)" }}>
                      <td className="py-2 px-3 font-mono text-xs">{product.sku}</td>
                      <td className="py-2 px-3">{product.name}</td>
                      <td className="py-2 px-3">
                        <PMBadge variant="default">{product.type}</PMBadge>
                      </td>
                      <td className="py-2 px-3">
                        <Switch
                          checked={product.active}
                          onCheckedChange={(v) => updateProductMutation.mutate({ id: product.id, data: { active: v } })}
                        />
                      </td>
                      <td className="py-2 px-3">
                        <Button
                          size="sm"
                          variant={selectedProduct?.id === product.id ? "default" : "ghost"}
                          onClick={() => setSelectedProduct(product)}
                        >
                          {selectedProduct?.id === product.id ? "Selected" : "Manage Variants"}
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {selectedProduct && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Variants for {selectedProduct.name}</CardTitle>
                  <p className="text-sm mt-1" style={{ color: "var(--pm-text-muted)" }}>
                    SKU: {selectedProduct.sku}
                  </p>
                </div>
                <Button size="sm" onClick={() => setCreatingVariant(!creatingVariant)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Variant
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {creatingVariant && (
                <div className="p-4 rounded border space-y-3" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface-hover)" }}>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-sm font-medium">Size</label>
                      <Input
                        value={newVariant.size}
                        onChange={(e) => setNewVariant({ ...newVariant, size: e.target.value })}
                        placeholder="8x10"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Tier</label>
                      <Input
                        value={newVariant.tier}
                        onChange={(e) => setNewVariant({ ...newVariant, tier: e.target.value.toLowerCase() })}
                        placeholder="standard"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Price</label>
                    <Input
                      type="number"
                      step="0.01"
                      value={newVariant.price}
                      onChange={(e) => setNewVariant({ ...newVariant, price: parseFloat(e.target.value) })}
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={newVariant.active}
                      onCheckedChange={(v) => setNewVariant({ ...newVariant, active: v })}
                    />
                    <span className="text-sm">Active</span>
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={handleAddVariant} disabled={addVariantMutation.isPending}>
                      {addVariantMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                      Add
                    </Button>
                    <Button variant="outline" onClick={() => setCreatingVariant(false)}>Cancel</Button>
                  </div>
                </div>
              )}

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ borderBottom: "1px solid var(--pm-border)" }}>
                      <th className="text-left py-2 px-3">Variant SKU</th>
                      <th className="text-left py-2 px-3">Variant Key</th>
                      <th className="text-left py-2 px-3">Size</th>
                      <th className="text-left py-2 px-3">Tier</th>
                      <th className="text-left py-2 px-3">Price</th>
                      <th className="text-left py-2 px-3">Active</th>
                    </tr>
                  </thead>
                  <tbody>
                    {productPrices.map((price) => (
                      <tr key={price.id} style={{ borderBottom: "1px solid var(--pm-border)" }}>
                        <td className="py-2 px-3 font-mono text-xs">{price.sku || '—'}</td>
                        <td className="py-2 px-3 font-mono text-xs">{price.variant_key}</td>
                        <td className="py-2 px-3">{price.size || '—'}</td>
                        <td className="py-2 px-3">{price.tier || price.material}</td>
                        <td className="py-2 px-3">
                          <div className="flex items-center gap-2">
                            <span>$</span>
                            <Input
                              type="number"
                              step="1"
                              value={price.price}
                              onChange={(e) => updatePriceMutation.mutate({ priceId: price.id, newPrice: e.target.value })}
                              className="w-20"
                            />
                          </div>
                        </td>
                        <td className="py-2 px-3">
                          <PMBadge variant={price.active ? "success" : "default"}>
                            {price.active ? "Yes" : "No"}
                          </PMBadge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </AdminLayout>
  );
}