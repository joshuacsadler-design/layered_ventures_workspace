import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ImageIcon, Sparkles, ShoppingBag, Loader2, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Gallery() {
  const [user, setUser] = useState(null);
  const [quickOrdering, setQuickOrdering] = useState({});
  const [galleryHelper, setGalleryHelper] = useState("Browse our featured gallery or upload your own image to get started.");
  const [dismissedAnnouncements, setDismissedAnnouncements] = useState([]);

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) return;
      const me = await base44.auth.me();
      setUser(me);
    })();
  }, []);

  const { data: siteContent = [] } = useQuery({
    queryKey: ["gallery-site-content"],
    queryFn: () => base44.asServiceRole.entities.SiteContent.list(),
  });

  const { data: galleryImages = [], isLoading } = useQuery({
    queryKey: ['gallery-images'],
    queryFn: async () => {
      const images = await base44.asServiceRole.entities.GalleryImage.filter({ is_active: true });
      return images.sort((a, b) => a.sort_order - b.sort_order);
    },
  });

  const { data: galleryFiles = [] } = useQuery({
    queryKey: ['gallery-files'],
    queryFn: () => base44.asServiceRole.entities.File.filter({ kind: 'GALLERY' }),
    enabled: galleryImages.length > 0,
  });

  const { data: products = [] } = useQuery({
    queryKey: ['gallery-products'],
    queryFn: () => base44.asServiceRole.entities.Product.filter({ type: 'print', active: true }),
  });

  const { data: prices = [] } = useQuery({
    queryKey: ['gallery-prices'],
    queryFn: () => base44.asServiceRole.entities.ProductPrice.filter({ active: true }),
    enabled: products.length > 0,
  });

  const { data: announcements = [] } = useQuery({
    queryKey: ["gallery-announcements"],
    queryFn: () => base44.asServiceRole.entities.Announcement.filter({ is_active: true }),
  });

  useEffect(() => {
    const helper = siteContent.find(c => c.key === 'gallery_helper_text');
    if (helper) setGalleryHelper(helper.value);
  }, [siteContent]);

  const findPrice = (size, material) => {
    const variantKey = `${size}-${material}`;
    return prices.find(p => p.variant_key === variantKey);
  };

  const getFileUrl = (fileId) => {
    const file = galleryFiles.find(f => f.id === fileId);
    return file?.file_url;
  };

  const activeAnnouncements = announcements.filter(a => !dismissedAnnouncements.includes(a.id));

  const handleQuickOrder = async (image, priceRecord) => {
    if (!user) {
      base44.auth.redirectToLogin();
      return;
    }

    setQuickOrdering({ ...quickOrdering, [image.id]: true });

    try {
      const product = products.find(p => p.id === priceRecord.product_id);
      if (!product) {
        throw new Error('Product not found');
      }

      await base44.functions.invoke('addToCart', {
        productId: product.id,
        size: priceRecord.size,
        material: priceRecord.material,
        quantity: 1,
        galleryImageId: image.id,
      });

      alert('Added to cart!');
    } catch (error) {
      alert('Error: ' + error.message);
    }

    setQuickOrdering({ ...quickOrdering, [image.id]: false });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <AnimatePresence>
        {activeAnnouncements.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 max-w-md w-full mx-4"
          >
            <div className="bg-amber-50 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-800 rounded-xl shadow-lg p-4">
              {activeAnnouncements.map((announcement) => (
                <div key={announcement.id} className="flex items-start justify-between gap-3 mb-2 last:mb-0">
                  <div className="flex-1">
                    <p className="font-semibold text-sm text-amber-900 dark:text-amber-100">{announcement.title}</p>
                    <p className="text-xs text-amber-800 dark:text-amber-200 mt-1">{announcement.message}</p>
                  </div>
                  <button
                    onClick={() => setDismissedAnnouncements([...dismissedAnnouncements, announcement.id])}
                    className="text-amber-600 hover:text-amber-800 flex-shrink-0"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">Gallery</h1>
        <p className="text-lg" style={{ color: "var(--pm-text-muted)" }}>{galleryHelper}</p>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin" />
        </div>
      ) : galleryImages.length === 0 ? (
        <div className="text-center py-20 rounded-2xl border" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}>
          <ImageIcon className="w-16 h-16 mx-auto mb-4 opacity-20" />
          <p className="text-xl font-medium">Gallery Coming Soon</p>
          <p className="text-sm mt-2" style={{ color: "var(--pm-text-muted)" }}>We're curating stunning prints for inspiration.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryImages.map((image, i) => {
            const imageUrl = getFileUrl(image.file_id);
            const standardPrice = findPrice(image.default_size, 'standard');
            const reservePrice = image.allow_reserve_upsell ? findPrice(image.default_size, 'puremetalreserve') : null;

            return (
              <motion.div
                key={image.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05, duration: 0.4 }}
                className="rounded-2xl border overflow-hidden hover:shadow-xl transition-all"
                style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}
              >
                <div className="aspect-square bg-neutral-100 dark:bg-neutral-800">
                  {imageUrl && <img src={imageUrl} alt={image.title} className="w-full h-full object-cover" />}
                </div>
                <div className="p-5">
                  <h3 className="font-semibold text-lg mb-3">{image.title}</h3>
                  <div className="space-y-2">
                    {standardPrice && (
                      <Button
                        variant="outline"
                        className="w-full justify-between"
                        onClick={() => handleQuickOrder(image, standardPrice)}
                        disabled={quickOrdering[image.id]}
                      >
                        <span className="flex items-center gap-2">
                          {quickOrdering[image.id] ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShoppingBag className="w-4 h-4" />}
                          Standard
                        </span>
                        <span className="font-semibold">${standardPrice.price.toFixed(2)}</span>
                      </Button>
                    )}
                    {reservePrice && (
                      <Button
                        variant="outline"
                        className="w-full justify-between border-amber-300 hover:bg-amber-50 dark:border-amber-700 dark:hover:bg-amber-900/20"
                        onClick={() => handleQuickOrder(image, reservePrice)}
                        disabled={quickOrdering[image.id]}
                      >
                        <span className="flex items-center gap-2">
                          <Sparkles className="w-4 h-4 text-amber-600" />
                          Reserve
                        </span>
                        <span className="font-semibold text-amber-600">${reservePrice.price.toFixed(2)}</span>
                      </Button>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}