import React, { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";

export default function Health() {
  const [user, setUser] = useState(null);
  const [authError, setAuthError] = useState(null);

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const [catalog, setCatalog] = useState(null);
  const [cartBadge, setCartBadge] = useState(null);

  const [error, setError] = useState(null);
  const [lastUpdatedAt, setLastUpdatedAt] = useState(null);

  const [expanded, setExpanded] = useState({
    summary: true,
    catalog: true,
    cart: true,
  });

  const pretty = (obj) => JSON.stringify(obj, null, 2);

  const invariants = useMemo(() => {
    const product = catalog?.productPrint ?? catalog?.product ?? null;
    const prices = catalog?.prices ?? [];
    const mounts = catalog?.mounts ?? [];

    const hasProduct = !!product?.id;
    const has6Prices = Array.isArray(prices) && prices.length === 6;
    const hasMounts = Array.isArray(mounts) && mounts.length >= 1;

    const hasPureShadowNone =
      Array.isArray(mounts) &&
      mounts.some(
        (m) =>
          (m?.key || "").toUpperCase() === "PURESHADOW_NONE" &&
          m?.active !== false
      );

    const cartCount = cartBadge?.count ?? cartBadge?.badgeCount ?? cartBadge ?? null;
    const hasCartCount = typeof cartCount === "number";

    return {
      hasProduct,
      has6Prices,
      hasMounts,
      hasPureShadowNone,
      hasCartCount,
      cartCount,
      productSku: product?.sku ?? null,
    };
  }, [catalog, cartBadge]);

  async function loadAll({ silent = false } = {}) {
    try {
      if (!silent) setLoading(true);
      setRefreshing(true);
      setError(null);

      const u = await base44.auth.me();
      setUser(u);

      if (!u) {
        setAuthError("Not signed in.");
        return;
      }

      const role = String(u.role || u.user_role || "").toLowerCase();
      if (role !== "admin") {
        // redirect preferred, but show message if redirect helper not available
        try {
          window.location.href = "/";
          return;
        } catch {
          setAuthError("Admin only.");
          return;
        }
      }

      const [catalogRes, cartRes] = await Promise.all([
        base44.functions.invoke('getCatalogPublic', {}),
        base44.functions.invoke('getCartBadgeCount', {}),
      ]);

      setCatalog(catalogRes.data);
      setCartBadge(cartRes.data);
      setLastUpdatedAt(new Date().toISOString());
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (authError) {
    return (
      <div className="p-6 max-w-4xl mx-auto">
        <h1 className="text-2xl font-semibold">/__health</h1>
        <div className="mt-4 rounded border p-4">
          <div className="font-medium">Access blocked</div>
          <div className="text-sm opacity-80 mt-1">{authError}</div>
        </div>
      </div>
    );
  }

  if (loading && !catalog && !cartBadge) {
    return (
      <div className="p-6 max-w-4xl mx-auto">
        <h1 className="text-2xl font-semibold">/__health</h1>
        <div className="mt-4 rounded border p-4 text-sm opacity-80">
          Loading…
        </div>
      </div>
    );
  }

  const pill = (ok, label) => (
    <span
      className={[
        "inline-flex items-center rounded-full px-3 py-1 text-xs font-medium border",
        ok ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200",
      ].join(" ")}
    >
      {ok ? "PASS" : "FAIL"} — {label}
    </span>
  );

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">/__health</h1>
          <div className="text-sm opacity-80 mt-1">
            Admin-only sanity probe. Read-only. No side effects.
          </div>
          <div className="text-xs opacity-70 mt-2">
            Updated: {lastUpdatedAt ? new Date(lastUpdatedAt).toLocaleString() : "—"}
          </div>
        </div>

        <button
          onClick={() => loadAll({ silent: true })}
          disabled={refreshing}
          className={[
            "rounded px-4 py-2 text-sm font-medium border",
            refreshing ? "opacity-60 cursor-not-allowed" : "",
          ].join(" ")}
        >
          {refreshing ? "Refreshing…" : "Refresh"}
        </button>
      </div>

      {error ? (
        <div className="mt-4 rounded border border-red-200 bg-red-50 p-4 text-sm">
          <div className="font-medium">Error</div>
          <div className="mt-1 whitespace-pre-wrap">{error}</div>
        </div>
      ) : null}

      <div className="mt-6 rounded border p-4">
        <div className="flex items-center justify-between">
          <div className="font-semibold">V1 invariants</div>
          <button
            className="text-sm underline"
            onClick={() => setExpanded((s) => ({ ...s, summary: !s.summary }))}
          >
            {expanded.summary ? "Collapse" : "Expand"}
          </button>
        </div>

        {expanded.summary ? (
          <div className="mt-3 flex flex-wrap gap-2">
            {pill(invariants.hasProduct, `Print product exists (${invariants.productSku || "no sku"})`)}
            {pill(invariants.has6Prices, "Exactly 6 print variants")}
            {pill(invariants.hasMounts, "At least 1 mount")}
            {pill(invariants.hasPureShadowNone, "PURESHADOW_NONE present")}
            {pill(invariants.hasCartCount, `Cart count available (${invariants.cartCount ?? "—"})`)}
          </div>
        ) : null}

        <div className="mt-4 text-xs opacity-70">
          NOTE: If any FAIL appears here after styling changes, revert to your Catalog V1 checkpoint.
        </div>
      </div>

      <div className="mt-6 rounded border p-4">
        <div className="flex items-center justify-between">
          <div className="font-semibold">getCatalogPublic (raw)</div>
          <button
            className="text-sm underline"
            onClick={() => setExpanded((s) => ({ ...s, catalog: !s.catalog }))}
          >
            {expanded.catalog ? "Collapse" : "Expand"}
          </button>
        </div>

        {expanded.catalog ? (
          <pre className="mt-3 overflow-auto rounded bg-black text-white p-4 text-xs leading-relaxed">
            {pretty(catalog)}
          </pre>
        ) : null}
      </div>

      <div className="mt-6 rounded border p-4">
        <div className="flex items-center justify-between">
          <div className="font-semibold">getCartBadgeCount (raw)</div>
          <button
            className="text-sm underline"
            onClick={() => setExpanded((s) => ({ ...s, cart: !s.cart }))}
          >
            {expanded.cart ? "Collapse" : "Expand"}
          </button>
        </div>

        {expanded.cart ? (
          <pre className="mt-3 overflow-auto rounded bg-black text-white p-4 text-xs leading-relaxed">
            {pretty(cartBadge)}
          </pre>
        ) : null}
      </div>

      {/* CATALOG V2 BOUNDARY (DO NOT VIOLATE IN V1 STYLING PHASE)
          If you change any of these, that is "Catalog V2":
          - functions/getCatalogPublic response keys or structure
          - functions/addToCart input contract or pricing computation
          - functions/applyCouponToDraftOrder contract or discount math
          - SKU/coupon generation rules (reserveSequentialSku/reserveRandomCouponCode)
          - entities: Product, ProductPrice, MountOffering, Coupon, CodeRegistry, CodeReservation
          Styling-only phase MUST NOT modify the above.
      */}
    </div>
  );
}