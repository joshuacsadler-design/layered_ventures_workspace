import React, { useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Loader2, Package } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

function tierLabel(tier) {
  if (tier === "reserve" || tier === "puremetalreserve") return "PureMetal Reserve";
  return "PureMetal Standard";
}

function sortKey(v) {
  const sizeOrder = { "6x8": 1, "8x10": 2, "8x12": 3 };
  const tierOrder = { standard: 1, reserve: 2, puremetalreserve: 2 };
  return (sizeOrder[v.size] || 99) * 10 + (tierOrder[v.tier || v.material] || 9);
}

export default function Shop() {
  const navigate = useNavigate();

  const { data: catalog, isLoading } = useQuery({
    queryKey: ["shop-catalog"],
    queryFn: async () => {
      const response = await base44.functions.invoke("getCatalogPublic", {});
      return response.data;
    },
  });

  const product = catalog?.product || null;
  const variants = catalog?.prices || [];

  const orderedVariants = useMemo(() => {
    return [...variants].sort((a, b) => sortKey(a) - sortKey(b));
  }, [variants]);

  const handleSelectVariant = (variant) => {
    const tier = variant.tier || variant.material;
    const url = `${createPageUrl("CreatePrint")}?size=${encodeURIComponent(variant.size)}&tier=${encodeURIComponent(tier)}`;
    navigate(url);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-10">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Shop</h1>
        <p className="mt-3 text-lg" style={{ color: "var(--pm-text-muted)" }}>
          Choose your size and edition. PureMetal production is always studio-controlled.
        </p>
      </div>

      {!product ? (
        <div className="text-center py-20" style={{ color: "var(--pm-text-muted)" }}>
          <Package className="w-12 h-12 mx-auto mb-4 opacity-40" />
          <p className="text-lg">Products coming soon!</p>
        </div>
      ) : (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl border overflow-hidden"
          style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}
        >
          <div className="p-6 border-b" style={{ borderColor: "var(--pm-border)" }}>
            <h2 className="text-2xl font-semibold">{product.name}</h2>
            <p className="mt-2 text-sm" style={{ color: "var(--pm-text-muted)" }}>
              {product.description || "Premium dye-sublimation aluminum prints by PureMetal."}
            </p>
          </div>

          {orderedVariants.length === 0 ? (
            <div className="p-10 text-center" style={{ color: "var(--pm-text-muted)" }}>
              <p>No active variants found for this product.</p>
            </div>
          ) : (
            <div className="divide-y" style={{ borderColor: "var(--pm-border)" }}>
              {orderedVariants.map((v) => {
                const tier = v.tier || v.material;
                return (
                  <div key={v.id} className="p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div>
                      <div className="font-medium text-lg">
                        {v.size}" — {tierLabel(tier)}
                      </div>
                      <div className="text-sm mt-1" style={{ color: "var(--pm-text-muted)" }}>
                        {tier === "reserve" || tier === "puremetalreserve"
                          ? "Premium glossy stock curated under the PureMetal brand."
                          : "Standard glossy aluminum stock."}
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-2xl font-bold">${Number(v.price).toFixed(2)}</div>
                      <Button
                        className="gap-2 bg-neutral-900 text-white hover:bg-neutral-800"
                        onClick={() => handleSelectVariant(v)}
                      >
                        Select & Upload
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
}