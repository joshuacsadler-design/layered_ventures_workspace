import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Loader2, Plus, X } from "lucide-react";
import AdminLayout from "@/components/admin/AdminLayout";
import PMBadge from "@/components/ui/PMBadge";

export default function AdminServices() {
  const [user, setUser] = useState(null);
  const [selectedService, setSelectedService] = useState(null);
  const [creatingService, setCreatingService] = useState(false);
  const [creatingTier, setCreatingTier] = useState(false);
  
  const [newService, setNewService] = useState({
    name: '',
    description: '',
    active: true
  });

  const [newTier, setNewTier] = useState({
    tier: 'basic',
    price: 0,
    active: true
  });

  const queryClient = useQueryClient();

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      const me = await base44.auth.me();
      if (me.role !== "admin") { window.location.href = "/"; return; }
      setUser(me);
    })();
  }, []);

  const { data: services = [] } = useQuery({
    queryKey: ["admin-services"],
    queryFn: async () => {
      const all = await base44.asServiceRole.entities.Product.list();
      return all.filter(p => p.type === 'service');
    },
    enabled: !!user,
  });

  const { data: allPrices = [] } = useQuery({
    queryKey: ["admin-service-prices"],
    queryFn: () => base44.asServiceRole.entities.ProductPrice.list(),
    enabled: !!user,
  });

  const createServiceMutation = useMutation({
    mutationFn: async (data) => {
      const response = await base44.functions.invoke("createProductAdmin", { ...data, type: 'service' });
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-services"]);
      setCreatingService(false);
      setNewService({ name: '', description: '', active: true });
      alert("Service created!");
    },
  });

  const addTierMutation = useMutation({
    mutationFn: async (data) => {
      const response = await base44.functions.invoke("addVariantAdmin", data);
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-service-prices"]);
      setCreatingTier(false);
      setNewTier({ tier: 'basic', price: 0, active: true });
      alert("Tier added!");
    },
  });

  const updateServiceMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      await base44.asServiceRole.entities.Product.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-services"]);
    },
  });

  const serviceTiers = selectedService 
    ? allPrices.filter(p => p.product_id === selectedService.id)
    : [];

  if (!user) return <div className="flex items-center justify-center min-h-screen"><Loader2 className="w-8 h-8 animate-spin" /></div>;

  return (
    <AdminLayout 
      title="Services"
      actions={
        <Button onClick={() => setCreatingService(true)} size="sm">
          <Plus className="w-4 h-4 mr-2" />
          New Service
        </Button>
      }
    >
      <div className="space-y-6">
        {creatingService && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Create New Service</CardTitle>
                <Button variant="ghost" size="icon" onClick={() => setCreatingService(false)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">Name *</label>
                <Input
                  value={newService.name}
                  onChange={(e) => setNewService({ ...newService, name: e.target.value })}
                  placeholder="Color Restoration"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Description</label>
                <Input
                  value={newService.description}
                  onChange={(e) => setNewService({ ...newService, description: e.target.value })}
                  placeholder="Optional description"
                />
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  checked={newService.active}
                  onCheckedChange={(v) => setNewService({ ...newService, active: v })}
                />
                <span className="text-sm">Active</span>
              </div>
              <div className="flex gap-2">
                <Button onClick={() => createServiceMutation.mutate(newService)} disabled={createServiceMutation.isPending}>
                  {createServiceMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                  Create
                </Button>
                <Button variant="outline" onClick={() => setCreatingService(false)}>Cancel</Button>
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Services ({services.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr style={{ borderBottom: "1px solid var(--pm-border)" }}>
                    <th className="text-left py-2 px-3">SKU</th>
                    <th className="text-left py-2 px-3">Name</th>
                    <th className="text-left py-2 px-3">Active</th>
                    <th className="text-left py-2 px-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {services.map((service) => (
                    <tr key={service.id} style={{ borderBottom: "1px solid var(--pm-border)" }}>
                      <td className="py-2 px-3 font-mono text-xs">{service.sku}</td>
                      <td className="py-2 px-3">{service.name}</td>
                      <td className="py-2 px-3">
                        <Switch
                          checked={service.active}
                          onCheckedChange={(v) => updateServiceMutation.mutate({ id: service.id, data: { active: v } })}
                        />
                      </td>
                      <td className="py-2 px-3">
                        <Button
                          size="sm"
                          variant={selectedService?.id === service.id ? "default" : "ghost"}
                          onClick={() => setSelectedService(service)}
                        >
                          {selectedService?.id === service.id ? "Selected" : "Manage Tiers"}
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {selectedService && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Tiers for {selectedService.name}</CardTitle>
                  <p className="text-sm mt-1" style={{ color: "var(--pm-text-muted)" }}>
                    SKU: {selectedService.sku}
                  </p>
                </div>
                <Button size="sm" onClick={() => setCreatingTier(!creatingTier)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Tier
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {creatingTier && (
                <div className="p-4 rounded border space-y-3" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface-hover)" }}>
                  <div>
                    <label className="text-sm font-medium">Tier Name</label>
                    <Input
                      value={newTier.tier}
                      onChange={(e) => setNewTier({ ...newTier, tier: e.target.value.toLowerCase() })}
                      placeholder="basic"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Price</label>
                    <Input
                      type="number"
                      step="0.01"
                      value={newTier.price}
                      onChange={(e) => setNewTier({ ...newTier, price: parseFloat(e.target.value) })}
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={newTier.active}
                      onCheckedChange={(v) => setNewTier({ ...newTier, active: v })}
                    />
                    <span className="text-sm">Active</span>
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={() => addTierMutation.mutate({ productId: selectedService.id, size: null, ...newTier })} disabled={addTierMutation.isPending}>
                      {addTierMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                      Add
                    </Button>
                    <Button variant="outline" onClick={() => setCreatingTier(false)}>Cancel</Button>
                  </div>
                </div>
              )}

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ borderBottom: "1px solid var(--pm-border)" }}>
                      <th className="text-left py-2 px-3">Tier SKU</th>
                      <th className="text-left py-2 px-3">Tier</th>
                      <th className="text-left py-2 px-3">Price</th>
                      <th className="text-left py-2 px-3">Active</th>
                    </tr>
                  </thead>
                  <tbody>
                    {serviceTiers.map((tier) => (
                      <tr key={tier.id} style={{ borderBottom: "1px solid var(--pm-border)" }}>
                        <td className="py-2 px-3 font-mono text-xs">{tier.sku || '—'}</td>
                        <td className="py-2 px-3">{tier.tier}</td>
                        <td className="py-2 px-3">${tier.price.toFixed(2)}</td>
                        <td className="py-2 px-3">
                          <PMBadge variant={tier.active ? "success" : "default"}>
                            {tier.active ? "Yes" : "No"}
                          </PMBadge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </AdminLayout>
  );
}