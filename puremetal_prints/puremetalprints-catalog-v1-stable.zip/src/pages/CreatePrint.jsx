import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { useNavigate, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Upload, Loader2, X, ShoppingCart, AlertCircle } from "lucide-react";

export default function CreatePrint() {
  const navigate = useNavigate();
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  
  const [user, setUser] = useState(null);
  const [isAuth, setIsAuth] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [adding, setAdding] = useState(false);
  const [file, setFile] = useState(null);
  const [fileUrl, setFileUrl] = useState(null);
  const [selectedSize, setSelectedSize] = useState(params.get('size') || '8x10');
  const [selectedTier, setSelectedTier] = useState(params.get('tier') || 'standard');
  const [selectedMount, setSelectedMount] = useState(null);

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      setIsAuth(auth);
      if (auth) setUser(await base44.auth.me());
    })();
  }, []);

  const { data: catalog, isLoading } = useQuery({
    queryKey: ["create-print-catalog"],
    queryFn: async () => {
      const response = await base44.functions.invoke("getCatalogPublic", {});
      return response.data;
    },
  });

  const product = catalog?.product || null;
  const variants = catalog?.prices || [];
  const mounts = catalog?.mounts || [];

  useEffect(() => {
    if (mounts.length > 0 && !selectedMount) {
      const defaultMount = mounts.find(m => m.key === 'PURESHADOW_NONE') || mounts[0];
      setSelectedMount(defaultMount.key);
    }
  }, [mounts, selectedMount]);

  const selectedVariant = variants.find(v => v.size === selectedSize && v.tier === selectedTier);
  const selectedMountObj = mounts.find(m => m.key === selectedMount);

  const totalPrice = selectedVariant && selectedMountObj
    ? selectedVariant.price + selectedMountObj.price_addon
    : 0;

  const handleFileChange = async (e) => {
    const selected = e.target.files[0];
    if (!selected) return;

    setFile(selected);
    setUploading(true);

    try {
      const uploadResp = await base44.integrations.Core.UploadFile({ file: selected });
      setFileUrl(uploadResp.file_url);
    } catch (error) {
      alert("Upload failed: " + error.message);
    }

    setUploading(false);
  };

  const handleAddToCart = async () => {
    if (!isAuth) {
      base44.auth.redirectToLogin();
      return;
    }

    if (!fileUrl || !selectedVariant || !selectedMount) {
      alert("Please upload an image and select all options.");
      return;
    }

    setAdding(true);

    try {
      await base44.functions.invoke("addToCart", {
        product_id: product.id,
        variant_key: selectedVariant.variant_key,
        quantity: 1,
        mount_key: selectedMount,
      });

      navigate(createPageUrl("Cart"));
    } catch (error) {
      alert("Failed to add to cart: " + error.message);
    }

    setAdding(false);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <AlertCircle className="w-12 h-12 mx-auto mb-4 opacity-40" />
        <p className="text-lg" style={{ color: "var(--pm-text-muted)" }}>
          Products are not available at the moment.
        </p>
      </div>
    );
  }

  if (mounts.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <AlertCircle className="w-12 h-12 mx-auto mb-4 text-amber-500" />
        <h2 className="text-xl font-semibold mb-2">Mount Options Unavailable</h2>
        <p className="text-sm" style={{ color: "var(--pm-text-muted)" }}>
          No mount options are currently available. Please check back soon.
        </p>
      </div>
    );
  }

  const sizes = [...new Set(variants.map(v => v.size))];
  const tiers = [...new Set(variants.map(v => v.tier))];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Create Your Print</h1>
        <p className="mt-2 text-lg" style={{ color: "var(--pm-text-muted)" }}>
          Upload your image and customize your order.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Upload Image</CardTitle>
          </CardHeader>
          <CardContent>
            {!fileUrl ? (
              <label className="flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-lg cursor-pointer hover:bg-neutral-50 dark:hover:bg-neutral-900 transition-colors" style={{ borderColor: "var(--pm-border)" }}>
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                  {uploading ? (
                    <Loader2 className="w-10 h-10 animate-spin mb-3" style={{ color: "var(--pm-text-muted)" }} />
                  ) : (
                    <Upload className="w-10 h-10 mb-3" style={{ color: "var(--pm-text-muted)" }} />
                  )}
                  <p className="mb-2 text-sm">
                    <span className="font-semibold">Click to upload</span> or drag and drop
                  </p>
                  <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>
                    PNG, JPG, TIFF (MAX. 50MB)
                  </p>
                </div>
                <input type="file" className="hidden" onChange={handleFileChange} accept="image/*" disabled={uploading} />
              </label>
            ) : (
              <div className="relative">
                <img src={fileUrl} alt="Preview" className="w-full h-64 object-contain rounded-lg" style={{ backgroundColor: "var(--pm-surface-hover)" }} />
                <Button
                  size="icon"
                  variant="destructive"
                  className="absolute top-2 right-2"
                  onClick={() => {
                    setFile(null);
                    setFileUrl(null);
                  }}
                >
                  <X className="w-4 h-4" />
                </Button>
                {file && (
                  <p className="mt-2 text-xs" style={{ color: "var(--pm-text-muted)" }}>
                    {file.name}
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Print Options</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="mb-2 block">Size</Label>
              <Select value={selectedSize} onValueChange={setSelectedSize}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {sizes.map(size => (
                    <SelectItem key={size} value={size}>{size}"</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="mb-2 block">Edition</Label>
              <Select value={selectedTier} onValueChange={setSelectedTier}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {tiers.map(tier => (
                    <SelectItem key={tier} value={tier}>
                      {tier === 'reserve' ? 'PureMetal Reserve' : 'PureMetal Standard'}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="mb-2 block">Mount</Label>
              <Select value={selectedMount} onValueChange={setSelectedMount}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {mounts.map(mount => (
                    <SelectItem key={mount.key} value={mount.key}>
                      {mount.label}
                      {mount.price_addon > 0 && ` (+$${mount.price_addon})`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="pt-4 border-t" style={{ borderColor: "var(--pm-border)" }}>
              <div className="flex justify-between items-center mb-4">
                <span className="text-lg font-semibold">Total</span>
                <span className="text-2xl font-bold">${totalPrice.toFixed(2)}</span>
              </div>

              <Button
                className="w-full gap-2 bg-neutral-900 text-white hover:bg-neutral-800"
                onClick={handleAddToCart}
                disabled={!fileUrl || adding || !selectedVariant || !selectedMount}
              >
                {adding ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Adding...
                  </>
                ) : (
                  <>
                    <ShoppingCart className="w-4 h-4" />
                    Add to Cart
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}