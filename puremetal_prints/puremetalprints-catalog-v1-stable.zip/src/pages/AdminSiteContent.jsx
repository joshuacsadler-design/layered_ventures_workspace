import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Loader2, Upload, Trash2, Save, Plus } from "lucide-react";
import AdminLayout from "@/components/admin/AdminLayout";
import PMBadge from "@/components/ui/PMBadge";

export default function AdminSiteContent() {
  const [user, setUser] = useState(null);
  const [heroCaption, setHeroCaption] = useState("");
  const [galleryHelper, setGalleryHelper] = useState("");
  const [announcements, setAnnouncements] = useState([]);
  const [newAnnouncement, setNewAnnouncement] = useState({ title: "", message: "", is_active: false });
  const queryClient = useQueryClient();

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      const me = await base44.auth.me();
      if (me.role !== "admin") { window.location.href = "/"; return; }
      setUser(me);

      // Ensure defaults exist
      await base44.functions.invoke('ensureSiteDefaults');
    })();
  }, []);

  const { data: siteContent = [] } = useQuery({
    queryKey: ["site-content"],
    queryFn: () => base44.asServiceRole.entities.SiteContent.list(),
    enabled: !!user,
    onSuccess: (data) => {
      const caption = data.find(c => c.key === 'hero_caption');
      const helper = data.find(c => c.key === 'gallery_helper_text');
      if (caption) setHeroCaption(caption.value);
      if (helper) setGalleryHelper(helper.value);
    },
  });

  const { data: galleryImages = [] } = useQuery({
    queryKey: ["gallery-images"],
    queryFn: () => base44.asServiceRole.entities.GalleryImage.list('-sort_order'),
    enabled: !!user,
  });

  const { data: allAnnouncements = [] } = useQuery({
    queryKey: ["announcements"],
    queryFn: () => base44.asServiceRole.entities.Announcement.list('-created_date'),
    enabled: !!user,
    onSuccess: (data) => setAnnouncements(data),
  });

  const updateContentMutation = useMutation({
    mutationFn: async ({ key, value }) => {
      const existing = siteContent.find(c => c.key === key);
      if (existing) {
        await base44.asServiceRole.entities.SiteContent.update(existing.id, { value });
      } else {
        await base44.asServiceRole.entities.SiteContent.create({ key, value });
      }
    },
    onSuccess: () => queryClient.invalidateQueries(["site-content"]),
  });

  const uploadGalleryImageMutation = useMutation({
    mutationFn: async ({ file, isHero, title }) => {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      const fileRecord = await base44.asServiceRole.entities.File.create({
        order_item_id: null,
        kind: 'GALLERY',
        file_url: file_url,
        filename: file.name,
        source_file_id: null,
        is_delivered_to_client: false,
        metadata: { uploaded_by: user.id },
      });

      // Count non-default heroes
      const nonDefaultHeroes = galleryImages.filter(img => !img.is_default_hero && img.is_active);
      
      if (isHero && nonDefaultHeroes.length >= 5) {
        alert('Maximum 5 additional hero images allowed (default hero not counted)');
        return;
      }

      await base44.asServiceRole.entities.GalleryImage.create({
        title: title || file.name,
        file_id: fileRecord.id,
        is_default_hero: false,
        is_active: true,
        sort_order: galleryImages.length,
        default_size: '8x10',
        default_material: 'standard',
        allow_reserve_upsell: true,
      });
    },
    onSuccess: () => queryClient.invalidateQueries(["gallery-images"]),
  });

  const updateGalleryImageMutation = useMutation({
    mutationFn: async ({ imageId, data }) => {
      await base44.asServiceRole.entities.GalleryImage.update(imageId, data);
    },
    onSuccess: () => queryClient.invalidateQueries(["gallery-images"]),
  });

  const deleteGalleryImageMutation = useMutation({
    mutationFn: async (imageId) => {
      const image = galleryImages.find(img => img.id === imageId);
      if (image?.is_default_hero) {
        alert('Cannot delete default hero image. Mark as inactive instead.');
        return;
      }
      await base44.asServiceRole.entities.GalleryImage.delete(imageId);
    },
    onSuccess: () => queryClient.invalidateQueries(["gallery-images"]),
  });

  const createAnnouncementMutation = useMutation({
    mutationFn: async () => {
      await base44.asServiceRole.entities.Announcement.create(newAnnouncement);
      setNewAnnouncement({ title: "", message: "", is_active: false });
    },
    onSuccess: () => queryClient.invalidateQueries(["announcements"]),
  });

  const updateAnnouncementMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      await base44.asServiceRole.entities.Announcement.update(id, data);
    },
    onSuccess: () => queryClient.invalidateQueries(["announcements"]),
  });

  const deleteAnnouncementMutation = useMutation({
    mutationFn: async (id) => {
      await base44.asServiceRole.entities.Announcement.delete(id);
    },
    onSuccess: () => queryClient.invalidateQueries(["announcements"]),
  });

  const handleUploadHeroImage = (e, isHero) => {
    const file = e.target.files?.[0];
    if (file) {
      const title = prompt("Enter image title:");
      if (title) uploadGalleryImageMutation.mutate({ file, isHero, title });
    }
  };

  if (!user) return <div className="flex items-center justify-center min-h-screen"><Loader2 className="w-8 h-8 animate-spin" /></div>;

  const defaultHero = galleryImages.find(img => img.is_default_hero);
  const additionalHeroes = galleryImages.filter(img => !img.is_default_hero && img.is_active);
  const regularGallery = galleryImages.filter(img => !img.is_default_hero);

  useEffect(() => {
    const caption = siteContent.find(c => c.key === 'hero_caption');
    const helper = siteContent.find(c => c.key === 'gallery_helper_text');
    if (caption) setHeroCaption(caption.value);
    if (helper) setGalleryHelper(helper.value);
  }, [siteContent]);

  return (
    <AdminLayout title="Site Content">
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Text Content</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Hero Caption</label>
              <Textarea
                value={heroCaption}
                onChange={(e) => setHeroCaption(e.target.value)}
                rows={2}
              />
              <Button
                size="sm"
                className="mt-2"
                onClick={() => updateContentMutation.mutate({ key: 'hero_caption', value: heroCaption })}
              >
                <Save className="w-3 h-3 mr-1" /> Save
              </Button>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Gallery Helper Text</label>
              <Textarea
                value={galleryHelper}
                onChange={(e) => setGalleryHelper(e.target.value)}
                rows={2}
              />
              <Button
                size="sm"
                className="mt-2"
                onClick={() => updateContentMutation.mutate({ key: 'gallery_helper_text', value: galleryHelper })}
              >
                <Save className="w-3 h-3 mr-1" /> Save
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Hero Carousel</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 rounded bg-blue-50 dark:bg-blue-900/20">
              <p className="text-sm font-medium mb-2">Default Hero (Always Included)</p>
              {defaultHero ? (
                <div className="flex items-start gap-3">
                  <div>
                    <p className="text-sm font-semibold">{defaultHero.title}</p>
                    <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>
                      Default · Editable but not removable
                    </p>
                    <div className="flex gap-2 mt-2">
                      <Switch
                        checked={defaultHero.is_active}
                        onCheckedChange={(checked) => updateGalleryImageMutation.mutate({ imageId: defaultHero.id, data: { is_active: checked } })}
                      />
                      <span className="text-xs">Active</span>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-sm" style={{ color: "var(--pm-text-muted)" }}>
                  No default hero set. Create one in Gallery Images.
                </p>
              )}
            </div>

            <div>
              <div className="flex items-center justify-between mb-3">
                <p className="text-sm font-medium">
                  Additional Hero Images ({additionalHeroes.length}/5)
                </p>
                {additionalHeroes.length < 5 && (
                  <label className="cursor-pointer">
                    <Button size="sm" variant="outline" asChild>
                      <span><Upload className="w-3 h-3 mr-1" /> Add Hero</span>
                    </Button>
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => handleUploadHeroImage(e, true)} />
                  </label>
                )}
              </div>
              <div className="space-y-2">
                {additionalHeroes.map((image) => (
                  <div key={image.id} className="flex items-center justify-between p-3 rounded border" style={{ borderColor: "var(--pm-border)" }}>
                    <div>
                      <p className="text-sm font-medium">{image.title}</p>
                      <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>Order: {image.sort_order}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={image.is_active}
                        onCheckedChange={(checked) => updateGalleryImageMutation.mutate({ imageId: image.id, data: { is_active: checked } })}
                      />
                      <Button variant="ghost" size="icon" onClick={() => deleteGalleryImageMutation.mutate(image.id)}>
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Announcements</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 rounded border" style={{ borderColor: "var(--pm-border)" }}>
              <p className="text-sm font-medium mb-3">Create New Announcement</p>
              <div className="space-y-2">
                <Input
                  placeholder="Title"
                  value={newAnnouncement.title}
                  onChange={(e) => setNewAnnouncement({ ...newAnnouncement, title: e.target.value })}
                />
                <Textarea
                  placeholder="Message"
                  value={newAnnouncement.message}
                  onChange={(e) => setNewAnnouncement({ ...newAnnouncement, message: e.target.value })}
                  rows={3}
                />
                <div className="flex items-center gap-2">
                  <Switch
                    checked={newAnnouncement.is_active}
                    onCheckedChange={(checked) => setNewAnnouncement({ ...newAnnouncement, is_active: checked })}
                  />
                  <span className="text-sm">Active</span>
                </div>
                <Button size="sm" onClick={() => createAnnouncementMutation.mutate()}>
                  <Plus className="w-3 h-3 mr-1" /> Create
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              {allAnnouncements.map((announcement) => (
                <div key={announcement.id} className="p-3 rounded border" style={{ borderColor: "var(--pm-border)" }}>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="font-medium">{announcement.title}</p>
                      <p className="text-sm mt-1">{announcement.message}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <PMBadge variant={announcement.is_active ? "success" : "default"}>
                          {announcement.is_active ? "Active" : "Inactive"}
                        </PMBadge>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={announcement.is_active}
                        onCheckedChange={(checked) => updateAnnouncementMutation.mutate({ id: announcement.id, data: { is_active: checked } })}
                      />
                      <Button variant="ghost" size="icon" onClick={() => deleteAnnouncementMutation.mutate(announcement.id)}>
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
              {allAnnouncements.length === 0 && (
                <p className="text-center py-4" style={{ color: "var(--pm-text-muted)" }}>
                  No announcements yet. Bubble hides when empty.
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}