import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/components/utils";
import { 
  Package, Clock, CheckCircle, PlayCircle, Wrench, 
  TruckIcon, AlertCircle, Loader2 
} from "lucide-react";
import AdminLayout from "@/components/admin/AdminLayout";
import PMBadge from "@/components/ui/PMBadge";

export default function AdminDashboard() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      const me = await base44.auth.me();
      if (me.role !== "admin") { window.location.href = "/"; return; }
      setUser(me);
    })();
  }, []);

  const { data: orders = [] } = useQuery({
    queryKey: ["admin-all-orders"],
    queryFn: () => base44.asServiceRole.entities.Order.list('-created_date', 100),
    enabled: !!user,
  });

  const { data: items = [] } = useQuery({
    queryKey: ["admin-all-items"],
    queryFn: () => base44.asServiceRole.entities.OrderItem.list(),
    enabled: !!user,
  });

  const { data: proofs = [] } = useQuery({
    queryKey: ["admin-all-proofs"],
    queryFn: () => base44.asServiceRole.entities.Proof.list(),
    enabled: !!user,
  });

  const { data: cancellationRequests = [] } = useQuery({
    queryKey: ["admin-cancellation-requests"],
    queryFn: () => base44.asServiceRole.entities.CancellationRequest.filter({ status: 'PENDING' }),
    enabled: !!user,
  });

  if (!user) return <div className="flex items-center justify-center min-h-screen"><Loader2 className="w-8 h-8 animate-spin" /></div>;

  // Calculate metrics
  const newOrders = orders.filter(o => o.status === 'UPLOADED').length;
  
  const awaitingProofDelivery = orders.filter(o => {
    const orderItems = items.filter(i => i.order_id === o.id);
    return orderItems.some(item => {
      const itemProofs = proofs.filter(p => p.order_item_id === item.id && !p.is_delivered);
      return itemProofs.length > 0 && item.status === 'IN_PROOFING';
    });
  }).length;

  const awaitingClientApproval = orders.filter(o => 
    ['PROOF_DELIVERED', 'PROOF_SELECTED'].includes(o.status)
  ).length;

  const readyToStartProduction = orders.filter(o => o.status === 'APPROVED').length;
  const inProduction = orders.filter(o => o.status === 'IN_PRODUCTION').length;
  
  const readyToShip = orders.filter(o => {
    const orderItems = items.filter(i => i.order_id === o.id);
    return orderItems.length > 0 && orderItems.every(i => i.status === 'COMPLETED') && o.status !== 'COMPLETED';
  }).length;

  const completedThisMonth = orders.filter(o => {
    if (o.status !== 'COMPLETED') return false;
    const date = new Date(o.updated_date);
    const now = new Date();
    return date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear();
  }).length;

  const recentOrders = orders.slice(0, 10);

  const metrics = [
    { label: "New Orders", value: newOrders, icon: Package, color: "text-blue-600", bg: "bg-blue-50", link: "AdminOrders?status=UPLOADED" },
    { label: "Awaiting Proof Delivery", value: awaitingProofDelivery, icon: Clock, color: "text-amber-600", bg: "bg-amber-50", link: "AdminOrders?status=IN_PROOFING" },
    { label: "Awaiting Client Approval", value: awaitingClientApproval, icon: AlertCircle, color: "text-purple-600", bg: "bg-purple-50", link: "AdminOrders?status=PROOF_DELIVERED" },
    { label: "Ready to Start Production", value: readyToStartProduction, icon: PlayCircle, color: "text-emerald-600", bg: "bg-emerald-50", link: "AdminOrders?status=APPROVED" },
    { label: "In Production", value: inProduction, icon: Wrench, color: "text-indigo-600", bg: "bg-indigo-50", link: "AdminOrders?status=IN_PRODUCTION" },
    { label: "Ready to Ship", value: readyToShip, icon: TruckIcon, color: "text-teal-600", bg: "bg-teal-50", link: "AdminShipping" },
    { label: "Completed This Month", value: completedThisMonth, icon: CheckCircle, color: "text-green-600", bg: "bg-green-50", link: "AdminOrders?status=COMPLETED" },
    { label: "Pending Cancellations", value: cancellationRequests.length, icon: AlertCircle, color: "text-red-600", bg: "bg-red-50", link: "AdminCancellations" },
  ];

  const STATUS_VARIANTS = {
    DRAFT: "default", UPLOADED: "purple", NEEDS_REVIEW: "warning", 
    PROOF_DELIVERED: "purple", PROOF_SELECTED: "success", APPROVED: "gold",
    IN_PRODUCTION: "purple", COMPLETED: "success", CANCELLATION_REQUESTED: "error", CANCELLED: "error",
  };

  return (
    <AdminLayout title="Dashboard">
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {metrics.map((metric, idx) => {
            const Icon = metric.icon;
            return (
              <Link key={idx} to={createPageUrl(metric.link)}>
                <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium" style={{ color: "var(--pm-text-muted)" }}>{metric.label}</p>
                        <p className="text-3xl font-bold mt-2">{metric.value}</p>
                      </div>
                      <div className={`${metric.bg} p-3 rounded-full`}>
                        <Icon className={`w-6 h-6 ${metric.color}`} />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Recent Orders</CardTitle>
            <Link to={createPageUrl("AdminOrders")}>
              <Button variant="outline" size="sm">View All</Button>
            </Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentOrders.map((order) => {
                const orderItems = items.filter(i => i.order_id === order.id);
                return (
                  <Link key={order.id} to={createPageUrl(`AdminOrderDetail?id=${order.id}`)}>
                    <div className="flex items-center justify-between p-4 rounded-lg border hover:bg-neutral-50 dark:hover:bg-neutral-800 transition-colors cursor-pointer" style={{ borderColor: "var(--pm-border)" }}>
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <span className="font-semibold">{order.order_number}</span>
                          <PMBadge variant={STATUS_VARIANTS[order.status]}>{order.status.replace(/_/g, ' ')}</PMBadge>
                        </div>
                        <p className="text-sm mt-1" style={{ color: "var(--pm-text-muted)" }}>
                          {orderItems.length} item{orderItems.length !== 1 ? 's' : ''} · {new Date(order.created_date).toLocaleDateString()}
                        </p>
                      </div>
                      <span className="font-semibold">${(order.total || 0).toFixed(2)}</span>
                    </div>
                  </Link>
                );
              })}
              {recentOrders.length === 0 && (
                <p className="text-center py-8" style={{ color: "var(--pm-text-muted)" }}>No orders yet</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}