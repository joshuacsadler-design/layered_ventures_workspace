import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/components/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Trash2, ShoppingBag, ArrowRight, Loader2, ImageIcon } from "lucide-react";

export default function Cart() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      setUser(await base44.auth.me());
    })();
  }, []);

  const { data: draftOrders = [] } = useQuery({
    queryKey: ["cart-orders", user?.id],
    queryFn: () => base44.entities.Order.filter({ user_id: user.id, status: 'DRAFT' }),
    enabled: !!user,
  });

  const { data: items = [] } = useQuery({
    queryKey: ["cart-items", draftOrders[0]?.id],
    queryFn: () => base44.entities.OrderItem.filter({ order_id: draftOrders[0].id }),
    enabled: draftOrders.length > 0,
  });

  const { data: mounts = [] } = useQuery({
    queryKey: ["cart-mounts"],
    queryFn: () => base44.entities.MountOffering.list(),
    enabled: !!user,
  });

  const getMountLabel = (mountKey) => {
    const mount = mounts.find(m => m.key === mountKey);
    return mount?.label || mountKey;
  };

  const deleteMutation = useMutation({
    mutationFn: async (itemId) => {
      await base44.entities.OrderItem.delete(itemId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["cart-items"]);
      queryClient.invalidateQueries(["cart-orders"]);
    },
  });

  if (!user) return <div className="flex items-center justify-center min-h-screen"><Loader2 className="w-8 h-8 animate-spin" /></div>;

  const subtotal = items.reduce((sum, item) => sum + (item.unit_price * item.quantity), 0);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold mb-8">Shopping Cart</h1>

      {items.length === 0 ? (
        <div className="text-center py-20 rounded-2xl border" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}>
          <ShoppingBag className="w-16 h-16 mx-auto mb-4 opacity-20" />
          <p className="text-xl font-medium mb-4">Your cart is empty</p>
          <div className="flex justify-center gap-3">
            <Link to={createPageUrl("CreatePrint")}>
              <Button>Create a Print</Button>
            </Link>
            <Link to={createPageUrl("Gallery")}>
              <Button variant="outline">Browse Gallery</Button>
            </Link>
          </div>
        </div>
      ) : (
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Items */}
          <div className="lg:col-span-2 space-y-4">
            {items.map((item) => (
              <div key={item.id} className="rounded-xl border p-5 flex items-start gap-4" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}>
                <div className="w-20 h-20 rounded-lg bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center flex-shrink-0">
                  <ImageIcon className="w-8 h-8 opacity-20" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg">{item.title}</h3>
                  <p className="text-sm mt-1" style={{ color: "var(--pm-text-muted)" }}>
                    {item.size}" · {item.material === "puremetalreserve" ? "PureMetal Reserve" : "Standard"}
                    {item.mount_type && ` · ${getMountLabel(item.mount_type)}`}
                  </p>
                  <p className="text-sm mt-2">Qty: {item.quantity}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="font-semibold text-lg">${(item.unit_price * item.quantity).toFixed(2)}</p>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="mt-2 text-red-600 hover:text-red-700"
                    onClick={() => deleteMutation.mutate(item.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>

          {/* Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between text-sm">
                <span style={{ color: "var(--pm-text-muted)" }}>Subtotal</span>
                <span className="font-medium">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span style={{ color: "var(--pm-text-muted)" }}>Shipping</span>
                <span className="font-medium">Calculated at checkout</span>
              </div>
              <div className="flex justify-between text-sm">
                <span style={{ color: "var(--pm-text-muted)" }}>Tax</span>
                <span className="font-medium">Calculated at checkout</span>
              </div>
              <div className="border-t pt-4 flex justify-between text-lg font-bold" style={{ borderColor: "var(--pm-border)" }}>
                <span>Total</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <Link to={createPageUrl("Checkout")}>
                <Button className="w-full gap-2 bg-neutral-900 text-white hover:bg-neutral-800">
                  Proceed to Checkout <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}