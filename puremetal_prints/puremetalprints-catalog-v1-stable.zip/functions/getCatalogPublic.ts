import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const products = await base44.entities.Product.filter({ type: 'print', active: true });
    const productPrint = products[0] || null;

    let prices = [];
    if (productPrint) {
      prices = await base44.entities.ProductPrice.filter({ 
        product_id: productPrint.id, 
        active: true 
      });
    }

    const mounts = await base44.entities.MountOffering.filter({ active: true });
    const sortedMounts = mounts.sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));

    const services = await base44.entities.Product.filter({ type: 'service', active: true });

    return Response.json({
      product: productPrint,
      prices,
      mounts: sortedMounts,
      services,
      coupons_supported: true,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});