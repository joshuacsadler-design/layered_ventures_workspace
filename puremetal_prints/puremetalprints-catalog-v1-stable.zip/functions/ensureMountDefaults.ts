import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const defaults = [
      { key: 'PURESHADOW_NONE', label: 'No Mount (Desktop)', sort_order: 1, price_addon: 0 },
      { key: 'PURESHADOW_FLOAT', label: 'PureShadow Float Mount', sort_order: 2, price_addon: 0 },
      { key: 'PURESHADOW_STANDOFF', label: 'PureShadow Standoff Mount', sort_order: 3, price_addon: 0 },
      { key: 'PURESHADOW_EASEL', label: 'PureShadow Easel Back', sort_order: 4, price_addon: 0 },
    ];

    const created = [];
    const skipped = [];

    for (const def of defaults) {
      const existing = await base44.asServiceRole.entities.MountOffering.filter({ key: def.key });
      if (existing.length > 0) {
        skipped.push(def.key);
        continue;
      }

      // Generate SKU
      const skuResp = await base44.asServiceRole.functions.invoke('reserveSequentialSku', {
        category: 'PM-MOUNT',
        slug: def.key,
      });
      const sku = skuResp.data.sku;

      await base44.asServiceRole.entities.MountOffering.create({
        key: def.key,
        sku,
        label: def.label,
        active: true,
        sort_order: def.sort_order,
        price_addon: def.price_addon,
      });

      created.push(def.key);
    }

    return Response.json({
      ok: true,
      created,
      skipped,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});