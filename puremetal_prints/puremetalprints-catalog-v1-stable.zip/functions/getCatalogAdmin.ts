import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const products = await base44.asServiceRole.entities.Product.list();
    const prices = await base44.asServiceRole.entities.ProductPrice.list();
    const mounts = await base44.asServiceRole.entities.MountOffering.list();
    const coupons = await base44.asServiceRole.entities.Coupon.list();

    const services = products.filter(p => p.type === 'service');

    return Response.json({
      products,
      prices,
      mounts,
      coupons,
      services,
      counts: {
        products: products.length,
        prices: prices.length,
        mounts: mounts.length,
        coupons: coupons.length,
        services: services.length,
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});