import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

function normalizeSlug(input, maxLength = 18) {
  return input
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, '')
    .substring(0, maxLength);
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const { category, slug: rawSlug } = await req.json();

    if (!category || !rawSlug) {
      return Response.json({ error: 'category and slug are required' }, { status: 400 });
    }

    const slug = normalizeSlug(rawSlug);
    const namespace = `SKU:${category}:${slug}`;

    // Upsert registry
    const existing = await base44.asServiceRole.entities.CodeRegistry.filter({ namespace });
    let registry;
    if (existing.length > 0) {
      registry = existing[0];
    } else {
      registry = await base44.asServiceRole.entities.CodeRegistry.create({
        namespace,
        next_seq: 1,
      });
    }

    const seq = registry.next_seq;
    const seqStr = String(seq).padStart(3, '0');
    const sku = `${category}-${slug}-${seqStr}`;

    // Reserve code
    await base44.asServiceRole.entities.CodeReservation.create({
      code: sku,
      type: 'SKU',
      namespace,
    });

    // Increment sequence
    await base44.asServiceRole.entities.CodeRegistry.update(registry.id, {
      next_seq: seq + 1,
    });

    return Response.json({
      sku,
      seq,
      namespace,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});