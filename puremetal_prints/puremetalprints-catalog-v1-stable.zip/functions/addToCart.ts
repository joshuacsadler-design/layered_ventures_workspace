import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { product_id, variant_key, quantity = 1, mount_key } = await req.json();

    if (!product_id || !variant_key || !mount_key) {
      return Response.json({ 
        error: 'product_id, variant_key, and mount_key are required' 
      }, { status: 400 });
    }

    // Validate product
    const product = await base44.asServiceRole.entities.Product.get(product_id);
    if (!product || !product.active) {
      return Response.json({ error: 'Product not available' }, { status: 400 });
    }

    // Validate variant
    const prices = await base44.asServiceRole.entities.ProductPrice.filter({
      product_id,
      variant_key,
    });

    if (prices.length === 0 || !prices[0].active) {
      return Response.json({ error: 'Product variant not available' }, { status: 400 });
    }

    const price = prices[0];

    // Validate mount
    const mounts = await base44.asServiceRole.entities.MountOffering.filter({ key: mount_key });
    if (mounts.length === 0 || !mounts[0].active) {
      return Response.json({ error: 'Mount option not available' }, { status: 400 });
    }

    const mount = mounts[0];

    // Get or create draft order
    const orders = await base44.asServiceRole.entities.Order.filter({
      user_id: user.id,
      status: 'DRAFT',
    });

    let order;
    if (orders.length > 0) {
      order = orders[0];
    } else {
      order = await base44.asServiceRole.entities.Order.create({
        user_id: user.id,
        status: 'DRAFT',
        subtotal: 0,
        shipping: 0,
        tax: 0,
        total: 0,
      });
    }

    // Create order item
    const unitPrice = price.price + mount.price_addon;

    const item = await base44.asServiceRole.entities.OrderItem.create({
      order_id: order.id,
      product_id: product.id,
      sku: product.sku,
      title: product.name,
      size: price.size || '',
      material: price.tier || 'standard',
      mount_type: mount_key,
      quantity,
      unit_price: unitPrice,
      status: 'PENDING',
    });

    // Recalculate order totals
    const allItems = await base44.asServiceRole.entities.OrderItem.filter({ order_id: order.id });
    const subtotal = allItems.reduce((sum, i) => sum + (i.unit_price * i.quantity), 0);

    await base44.asServiceRole.entities.Order.update(order.id, {
      subtotal,
      total: subtotal,
    });

    return Response.json({
      ok: true,
      order_id: order.id,
      item_id: item.id,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});