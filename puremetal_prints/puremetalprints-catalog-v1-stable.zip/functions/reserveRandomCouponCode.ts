import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

function randomToken(length = 8) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const { discount_type } = await req.json();

    if (!discount_type) {
      return Response.json({ error: 'discount_type is required' }, { status: 400 });
    }

    const prefixMap = {
      'PERCENT': 'PM-PCT-',
      'AMOUNT': 'PM-AMT-',
      'FREE_SHIPPING': 'PM-SHIP-',
    };

    const prefix = prefixMap[discount_type] || 'PM-';
    const namespace = `COUPON:${prefix}`;

    let attempts = 0;
    let code = null;

    while (!code && attempts < 100) {
      const token = randomToken(8);
      const candidate = prefix + token;

      const existing = await base44.asServiceRole.entities.CodeReservation.filter({ code: candidate });
      if (existing.length === 0) {
        await base44.asServiceRole.entities.CodeReservation.create({
          code: candidate,
          type: 'COUPON',
          namespace,
        });
        code = candidate;
      }

      attempts++;
    }

    if (!code) {
      return Response.json({ error: 'Failed to generate unique coupon code' }, { status: 500 });
    }

    return Response.json({ code });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});