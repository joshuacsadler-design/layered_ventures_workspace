import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { 
      brand_slug = 'PURESHADOW', 
      mount_type, 
      label, 
      description, 
      price_addon = 0, 
      active = true, 
      sort_order = 0 
    } = await req.json();

    if (!mount_type || !label) {
      return Response.json({ error: 'mount_type and label are required' }, { status: 400 });
    }

    const key = `${brand_slug}_${mount_type}`.toUpperCase().replace(/[^A-Z0-9]+/g, '_');

    const existing = await base44.asServiceRole.entities.MountOffering.filter({ key });
    if (existing.length > 0) {
      return Response.json({ error: 'Mount with this key already exists' }, { status: 400 });
    }

    const skuResp = await base44.asServiceRole.functions.invoke('reserveSequentialSku', {
      category: 'PM-MOUNT',
      slug: key,
    });
    const sku = skuResp.data.sku;

    const mount = await base44.asServiceRole.entities.MountOffering.create({
      key,
      sku,
      label,
      description: description || '',
      active,
      sort_order,
      price_addon,
    });

    return Response.json({
      ok: true,
      mount: {
        id: mount.id,
        key: mount.key,
        sku: mount.sku,
        label: mount.label,
        price_addon: mount.price_addon,
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});