import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // This function can be called internally without user auth
    const { action, entity_type, entity_id, user_id, before_state, after_state, details, notes } = await req.json();

    if (!action || !entity_type) {
      return Response.json({ error: 'action and entity_type required' }, { status: 400 });
    }

    // Create audit log using service role (append-only, no updates allowed)
    await base44.asServiceRole.entities.AuditLog.create({
      entity_type: entity_type,
      entity_id: entity_id || null,
      action: action,
      user_id: user_id || null,
      before_state: before_state || null,
      after_state: after_state || null,
      notes: notes || (details ? JSON.stringify(details) : null),
    });

    return Response.json({ success: true });
  } catch (error) {
    console.error('Audit log error:', error);
    // Never block the main operation due to audit failure
    return Response.json({ error: error.message }, { status: 500 });
  }
});