import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { type, name, description, active = true } = await req.json();

    if (!type || !name) {
      return Response.json({ error: 'type and name are required' }, { status: 400 });
    }

    const categoryMap = {
      'print': 'PM-METAL',
      'service': 'PM-SERV',
      'mount': 'PM-MOUNT',
      'addon': 'PM-ADDON',
    };

    const category = categoryMap[type] || 'PM-MISC';

    const skuResp = await base44.functions.invoke('reserveSequentialSku', {
      category,
      slug: name,
    });
    const productSku = skuResp.data.sku;

    const product = await base44.asServiceRole.entities.Product.create({
      sku: productSku,
      name,
      type,
      description: description || '',
      active,
    });

    return Response.json({
      ok: true,
      product: {
        id: product.id,
        sku: product.sku,
        name: product.name,
        type: product.type,
        description: product.description,
        active: product.active,
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});