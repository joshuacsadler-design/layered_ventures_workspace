import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    console.log('[SEED] Starting ensureSeedProducts');
    const base44 = createClientFromRequest(req);
    console.log('[SEED] Base44 client created');
    
    const user = await base44.auth.me();
    console.log('[SEED] User authenticated:', user?.id, user?.role);

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    // ONE product: Metal Print
    const METAL_PRINT_SKU = 'PM-METAL';
    
    // Upsert base product
    const existingProducts = await base44.asServiceRole.entities.Product.filter({ sku: METAL_PRINT_SKU });
    let metalPrintProduct;
    
    if (existingProducts.length > 0) {
      metalPrintProduct = existingProducts[0];
      console.log(`[SEED] Product ${METAL_PRINT_SKU} already exists (ID: ${metalPrintProduct.id})`);
    } else {
      metalPrintProduct = await base44.asServiceRole.entities.Product.create({
        sku: METAL_PRINT_SKU,
        name: 'Metal Print',
        type: 'print',
        active: true,
        description: 'Premium dye-sublimation aluminum prints produced by the PureMetal studio.',
      });
      console.log(`[SEED] Product created: ${METAL_PRINT_SKU} (ID: ${metalPrintProduct.id})`);
    }

    // NEW LOCKED PRICING MATRIX (authoritative)
    const priceMatrix = [
      { size: '6x8', material: 'standard', price: 20 },
      { size: '8x10', material: 'standard', price: 30 },
      { size: '8x12', material: 'standard', price: 40 },
      { size: '6x8', material: 'puremetalreserve', price: 40 },
      { size: '8x10', material: 'puremetalreserve', price: 50 },
      { size: '8x12', material: 'puremetalreserve', price: 60 },
    ];

    console.log('[SEED] Syncing price variants (upsert by variant_key)...');
    const syncedPrices = [];

    for (const priceSpec of priceMatrix) {
      const variantKey = `${priceSpec.size}-${priceSpec.material}`;
      
      // Check if price already exists
      const existingPrices = await base44.asServiceRole.entities.ProductPrice.filter({ 
        product_id: metalPrintProduct.id, 
        variant_key: variantKey 
      });
      
      if (existingPrices.length > 0) {
        // UPDATE existing price
        const existingPrice = existingPrices[0];
        console.log(`[SEED] Updating price: ${variantKey} from $${existingPrice.price} to $${priceSpec.price}`);
        
        await base44.asServiceRole.entities.ProductPrice.update(existingPrice.id, {
          price: priceSpec.price,
          active: true,
          size: priceSpec.size,
          material: priceSpec.material,
        });
        
        syncedPrices.push({ ...existingPrice, price: priceSpec.price, active: true });
      } else {
        // CREATE new price
        console.log(`[SEED] Creating price: ${variantKey} = $${priceSpec.price}`);
        
        try {
          const priceRecord = await base44.asServiceRole.entities.ProductPrice.create({
            product_id: metalPrintProduct.id,
            variant_key: variantKey,
            size: priceSpec.size,
            material: priceSpec.material,
            price: priceSpec.price,
            active: true,
          });
          console.log(`[SEED] Price created: ${variantKey} (ID: ${priceRecord.id})`);
          syncedPrices.push(priceRecord);
        } catch (priceError) {
          console.error(`[SEED] Failed to create price ${variantKey}:`, priceError);
          throw new Error(`Price creation failed for ${variantKey}: ${priceError.message}`);
        }
      }
    }

    console.log('[SEED] Prices synced, invoking audit log...');
    // Log audit
    try {
      await base44.functions.invoke('logAudit', {
        action: 'PRODUCTS_SYNCED',
        entity_type: 'Product',
        entity_id: metalPrintProduct.id,
        details: { 
          product_count: 1, 
          price_count: syncedPrices.length,
          total_variants: priceMatrix.length
        },
      });
      console.log('[SEED] Audit log created');
    } catch (auditError) {
      console.error('[SEED] Audit log failed (non-critical):', auditError);
    }

    // Query final state for verification
    console.log('[SEED] Querying final database state...');
    const allPrices = await base44.asServiceRole.entities.ProductPrice.filter({ product_id: metalPrintProduct.id });

    console.log('[SEED] Success! Returning verification payload.');
    return Response.json({
      ok: true,
      product: {
        id: metalPrintProduct.id,
        sku: metalPrintProduct.sku,
        name: metalPrintProduct.name,
        active: metalPrintProduct.active
      },
      prices: allPrices.map(pr => ({
        variant_key: pr.variant_key,
        size: pr.size,
        material: pr.material,
        price: pr.price,
        active: pr.active
      }))
    });
  } catch (error) {
    console.error('[SEED] FATAL ERROR:', error);
    console.error('[SEED] Error name:', error.name);
    console.error('[SEED] Error message:', error.message);
    console.error('[SEED] Error stack:', error.stack);
    
    return Response.json({ 
      error: error.message,
      name: error.name,
      stack: error.stack,
      details: error.cause || error.response?.data || 'No additional details',
    }, { status: 500 });
  }
});