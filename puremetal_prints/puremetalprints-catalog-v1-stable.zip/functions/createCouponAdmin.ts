import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const {
      name,
      discount_type,
      percent_off,
      amount_off,
      currency = 'USD',
      applies_to = 'ORDER',
      product_skus,
      min_order_amount,
      max_redemptions,
      start_at,
      end_at,
      active = true,
      notes,
    } = await req.json();

    if (!name || !discount_type) {
      return Response.json({ error: 'name and discount_type are required' }, { status: 400 });
    }

    const codeResp = await base44.asServiceRole.functions.invoke('reserveRandomCouponCode', { discount_type });
    const code = codeResp.data.code;

    const coupon = await base44.asServiceRole.entities.Coupon.create({
      code,
      name,
      discount_type,
      percent_off: percent_off || null,
      amount_off: amount_off || null,
      currency,
      applies_to,
      product_skus: product_skus || null,
      min_order_amount: min_order_amount || null,
      max_redemptions: max_redemptions || null,
      redemption_count: 0,
      start_at: start_at || null,
      end_at: end_at || null,
      active,
      notes: notes || '',
    });

    return Response.json({
      ok: true,
      coupon: {
        id: coupon.id,
        code: coupon.code,
        name: coupon.name,
        discount_type: coupon.discount_type,
        active: coupon.active,
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});