/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import Account from './pages/Account';
import AdminAI from './pages/AdminAI';
import AdminAnalyzer from './pages/AdminAnalyzer';
import AdminCancellations from './pages/AdminCancellations';
import AdminClientDetail from './pages/AdminClientDetail';
import AdminClients from './pages/AdminClients';
import AdminCoupons from './pages/AdminCoupons';
import AdminDashboard from './pages/AdminDashboard';
import AdminGallery from './pages/AdminGallery';
import AdminHealth from './pages/AdminHealth';
import AdminLegacyAttachments from './pages/AdminLegacyAttachments';
import AdminMessages from './pages/AdminMessages';
import AdminMounts from './pages/AdminMounts';
import AdminOrderDetail from './pages/AdminOrderDetail';
import AdminOrders from './pages/AdminOrders';
import AdminProducts from './pages/AdminProducts';
import AdminServices from './pages/AdminServices';
import AdminSettings from './pages/AdminSettings';
import AdminShipping from './pages/AdminShipping';
import AdminSiteContent from './pages/AdminSiteContent';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import Contact from './pages/Contact';
import CreatePrint from './pages/CreatePrint';
import Gallery from './pages/Gallery';
import Home from './pages/Home';
import OrderDetail from './pages/OrderDetail';
import ProductionSheet from './pages/ProductionSheet';
import Shop from './pages/Shop';
import health from './pages/__health';
import createPrint from './pages/create-print';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Account": Account,
    "AdminAI": AdminAI,
    "AdminAnalyzer": AdminAnalyzer,
    "AdminCancellations": AdminCancellations,
    "AdminClientDetail": AdminClientDetail,
    "AdminClients": AdminClients,
    "AdminCoupons": AdminCoupons,
    "AdminDashboard": AdminDashboard,
    "AdminGallery": AdminGallery,
    "AdminHealth": AdminHealth,
    "AdminLegacyAttachments": AdminLegacyAttachments,
    "AdminMessages": AdminMessages,
    "AdminMounts": AdminMounts,
    "AdminOrderDetail": AdminOrderDetail,
    "AdminOrders": AdminOrders,
    "AdminProducts": AdminProducts,
    "AdminServices": AdminServices,
    "AdminSettings": AdminSettings,
    "AdminShipping": AdminShipping,
    "AdminSiteContent": AdminSiteContent,
    "Cart": Cart,
    "Checkout": Checkout,
    "Contact": Contact,
    "CreatePrint": CreatePrint,
    "Gallery": Gallery,
    "Home": Home,
    "OrderDetail": OrderDetail,
    "ProductionSheet": ProductionSheet,
    "Shop": Shop,
    "__health": health,
    "create-print": createPrint,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: __Layout,
};