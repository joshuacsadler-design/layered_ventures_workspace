import React from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function AdminTopbar({ title, showBack = false, actions = null }) {
  const navigate = useNavigate();

  const handleBack = () => {
    if (window.history.length > 1) {
      navigate(-1);
    } else {
      navigate(createPageUrl("AdminDashboard"));
    }
  };

  return (
    <div className="border-b px-6 py-4 flex items-center justify-between" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}>
      <div className="flex items-center gap-3">
        {showBack && (
          <Button variant="ghost" size="icon" onClick={handleBack} className="rounded-lg">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        )}
        <h1 className="text-xl font-semibold">{title}</h1>
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}