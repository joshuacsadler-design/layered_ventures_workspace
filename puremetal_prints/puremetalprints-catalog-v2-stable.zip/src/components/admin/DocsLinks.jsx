import React from "react";
import { FileText, Shield } from "lucide-react";

export default function DocsLinks() {
  const docs = [
    {
      title: "Architecture Blueprint",
      description: "Reusable skeleton, entities, functions, and rules",
      icon: FileText,
      url: "https://github.com/yourusername/yourrepo/blob/main/docs/SKELETON_BASE44.md",
      color: "text-blue-600 bg-blue-50",
    },
    {
      title: "V1 Lock Rules",
      description: "Catalog boundaries, invariants, and migration guide",
      icon: Shield,
      url: "https://github.com/yourusername/yourrepo/blob/main/docs/V1_LOCK_RULES.md",
      color: "text-purple-600 bg-purple-50",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {docs.map((doc, idx) => {
        const Icon = doc.icon;
        return (
          <a
            key={idx}
            href={doc.url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-start gap-3 p-4 rounded-lg border hover:shadow-md transition-all"
            style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}
          >
            <div className={`p-2 rounded ${doc.color}`}>
              <Icon className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-sm">{doc.title}</div>
              <div className="text-xs mt-1" style={{ color: "var(--pm-text-muted)" }}>
                {doc.description}
              </div>
            </div>
          </a>
        );
      })}
    </div>
  );
}