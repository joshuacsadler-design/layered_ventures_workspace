import React from "react";

const variants = {
  default: "bg-neutral-100 text-neutral-700 dark:bg-neutral-800 dark:text-neutral-300",
  success: "bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400",
  warning: "bg-amber-50 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400",
  error: "bg-red-50 text-red-700 dark:bg-red-900/30 dark:text-red-400",
  purple: "bg-purple-50 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400",
  gold: "bg-amber-50 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
};

export default function PMBadge({ children, variant = "default", className = "" }) {
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${variants[variant] || variants.default} ${className}`}>
      {children}
    </span>
  );
}