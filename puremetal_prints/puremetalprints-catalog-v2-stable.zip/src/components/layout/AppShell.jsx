import React from "react";

export default function AppShell({ children, maxWidth = "7xl", className = "" }) {
  return (
    <div className={`w-full px-4 sm:px-6 lg:px-8 py-8 mx-auto max-w-${maxWidth} ${className}`}>
      {children}
    </div>
  );
}