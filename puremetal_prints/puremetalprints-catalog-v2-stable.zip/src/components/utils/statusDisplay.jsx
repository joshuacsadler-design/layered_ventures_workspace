// Client-facing status display labels
export const CLIENT_STATUS_LABELS = {
  DRAFT: "Draft",
  UPLOADED: "Uploaded",
  NEEDS_REVIEW: "In Preparation",
  PROOF_DELIVERED: "Proof Ready",
  PROOF_SELECTED: "Proof Ready",
  APPROVED: "Approved",
  IN_PRODUCTION: "In Production",
  COMPLETED: "Completed",
  CANCELLATION_REQUESTED: "Cancellation Requested",
  CANCELLED: "Cancelled",
  
  // Item statuses
  PENDING: "Pending",
  IN_PROOFING: "In Preparation",
  PROOF_DELIVERED: "Proof Ready",
};

export function getClientStatusLabel(status) {
  return CLIENT_STATUS_LABELS[status] || status.replace(/_/g, ' ');
}