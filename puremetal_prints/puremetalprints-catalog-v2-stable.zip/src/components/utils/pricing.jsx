// Fallback pricing if database is empty
export const FALLBACK_PRICES = {
  "6x8-standard": 20,
  "8x10-standard": 30,
  "8x12-standard": 40,
  "8x12-puremetalreserve": 60,
  "PS-MOUNT-STD": 7,
  "PS-MOUNT-BLK": 10,
};

export function getPriceFallback(variantKey) {
  return FALLBACK_PRICES[variantKey] || 0;
}

export function formatMoney(amount, currency = "USD") {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
  }).format(amount);
}

export function safeJsonParse(str, fallback = null) {
  try {
    return JSON.parse(str);
  } catch {
    return fallback;
  }
}