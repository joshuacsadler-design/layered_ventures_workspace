import React from "react";
import Navbar from "./components/layout/Navbar";
import Footer from "./components/layout/Footer";

export default function Layout({ children, currentPageName }) {
  const isAdmin = currentPageName?.startsWith("Admin");
  const isPrintPage = currentPageName === "ProductionSheet";

  if (isPrintPage) {
    return <div className="min-h-screen">{children}</div>;
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: "var(--pm-bg)" }}>
      <Navbar />
      <main className="flex-1">{children}</main>
      {!isAdmin && <Footer />}
    </div>
  );
}