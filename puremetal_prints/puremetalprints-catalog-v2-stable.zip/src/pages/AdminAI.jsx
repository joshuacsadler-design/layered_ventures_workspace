import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Sparkles, Loader2, RefreshCw, Image as ImageIcon } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export default function AdminAI() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState("");
  const [selectedItem, setSelectedItem] = useState("");
  const [running, setRunning] = useState(false);

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      const me = await base44.auth.me();
      if (me.role !== "admin") { window.location.href = "/"; return; }
      setUser(me);
    })();
  }, []);

  const { data: orders = [] } = useQuery({
    queryKey: ["ai-orders"],
    queryFn: () => base44.entities.PMOrders.list("-created_date", 100),
    enabled: !!user,
  });

  const { data: items = [] } = useQuery({
    queryKey: ["ai-items", selectedOrder],
    queryFn: () => base44.entities.PMOrderItems.filter({ order_id: selectedOrder }),
    enabled: !!selectedOrder,
  });

  const { data: jobs = [] } = useQuery({
    queryKey: ["ai-jobs"],
    queryFn: () => base44.entities.PMAIJobs.list("-created_date", 50),
    enabled: !!user,
  });

  const runAnalysis = async () => {
    if (!selectedItem) return;
    setRunning(true);
    const item = items.find(i => i.id === selectedItem);
    if (!item?.original_upload_url) { setRunning(false); return; }

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Analyze this image for metal print production. Assess:
1. Resolution quality and DPI estimate
2. Color profile suitability for premium aluminum metal printing
3. Contrast and brightness recommendations
4. Recommended crop/sizing for ${item.size}" format
5. Enhancement suggestions (sharpening, color adjustments)
6. Overall print quality score (1-10)

Provide actionable recommendations for the print technician.`,
      file_urls: [item.original_upload_url],
      response_json_schema: {
        type: "object",
        properties: {
          quality_score: { type: "number" },
          resolution_assessment: { type: "string" },
          color_profile_notes: { type: "string" },
          contrast_brightness: { type: "string" },
          crop_recommendation: { type: "string" },
          enhancement_suggestions: { type: "array", items: { type: "string" } },
          overall_notes: { type: "string" },
        },
      },
    });

    await base44.entities.PMAIJobs.create({
      order_item_id: selectedItem,
      user_id: item.user_id,
      input_url: item.original_upload_url,
      job_type: "analyze",
      result_json: result,
      recommended_settings: { suggestions: result.enhancement_suggestions },
      outcome_score: result.quality_score,
      printer_notes: result.overall_notes,
    });

    queryClient.invalidateQueries({ queryKey: ["ai-jobs"] });
    setRunning(false);
  };

  if (!user) return null;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center gap-3 mb-8">
        <Sparkles className="w-6 h-6 text-purple-500" />
        <h1 className="text-2xl font-bold">AI Enhancement Tools</h1>
      </div>

      {/* Run analysis */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Analyze Client Image</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <p className="text-sm font-medium mb-1.5">Select Order</p>
              <Select value={selectedOrder} onValueChange={(v) => { setSelectedOrder(v); setSelectedItem(""); }}>
                <SelectTrigger><SelectValue placeholder="Choose order..." /></SelectTrigger>
                <SelectContent>
                  {orders.filter(o => o.status !== "Draft").map(o => (
                    <SelectItem key={o.id} value={o.id}>{o.order_number} — {o.client_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <p className="text-sm font-medium mb-1.5">Select Item</p>
              <Select value={selectedItem} onValueChange={setSelectedItem} disabled={!selectedOrder}>
                <SelectTrigger><SelectValue placeholder="Choose item..." /></SelectTrigger>
                <SelectContent>
                  {items.filter(i => i.item_type === "print").map(i => (
                    <SelectItem key={i.id} value={i.id}>{i.product_name} ({i.size}")</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          {selectedItem && items.find(i => i.id === selectedItem)?.original_upload_url && (
            <div className="w-32 h-32 rounded-lg overflow-hidden bg-neutral-100 dark:bg-neutral-800">
              <img src={items.find(i => i.id === selectedItem).original_upload_url} alt="" className="w-full h-full object-cover" />
            </div>
          )}
          <Button onClick={runAnalysis} disabled={!selectedItem || running} className="gap-2 bg-purple-600 hover:bg-purple-700 text-white">
            {running ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            Run AI Analysis
          </Button>
        </CardContent>
      </Card>

      {/* Past Jobs */}
      <h2 className="text-lg font-semibold mb-4">Analysis History</h2>
      <div className="space-y-3">
        {jobs.map((job) => (
          <Card key={job.id}>
            <CardContent className="pt-5">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="text-sm font-medium">Job: {job.job_type}</p>
                  <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>{new Date(job.created_date).toLocaleString()}</p>
                </div>
                {job.outcome_score && (
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-bold">{job.outcome_score}/10</span>
                    <span className="text-xs" style={{ color: "var(--pm-text-muted)" }}>Quality</span>
                  </div>
                )}
              </div>
              {job.result_json && (
                <div className="text-sm space-y-2">
                  {job.result_json.resolution_assessment && <p><strong>Resolution:</strong> {job.result_json.resolution_assessment}</p>}
                  {job.result_json.color_profile_notes && <p><strong>Color:</strong> {job.result_json.color_profile_notes}</p>}
                  {job.result_json.contrast_brightness && <p><strong>Contrast:</strong> {job.result_json.contrast_brightness}</p>}
                  {job.result_json.crop_recommendation && <p><strong>Crop:</strong> {job.result_json.crop_recommendation}</p>}
                  {job.result_json.enhancement_suggestions?.length > 0 && (
                    <div>
                      <strong>Enhancements:</strong>
                      <ul className="list-disc ml-5 mt-1">
                        {job.result_json.enhancement_suggestions.map((s, i) => <li key={i}>{s}</li>)}
                      </ul>
                    </div>
                  )}
                  {job.printer_notes && <p className="mt-2 text-xs p-2 rounded bg-neutral-50 dark:bg-neutral-800">{job.printer_notes}</p>}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
        {jobs.length === 0 && <p className="text-center py-8 text-sm" style={{ color: "var(--pm-text-muted)" }}>No AI analyses yet.</p>}
      </div>
    </div>
  );
}