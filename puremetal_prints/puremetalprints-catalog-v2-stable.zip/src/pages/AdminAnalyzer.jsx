import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import AdminLayout from "@/components/admin/AdminLayout";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Play, History, RotateCcw, AlertCircle, CheckCircle, AlertTriangle, Upload, Download, File } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

export default function AdminAnalyzer() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [selectedItem, setSelectedItem] = useState(null);
  const [showHistory, setShowHistory] = useState(false);
  const [historyItem, setHistoryItem] = useState(null);
  
  // Upload state
  const [uploadMode, setUploadMode] = useState('attach'); // 'attach' | 'adhoc'
  const [uploadFile, setUploadFile] = useState(null);
  const [uploadNotes, setUploadNotes] = useState('');
  const [selectedOrderItemId, setSelectedOrderItemId] = useState('');
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) {
        navigate('/');
        return;
      }
      const user = await base44.auth.me();
      if (user.role !== 'admin') {
        navigate('/');
      }
    })();
  }, [navigate]);

  const { data, isLoading } = useQuery({
    queryKey: ["analyzer-queue"],
    queryFn: async () => (await base44.functions.invoke("getAnalyzerQueueAdmin", {})).data,
  });

  const { data: historyData, isLoading: historyLoading } = useQuery({
    queryKey: ["analyzer-history", historyItem?.id],
    queryFn: async () => (await base44.functions.invoke("getAnalyzerHistoryForItemAdmin", { order_item_id: historyItem.id })).data,
    enabled: !!historyItem,
  });

  const { data: adHocData } = useQuery({
    queryKey: ["analyzer-adhoc"],
    queryFn: async () => (await base44.functions.invoke("getAnalyzerAdHocJobsAdmin", {})).data,
  });

  const adHocJobs = adHocData?.jobs ?? [];

  const runAnalysis = useMutation({
    mutationFn: (order_item_id) => base44.functions.invoke("runAnalyzerForOrderItemAdmin", { order_item_id }),
    onSuccess: () => {
      qc.invalidateQueries(["analyzer-queue"]);
      alert("Analysis complete");
    },
  });

  const clearStatus = useMutation({
    mutationFn: (order_item_id) => base44.functions.invoke("clearAnalyzerResultAdmin", { order_item_id }),
    onSuccess: () => {
      qc.invalidateQueries(["analyzer-queue"]);
    },
  });

  const runAdHocAnalysis = useMutation({
    mutationFn: (analysis_job_id) => base44.functions.invoke("runAnalyzerAdHocAdmin", { analysis_job_id }),
    onSuccess: () => {
      qc.invalidateQueries(["analyzer-adhoc"]);
      alert("Ad-hoc analysis complete");
    },
  });

  const handleFileUpload = async () => {
    if (!uploadFile) {
      alert('Please select a file');
      return;
    }

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', uploadFile);
      
      const resp = await base44.integrations.Core.UploadPrivateFile({ file: uploadFile });
      const file_id = resp.file_uri;
      
      const metadata = {
        input_file_id: file_id,
        input_filename: uploadFile.name,
        input_mime_type: uploadFile.type,
        input_byte_size: uploadFile.size
      };

      if (uploadMode === 'attach') {
        if (!selectedOrderItemId) {
          alert('Please select an order item');
          return;
        }
        await base44.functions.invoke('attachAnalyzerFileToOrderItemAdmin', {
          order_item_id: selectedOrderItemId,
          ...metadata
        });
        alert('File attached successfully');
        qc.invalidateQueries(['analyzer-queue']);
      } else {
        await base44.functions.invoke('createAdHocAnalyzerJobAdmin', {
          ...metadata,
          input_notes: uploadNotes || null
        });
        alert('Ad-hoc job created successfully');
        qc.invalidateQueries(['analyzer-adhoc']);
      }

      setUploadFile(null);
      setUploadNotes('');
      setSelectedOrderItemId('');
    } catch (error) {
      alert('Upload failed: ' + error.message);
    } finally {
      setUploading(false);
    }
  };

  const downloadFile = async (file_id) => {
    try {
      const resp = await base44.functions.invoke('getAnalyzerFileDownloadUrlAdmin', { file_id });
      window.open(resp.data.url, '_blank');
    } catch (error) {
      alert('Download failed: ' + error.message);
    }
  };

  const items = data?.items ?? [];

  const getVerdictIcon = (verdict) => {
    if (verdict === 'OK') return <CheckCircle className="w-4 h-4 text-green-600" />;
    if (verdict === 'WARN') return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
    if (verdict === 'FAIL') return <AlertCircle className="w-4 h-4 text-red-600" />;
    return null;
  };

  const getVerdictBadge = (verdict) => {
    if (verdict === 'OK') return <Badge className="bg-green-100 text-green-800">OK</Badge>;
    if (verdict === 'WARN') return <Badge className="bg-yellow-100 text-yellow-800">WARN</Badge>;
    if (verdict === 'FAIL') return <Badge className="bg-red-100 text-red-800">FAIL</Badge>;
    return <Badge>-</Badge>;
  };

  if (isLoading) {
    return (
      <AdminLayout title="Analyzer">
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout title="Analyzer">
      <div className="space-y-6">
        <div>
          <p className="text-sm text-muted-foreground">
            Manual-first: analysis runs only when you click. Uploads are private; downloads use expiring links.
          </p>
        </div>

        {/* Upload Section */}
        <Card>
          <CardHeader>
            <CardTitle>Upload to Analyzer</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Mode</Label>
              <Select value={uploadMode} onValueChange={setUploadMode}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="attach">Attach to Order Item</SelectItem>
                  <SelectItem value="adhoc">Ad-hoc Upload</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>File</Label>
              <Input
                type="file"
                onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
                disabled={uploading}
              />
              {uploadFile && (
                <p className="text-xs text-muted-foreground mt-1">
                  {uploadFile.name} ({(uploadFile.size / 1024).toFixed(1)} KB)
                </p>
              )}
            </div>

            {uploadMode === 'attach' && (
              <div>
                <Label>Order Item</Label>
                <Select value={selectedOrderItemId} onValueChange={setSelectedOrderItemId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select order item..." />
                  </SelectTrigger>
                  <SelectContent>
                    {items.map(item => (
                      <SelectItem key={item.id} value={item.id}>
                        Order {item.order_id?.slice(-8)} - {item.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {uploadMode === 'adhoc' && (
              <div>
                <Label>Notes (optional)</Label>
                <Textarea
                  value={uploadNotes}
                  onChange={(e) => setUploadNotes(e.target.value)}
                  placeholder="Add any context or notes..."
                  rows={3}
                />
              </div>
            )}

            <Button onClick={handleFileUpload} disabled={uploading || !uploadFile}>
              <Upload className="w-4 h-4 mr-2" />
              {uploading ? 'Uploading...' : (uploadMode === 'attach' ? 'Attach File' : 'Create Ad-hoc Job')}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Order Items Queue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-2 font-medium">Order</th>
                    <th className="text-left p-2 font-medium">Client</th>
                    <th className="text-left p-2 font-medium">Item</th>
                    <th className="text-left p-2 font-medium">Size</th>
                    <th className="text-left p-2 font-medium">Tier</th>
                    <th className="text-left p-2 font-medium">Mount</th>
                    <th className="text-left p-2 font-medium">Qty</th>
                    <th className="text-left p-2 font-medium">Status</th>
                    <th className="text-left p-2 font-medium">Result</th>
                    <th className="text-right p-2 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((item) => (
                    <tr key={item.id} className="border-b hover:bg-muted/50">
                      <td className="p-2">
                        <div className="flex items-center gap-1">
                          <span className="text-xs font-mono">{item.order_id?.slice(-8)}</span>
                          {item.analyzer_input_file_id && (
                            <File className="w-3 h-3 text-blue-600" title="File attached" />
                          )}
                        </div>
                      </td>
                      <td className="p-2">
                        <div className="text-xs">
                          <div className="font-medium">{item.client_name || 'N/A'}</div>
                          <div className="text-muted-foreground">{item.client_email}</div>
                        </div>
                      </td>
                      <td className="p-2">
                        <div className="text-xs">
                          <div className="font-medium">{item.title}</div>
                          <div className="text-muted-foreground">{item.kind}</div>
                        </div>
                      </td>
                      <td className="p-2 text-xs">{item.size || '-'}</td>
                      <td className="p-2 text-xs">{item.tier || '-'}</td>
                      <td className="p-2 text-xs">{item.mount_key || '-'}</td>
                      <td className="p-2 text-xs">{item.quantity || 1}</td>
                      <td className="p-2">
                        <Badge variant="outline" className="text-xs">
                          {item.analyzer_status || 'NONE'}
                        </Badge>
                      </td>
                      <td className="p-2">
                        {item.latest_result ? (
                          <div className="flex items-center gap-1">
                            {getVerdictIcon(item.latest_result.verdict)}
                            {getVerdictBadge(item.latest_result.verdict)}
                          </div>
                        ) : (
                          <span className="text-xs text-muted-foreground">-</span>
                        )}
                      </td>
                      <td className="p-2">
                        <div className="flex justify-end gap-1">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => runAnalysis.mutate(item.id)}
                            disabled={runAnalysis.isPending}
                          >
                            <Play className="w-3 h-3 mr-1" />
                            Run
                          </Button>
                          {item.analyzer_input_file_id && (
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => downloadFile(item.analyzer_input_file_id)}
                            >
                              <Download className="w-3 h-3" />
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => {
                              setSelectedItem(item);
                            }}
                            disabled={!item.latest_result}
                          >
                            View
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => {
                              setHistoryItem(item);
                              setShowHistory(true);
                            }}
                          >
                            <History className="w-3 h-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => clearStatus.mutate(item.id)}
                            disabled={clearStatus.isPending || item.analyzer_status === 'NONE'}
                          >
                            <RotateCcw className="w-3 h-3" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Ad-hoc Jobs */}
        {adHocJobs.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Ad-hoc Jobs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {adHocJobs.map((job) => (
                  <div key={job.id} className="border rounded p-3">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <File className="w-4 h-4" />
                          <span className="font-medium text-sm">{job.input_filename || 'Unknown file'}</span>
                          <Badge variant="outline" className="text-xs">{job.status}</Badge>
                        </div>
                        {job.input_notes && (
                          <p className="text-xs text-muted-foreground mb-2">{job.input_notes}</p>
                        )}
                        <p className="text-xs text-muted-foreground">
                          Created: {new Date(job.created_date).toLocaleString()}
                        </p>
                        {job.latest_result && (
                          <div className="flex items-center gap-2 mt-2">
                            {getVerdictIcon(job.latest_result.verdict)}
                            {getVerdictBadge(job.latest_result.verdict)}
                          </div>
                        )}
                      </div>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => runAdHocAnalysis.mutate(job.id)}
                          disabled={runAdHocAnalysis.isPending || job.status === 'COMPLETED'}
                        >
                          <Play className="w-3 h-3" />
                        </Button>
                        {job.input_file_id && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => downloadFile(job.input_file_id)}
                          >
                            <Download className="w-3 h-3" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Result Detail Modal */}
      {selectedItem && selectedItem.latest_result && (
        <Dialog open={!!selectedItem} onOpenChange={() => setSelectedItem(null)}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Analysis Result: {selectedItem.title}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  {getVerdictIcon(selectedItem.latest_result.verdict)}
                  <span className="font-semibold">Verdict:</span>
                  {getVerdictBadge(selectedItem.latest_result.verdict)}
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Findings:</h4>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  {(selectedItem.latest_result.findings || []).map((finding, idx) => (
                    <li key={idx}>{finding}</li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Recommendations:</h4>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  {(selectedItem.latest_result.recommendations || []).map((rec, idx) => (
                    <li key={idx}>{rec}</li>
                  ))}
                </ul>
              </div>

              <details className="border rounded p-3">
                <summary className="font-semibold cursor-pointer">Technical Details (JSON)</summary>
                <pre className="text-xs mt-2 overflow-x-auto bg-muted p-2 rounded">
                  {JSON.stringify(selectedItem.latest_result.details_json, null, 2)}
                </pre>
              </details>
            </div>
            <DialogFooter>
              <Button onClick={() => setSelectedItem(null)}>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* History Modal */}
      {showHistory && historyItem && (
        <Dialog open={showHistory} onOpenChange={() => { setShowHistory(false); setHistoryItem(null); }}>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Analysis History: {historyItem.title}</DialogTitle>
            </DialogHeader>
            {historyLoading ? (
              <div className="flex justify-center py-6">
                <Loader2 className="w-6 h-6 animate-spin" />
              </div>
            ) : (
              <div className="space-y-3">
                {(historyData?.jobs ?? []).map((job) => (
                  <div key={job.id} className="border rounded p-3">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <Badge variant="outline">{job.status}</Badge>
                        <span className="text-xs text-muted-foreground ml-2">
                          {new Date(job.created_date).toLocaleString()}
                        </span>
                      </div>
                      {job.result && getVerdictBadge(job.result.verdict)}
                    </div>
                    {job.output_summary && (
                      <p className="text-sm mt-2">{job.output_summary}</p>
                    )}
                    {job.result && (
                      <details className="mt-2 text-xs">
                        <summary className="cursor-pointer font-medium">Details</summary>
                        <div className="mt-2 space-y-1">
                          <div><strong>Findings:</strong> {job.result.findings?.join(', ') || 'None'}</div>
                          <div><strong>Recommendations:</strong> {job.result.recommendations?.join(', ') || 'None'}</div>
                        </div>
                      </details>
                    )}
                  </div>
                ))}
              </div>
            )}
            <DialogFooter>
              <Button onClick={() => { setShowHistory(false); setHistoryItem(null); }}>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </AdminLayout>
  );
}