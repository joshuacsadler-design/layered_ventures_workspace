import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Package, Plus, Trash2 } from "lucide-react";
import AdminLayout from "@/components/admin/AdminLayout";
import PMBadge from "@/components/ui/PMBadge";

export default function AdminShipping() {
  const [user, setUser] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [parcels, setParcels] = useState([{ weight_oz: 16, length_in: 12, width_in: 9, height_in: 1 }]);
  const queryClient = useQueryClient();

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      const me = await base44.auth.me();
      if (me.role !== "admin") { window.location.href = "/"; return; }
      setUser(me);
    })();
  }, []);

  const { data: orders = [], isLoading } = useQuery({
    queryKey: ["shipping-orders"],
    queryFn: async () => {
      const allOrders = await base44.asServiceRole.entities.Order.list('-created_date');
      
      // Only show orders where all items are COMPLETED
      const eligibleOrders = [];
      for (const order of allOrders) {
        if (order.status === 'IN_PRODUCTION' || order.status === 'COMPLETED') {
          const items = await base44.asServiceRole.entities.OrderItem.filter({ order_id: order.id });
          const allCompleted = items.every(item => item.status === 'COMPLETED');
          if (allCompleted) {
            eligibleOrders.push(order);
          }
        }
      }
      
      return eligibleOrders;
    },
    enabled: !!user,
  });

  const { data: clients = [] } = useQuery({
    queryKey: ["shipping-clients"],
    queryFn: async () => {
      const clientIds = [...new Set(orders.map(o => o.client_id))];
      if (clientIds.length === 0) return [];
      const allClients = await base44.asServiceRole.entities.Client.list();
      return allClients.filter(c => clientIds.includes(c.id));
    },
    enabled: !!user && orders.length > 0,
  });

  const { data: shipments = [] } = useQuery({
    queryKey: ["shipments"],
    queryFn: () => base44.asServiceRole.entities.ShipmentParcel.list('-created_date'),
    enabled: !!user,
  });

  const purchaseLabelMutation = useMutation({
    mutationFn: async ({ orderId, parcels }) => {
      await base44.functions.invoke('purchaseLabel', { orderId, parcels });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["shipping-orders"]);
      queryClient.invalidateQueries(["shipments"]);
      setSelectedOrder(null);
      setParcels([{ weight_oz: 16, length_in: 12, width_in: 9, height_in: 1 }]);
      alert('Shipping label purchased successfully!');
    },
    onError: (error) => {
      alert('Error purchasing label: ' + error.message);
    },
  });

  const getClient = (clientId) => clients.find(c => c.id === clientId);
  const getOrderShipments = (orderId) => shipments.filter(s => s.order_id === orderId);

  const addParcel = () => {
    setParcels([...parcels, { weight_oz: 16, length_in: 12, width_in: 9, height_in: 1 }]);
  };

  const removeParcel = (index) => {
    setParcels(parcels.filter((_, i) => i !== index));
  };

  const updateParcel = (index, field, value) => {
    const updated = [...parcels];
    updated[index][field] = parseFloat(value) || 0;
    setParcels(updated);
  };

  const handlePurchaseLabel = () => {
    if (!selectedOrder) {
      alert('Please select an order.');
      return;
    }
    if (parcels.length === 0) {
      alert('Please add at least one parcel.');
      return;
    }
    
    const invalidParcel = parcels.find(p => 
      p.weight_oz <= 0 || p.length_in <= 0 || p.width_in <= 0 || p.height_in <= 0
    );
    if (invalidParcel) {
      alert('All parcel dimensions must be greater than 0.');
      return;
    }

    purchaseLabelMutation.mutate({ orderId: selectedOrder.id, parcels });
  };

  if (!user) return <div className="flex items-center justify-center min-h-screen"><Loader2 className="w-8 h-8 animate-spin" /></div>;

  const shippedOrders = orders.filter(o => getOrderShipments(o.id).length > 0);
  const readyToShip = orders.filter(o => getOrderShipments(o.id).length === 0);

  return (
    <AdminLayout title="Shipping Management">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Ready to Ship */}
        <Card>
          <CardHeader>
            <CardTitle>Ready to Ship ({readyToShip.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-6 h-6 animate-spin" />
              </div>
            ) : readyToShip.length === 0 ? (
              <p className="text-center py-12" style={{ color: "var(--pm-text-muted)" }}>
                No orders ready to ship.
              </p>
            ) : (
              <div className="space-y-3">
                {readyToShip.map((order) => {
                  const client = getClient(order.client_id);
                  const isSelected = selectedOrder?.id === order.id;

                  return (
                    <div
                      key={order.id}
                      className={`p-3 rounded border cursor-pointer transition-colors ${
                        isSelected ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' : ''
                      }`}
                      style={{ borderColor: isSelected ? undefined : "var(--pm-border)" }}
                      onClick={() => setSelectedOrder(order)}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-semibold">{order.order_number}</p>
                          <p className="text-sm" style={{ color: "var(--pm-text-muted)" }}>
                            {client?.full_name || 'Unknown Client'}
                          </p>
                          <p className="text-xs mt-1" style={{ color: "var(--pm-text-muted)" }}>
                            Total: ${order.total?.toFixed(2) || '0.00'}
                          </p>
                        </div>
                        <PMBadge variant="success">Ready</PMBadge>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Right: Purchase Label */}
        <Card>
          <CardHeader>
            <CardTitle>Purchase Shipping Label</CardTitle>
          </CardHeader>
          <CardContent>
            {!selectedOrder ? (
              <p className="text-center py-12" style={{ color: "var(--pm-text-muted)" }}>
                Select an order from the left to purchase a label.
              </p>
            ) : (
              <div className="space-y-4">
                <div className="p-3 rounded border" style={{ borderColor: "var(--pm-border)" }}>
                  <p className="font-semibold mb-2">Order {selectedOrder.order_number}</p>
                  <div className="text-sm space-y-1">
                    <p><strong>Ship To:</strong></p>
                    {selectedOrder.shipping_address ? (
                      <>
                        <p>{selectedOrder.shipping_address.line1}</p>
                        {selectedOrder.shipping_address.line2 && <p>{selectedOrder.shipping_address.line2}</p>}
                        <p>
                          {selectedOrder.shipping_address.city}, {selectedOrder.shipping_address.state} {selectedOrder.shipping_address.zip}
                        </p>
                      </>
                    ) : (
                      <p style={{ color: "var(--pm-text-muted)" }}>No shipping address provided</p>
                    )}
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-3">
                    <p className="font-medium">Parcels ({parcels.length})</p>
                    <Button size="sm" variant="outline" onClick={addParcel}>
                      <Plus className="w-3 h-3 mr-1" /> Add Parcel
                    </Button>
                  </div>

                  <div className="space-y-3">
                    {parcels.map((parcel, index) => (
                      <div key={index} className="p-3 rounded border" style={{ borderColor: "var(--pm-border)" }}>
                        <div className="flex items-center justify-between mb-2">
                          <p className="text-sm font-medium">Parcel {index + 1}</p>
                          {parcels.length > 1 && (
                            <Button size="sm" variant="ghost" onClick={() => removeParcel(index)}>
                              <Trash2 className="w-3 h-3 text-red-500" />
                            </Button>
                          )}
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>
                            <label className="block mb-1 text-xs">Weight (oz)</label>
                            <Input
                              type="number"
                              step="0.1"
                              value={parcel.weight_oz}
                              onChange={(e) => updateParcel(index, 'weight_oz', e.target.value)}
                            />
                          </div>
                          <div>
                            <label className="block mb-1 text-xs">Length (in)</label>
                            <Input
                              type="number"
                              step="0.1"
                              value={parcel.length_in}
                              onChange={(e) => updateParcel(index, 'length_in', e.target.value)}
                            />
                          </div>
                          <div>
                            <label className="block mb-1 text-xs">Width (in)</label>
                            <Input
                              type="number"
                              step="0.1"
                              value={parcel.width_in}
                              onChange={(e) => updateParcel(index, 'width_in', e.target.value)}
                            />
                          </div>
                          <div>
                            <label className="block mb-1 text-xs">Height (in)</label>
                            <Input
                              type="number"
                              step="0.1"
                              value={parcel.height_in}
                              onChange={(e) => updateParcel(index, 'height_in', e.target.value)}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <Button
                  className="w-full"
                  onClick={handlePurchaseLabel}
                  disabled={purchaseLabelMutation.isPending || !selectedOrder.shipping_address}
                >
                  {purchaseLabelMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Package className="w-4 h-4 mr-2" />
                  )}
                  Purchase Label ({parcels.length} {parcels.length === 1 ? 'Parcel' : 'Parcels'})
                </Button>

                {!selectedOrder.shipping_address && (
                  <p className="text-xs text-center text-red-500">
                    Cannot purchase label: Missing shipping address
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Bottom: Shipped Orders */}
        {shippedOrders.length > 0 && (
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Shipped Orders ({shippedOrders.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {shippedOrders.map((order) => {
                  const client = getClient(order.client_id);
                  const orderShipments = getOrderShipments(order.id);

                  return (
                    <div key={order.id} className="p-3 rounded border" style={{ borderColor: "var(--pm-border)" }}>
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <p className="font-semibold">{order.order_number}</p>
                          <p className="text-sm" style={{ color: "var(--pm-text-muted)" }}>
                            {client?.full_name || 'Unknown'}
                          </p>
                        </div>
                        <PMBadge variant="default">Shipped</PMBadge>
                      </div>

                      <div className="space-y-2">
                        {orderShipments.map((shipment) => (
                          <div key={shipment.id} className="p-2 rounded bg-neutral-50 dark:bg-neutral-900 text-sm">
                            <p><strong>Tracking:</strong> {shipment.tracking_number}</p>
                            <p><strong>Carrier:</strong> {shipment.carrier}</p>
                            {shipment.tracking_url && (
                              <a 
                                href={shipment.tracking_url} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-blue-600 hover:underline"
                              >
                                Track Shipment →
                              </a>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </AdminLayout>
  );
}