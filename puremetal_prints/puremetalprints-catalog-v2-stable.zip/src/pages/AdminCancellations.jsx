import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, CheckCircle, XCircle } from "lucide-react";
import AdminLayout from "@/components/admin/AdminLayout";
import PMBadge from "@/components/ui/PMBadge";

export default function AdminCancellations() {
  const [user, setUser] = useState(null);
  const [adminResponses, setAdminResponses] = useState({});
  const queryClient = useQueryClient();

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      const me = await base44.auth.me();
      if (me.role !== "admin") { window.location.href = "/"; return; }
      setUser(me);
    })();
  }, []);

  const { data: requests = [], isLoading } = useQuery({
    queryKey: ["cancellation-requests"],
    queryFn: () => base44.asServiceRole.entities.CancellationRequest.list('-created_date'),
    enabled: !!user,
  });

  const { data: orders = [] } = useQuery({
    queryKey: ["cancellation-orders"],
    queryFn: async () => {
      const orderIds = [...new Set(requests.map(r => r.order_id))];
      if (orderIds.length === 0) return [];
      const allOrders = await base44.asServiceRole.entities.Order.list();
      return allOrders.filter(o => orderIds.includes(o.id));
    },
    enabled: !!user && requests.length > 0,
  });

  const { data: clients = [] } = useQuery({
    queryKey: ["cancellation-clients"],
    queryFn: async () => {
      const clientIds = [...new Set(orders.map(o => o.client_id))];
      if (clientIds.length === 0) return [];
      const allClients = await base44.asServiceRole.entities.Client.list();
      return allClients.filter(c => clientIds.includes(c.id));
    },
    enabled: !!user && orders.length > 0,
  });

  const respondMutation = useMutation({
    mutationFn: async ({ requestId, approved, adminResponse }) => {
      await base44.functions.invoke('respondToCancellation', {
        requestId,
        approved,
        adminResponse,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["cancellation-requests"]);
      queryClient.invalidateQueries(["cancellation-orders"]);
      setAdminResponses({});
    },
  });

  const getOrder = (orderId) => orders.find(o => o.id === orderId);
  const getClient = (clientId) => clients.find(c => c.id === clientId);

  const handleRespond = (request, approved) => {
    const adminResponse = adminResponses[request.id] || '';
    if (!approved && !adminResponse.trim()) {
      alert('Please provide a reason for denial.');
      return;
    }
    respondMutation.mutate({ 
      requestId: request.id, 
      approved, 
      adminResponse: adminResponse.trim() || null 
    });
  };

  const pendingRequests = requests.filter(r => r.status === 'PENDING');
  const resolvedRequests = requests.filter(r => r.status !== 'PENDING');

  if (!user) return <div className="flex items-center justify-center min-h-screen"><Loader2 className="w-8 h-8 animate-spin" /></div>;

  return (
    <AdminLayout title="Cancellation Requests">
      <div className="space-y-6">
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin" />
          </div>
        ) : (
          <>
            {/* Pending Requests */}
            <Card>
              <CardHeader>
                <CardTitle>Pending Requests ({pendingRequests.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {pendingRequests.length === 0 ? (
                  <p className="text-center py-8" style={{ color: "var(--pm-text-muted)" }}>
                    No pending cancellation requests.
                  </p>
                ) : (
                  <div className="space-y-4">
                    {pendingRequests.map((request) => {
                      const order = getOrder(request.order_id);
                      const client = order ? getClient(order.client_id) : null;
                      const prepFeeApplies = request.prep_fee_applies ?? true;
                      const refundAmount = order ? (prepFeeApplies ? order.total - 15 : order.total) : 0;

                      return (
                        <div 
                          key={request.id} 
                          className="p-4 rounded border" 
                          style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}
                        >
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <p className="font-semibold">Order {order?.order_number || request.order_id}</p>
                              <p className="text-sm" style={{ color: "var(--pm-text-muted)" }}>
                                Client: {client?.full_name || 'Unknown'}
                              </p>
                              <p className="text-xs mt-1" style={{ color: "var(--pm-text-muted)" }}>
                                Requested: {new Date(request.created_date).toLocaleString()}
                              </p>
                            </div>
                            <PMBadge variant="warning">Pending</PMBadge>
                          </div>

                          <div className="mb-3">
                            <p className="text-sm font-medium mb-1">Reason:</p>
                            <p className="text-sm p-2 rounded bg-neutral-50 dark:bg-neutral-900">
                              {request.reason}
                            </p>
                          </div>

                          <div className="grid grid-cols-2 gap-3 mb-3 text-sm">
                            <div>
                              <p className="font-medium">Order Total:</p>
                              <p>${order?.total?.toFixed(2) || '0.00'}</p>
                            </div>
                            <div>
                              <p className="font-medium">Prep Fee:</p>
                              <p>{prepFeeApplies ? '$15.00' : 'N/A'}</p>
                            </div>
                            <div>
                              <p className="font-medium">Refund Amount:</p>
                              <p className="text-lg font-semibold">${refundAmount.toFixed(2)}</p>
                            </div>
                            <div>
                              <p className="font-medium">Order Status:</p>
                              <p>{order?.status || 'Unknown'}</p>
                            </div>
                          </div>

                          <div className="mb-3">
                            <label className="text-sm font-medium mb-2 block">Admin Response (optional for approval, required for denial):</label>
                            <Textarea
                              value={adminResponses[request.id] || ''}
                              onChange={(e) => setAdminResponses({ ...adminResponses, [request.id]: e.target.value })}
                              placeholder="Add notes or reason for denial..."
                              rows={2}
                            />
                          </div>

                          <div className="flex gap-2">
                            <Button
                              variant="default"
                              onClick={() => handleRespond(request, true)}
                              disabled={respondMutation.isPending}
                            >
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Approve ({prepFeeApplies ? `Refund $${refundAmount.toFixed(2)}` : 'Full Refund'})
                            </Button>
                            <Button
                              variant="destructive"
                              onClick={() => handleRespond(request, false)}
                              disabled={respondMutation.isPending}
                            >
                              <XCircle className="w-4 h-4 mr-2" />
                              Deny
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Resolved Requests */}
            {resolvedRequests.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Resolved Requests ({resolvedRequests.length})</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {resolvedRequests.map((request) => {
                      const order = getOrder(request.order_id);
                      const client = order ? getClient(order.client_id) : null;

                      return (
                        <div 
                          key={request.id} 
                          className="p-3 rounded border" 
                          style={{ borderColor: "var(--pm-border)" }}
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <p className="font-medium">Order {order?.order_number || request.order_id}</p>
                              <p className="text-sm" style={{ color: "var(--pm-text-muted)" }}>
                                {client?.full_name || 'Unknown'} · {new Date(request.created_date).toLocaleDateString()}
                              </p>
                              {request.admin_response && (
                                <p className="text-sm mt-2 p-2 rounded bg-neutral-50 dark:bg-neutral-900">
                                  Response: {request.admin_response}
                                </p>
                              )}
                            </div>
                            <PMBadge variant={request.status === 'APPROVED' ? 'success' : 'error'}>
                              {request.status}
                            </PMBadge>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}
          </>
        )}
      </div>
    </AdminLayout>
  );
}