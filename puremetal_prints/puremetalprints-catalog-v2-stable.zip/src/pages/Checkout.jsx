import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { CreditCard, Loader2, ShieldCheck, AlertCircle, Tag } from "lucide-react";

export default function Checkout() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [licensingAccepted, setLicensingAccepted] = useState(false);
  const [galleryOptIn, setGalleryOptIn] = useState(false);
  const [address, setAddress] = useState({ line1: "", line2: "", city: "", state: "", zip: "", country: "US" });
  const [promoCode, setPromoCode] = useState("");
  const [promoApplied, setPromoApplied] = useState(null);

  const queryClient = useQueryClient();

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      setUser(await base44.auth.me());
    })();
  }, []);

  const { data: draftOrders = [] } = useQuery({
    queryKey: ["checkout-orders", user?.id],
    queryFn: () => base44.entities.Order.filter({ user_id: user.id, status: 'DRAFT' }),
    enabled: !!user,
  });

  const { data: items = [] } = useQuery({
    queryKey: ["checkout-items", draftOrders[0]?.id],
    queryFn: () => base44.entities.OrderItem.filter({ order_id: draftOrders[0].id }),
    enabled: draftOrders.length > 0,
  });

  const { data: mounts = [] } = useQuery({
    queryKey: ["checkout-mounts"],
    queryFn: () => base44.entities.MountOffering.list(),
    enabled: !!user,
  });

  const applyPromoMutation = useMutation({
    mutationFn: async (code) => {
      const response = await base44.functions.invoke("applyCouponToDraftOrder", { code });
      return response.data;
    },
    onSuccess: (data) => {
      setPromoApplied(data);
      queryClient.invalidateQueries(["checkout-orders"]);
      alert(`Promo applied: ${data.coupon_name}`);
    },
    onError: (error) => {
      alert(`Promo error: ${error.message}`);
    },
  });

  const subtotal = items.reduce((s, i) => s + i.unit_price * i.quantity, 0);
  const discount = promoApplied?.discount || 0;
  const total = Math.max(0, subtotal - discount);

  const handleApplyPromo = () => {
    if (!promoCode.trim()) return;
    applyPromoMutation.mutate(promoCode);
  };

  const handleCheckout = async () => {
    if (!licensingAccepted) return;
    setLoading(true);

    const order = draftOrders[0];
    if (!order) {
      alert('No items in cart');
      setLoading(false);
      return;
    }

    await base44.asServiceRole.entities.Order.update(order.id, {
      shipping_address: address,
      notes: galleryOptIn ? 'Gallery opt-in: Yes' : '',
    });

    const resp = await base44.functions.invoke("createCheckoutSession", { orderId: order.id });
    if (resp.data?.url) {
      window.location.href = resp.data.url;
    } else {
      alert('Failed to create checkout session');
      setLoading(false);
    }
  };

  const getMountLabel = (mountKey) => {
    const mount = mounts.find(m => m.key === mountKey);
    return mount?.label || mountKey;
  };

  const addressField = (key, label, span = false) => (
    <div className={span ? "sm:col-span-2" : ""}>
      <Label className="text-sm mb-1 block">{label}</Label>
      <Input value={address[key]} onChange={(e) => setAddress({ ...address, [key]: e.target.value })} />
    </div>
  );

  if (!user) return <div className="flex items-center justify-center min-h-screen"><Loader2 className="w-8 h-8 animate-spin" /></div>;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold tracking-tight mb-8">Checkout</h1>

      <div className="space-y-8">
        <div className="rounded-2xl border p-6" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}>
          <h2 className="text-lg font-semibold mb-4">Shipping Address</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            {addressField("line1", "Address Line 1", true)}
            {addressField("line2", "Address Line 2 (optional)", true)}
            {addressField("city", "City")}
            {addressField("state", "State")}
            {addressField("zip", "ZIP Code")}
            {addressField("country", "Country")}
          </div>
        </div>

        <div className="rounded-2xl border p-6" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}>
          <h2 className="text-lg font-semibold mb-4">Promo Code</h2>
          <div className="flex gap-2">
            <Input
              placeholder="Enter promo code"
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
              className="flex-1"
            />
            <Button onClick={handleApplyPromo} disabled={applyPromoMutation.isPending} variant="outline">
              {applyPromoMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Tag className="w-4 h-4 mr-2" />}
              Apply
            </Button>
          </div>
          {promoApplied && (
            <p className="mt-2 text-sm text-green-600">
              ✓ {promoApplied.coupon_name} applied: -${promoApplied.discount.toFixed(2)}
            </p>
          )}
        </div>

        <div className="rounded-2xl border p-6" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}>
          <h2 className="text-lg font-semibold mb-4">Agreements</h2>
          <div className="space-y-4">
            <label className="flex items-start gap-3 cursor-pointer">
              <Checkbox checked={licensingAccepted} onCheckedChange={setLicensingAccepted} className="mt-0.5" />
              <div>
                <p className="text-sm font-medium">Licensing Agreement *</p>
                <p className="text-xs mt-0.5" style={{ color: "var(--pm-text-muted)" }}>
                  I confirm I have the rights to print the uploaded images and accept the terms of service.
                </p>
              </div>
            </label>
            <label className="flex items-start gap-3 cursor-pointer">
              <Checkbox checked={galleryOptIn} onCheckedChange={setGalleryOptIn} className="mt-0.5" />
              <div>
                <p className="text-sm font-medium">Gallery Opt-In</p>
                <p className="text-xs mt-0.5" style={{ color: "var(--pm-text-muted)" }}>
                  I'd love for my print(s) to be featured in the PureMetal gallery.
                </p>
              </div>
            </label>
          </div>
        </div>

        <div className="rounded-2xl border p-6" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}>
          <h2 className="text-lg font-semibold mb-4">Order Summary</h2>
          <div className="space-y-2 text-sm mb-4">
            {items.map(item => (
              <div key={item.id} className="flex justify-between">
                <span>
                  {item.title} ({item.size}") 
                  {item.mount_type && ` • ${getMountLabel(item.mount_type)}`}
                  {' × '}{item.quantity}
                </span>
                <span className="font-medium">${(item.unit_price * item.quantity).toFixed(2)}</span>
              </div>
            ))}
          </div>
          <div className="border-t pt-3 space-y-1" style={{ borderColor: "var(--pm-border)" }}>
            <div className="flex justify-between text-sm">
              <span>Subtotal</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between text-sm text-green-600">
                <span>Discount</span>
                <span>-${discount.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between text-lg font-bold pt-2">
              <span>Total</span>
              <span>${total.toFixed(2)}</span>
            </div>
          </div>
          <p className="text-xs mt-2" style={{ color: "var(--pm-text-muted)" }}>Shipping and tax calculated by Stripe.</p>
        </div>

        {!licensingAccepted && (
          <div className="flex items-center gap-2 text-amber-600 text-sm">
            <AlertCircle className="w-4 h-4" />
            Please accept the licensing agreement to continue.
          </div>
        )}

        <Button
          className="w-full h-14 text-base gap-2 bg-neutral-900 text-white hover:bg-neutral-800"
          disabled={!licensingAccepted || loading || items.length === 0}
          onClick={handleCheckout}
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <CreditCard className="w-5 h-5" />}
          Pay with Stripe
          <ShieldCheck className="w-4 h-4 ml-1 opacity-50" />
        </Button>
      </div>
    </div>
  );
}