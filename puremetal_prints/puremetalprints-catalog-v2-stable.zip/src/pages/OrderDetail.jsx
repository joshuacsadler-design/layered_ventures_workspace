import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { CheckCircle, XCircle, Loader2, Image as ImageIcon, AlertCircle, ArrowLeft, ArrowRight } from "lucide-react";
import PMBadge from "@/components/ui/PMBadge";
import { getClientStatusLabel } from "@/components/utils/statusDisplay";

const STATUS_VARIANTS = {
  DRAFT: "default",
  UPLOADED: "purple",
  NEEDS_REVIEW: "warning",
  PROOF_DELIVERED: "purple",
  PROOF_SELECTED: "success",
  APPROVED: "gold",
  IN_PRODUCTION: "purple",
  COMPLETED: "success",
  CANCELLATION_REQUESTED: "error",
  CANCELLED: "error",
};

export default function OrderDetail() {
  const queryClient = useQueryClient();
  const params = new URLSearchParams(window.location.search);
  const orderId = params.get("id");
  const [user, setUser] = useState(null);
  const [cancellationReason, setCancellationReason] = useState("");
  const [showCancellation, setShowCancellation] = useState(false);
  const [changeMessage, setChangeMessage] = useState("");
  const [showChangeRequest, setShowChangeRequest] = useState(false);
  const [selectedProofs, setSelectedProofs] = useState({});

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      setUser(await base44.auth.me());
    })();
  }, []);

  const { data: order } = useQuery({
    queryKey: ["order", orderId],
    queryFn: async () => {
      const orders = await base44.entities.Order.filter({ id: orderId, user_id: user.id });
      return orders[0];
    },
    enabled: !!user && !!orderId,
  });

  const { data: items = [] } = useQuery({
    queryKey: ["order-items", orderId],
    queryFn: () => base44.entities.OrderItem.filter({ order_id: orderId }),
    enabled: !!orderId,
  });

  const { data: proofs = [] } = useQuery({
    queryKey: ["order-proofs", orderId],
    queryFn: async () => {
      const { data } = await base44.functions.invoke('listProofsForOrder', { order_id: orderId });
      return data.proofs;
    },
    enabled: !!orderId && !!user,
  });

  const { data: files = [] } = useQuery({
    queryKey: ["order-files", orderId],
    queryFn: async () => {
      const { data } = await base44.functions.invoke('listClientFilesForOrder', { orderId });
      return data.files;
    },
    enabled: !!orderId && !!user,
  });

  const { data: parcels = [] } = useQuery({
    queryKey: ["order-parcels", orderId],
    queryFn: () => base44.entities.ShipmentParcel.filter({ order_id: orderId }),
    enabled: !!orderId,
  });

  useEffect(() => {
    const selected = {};
    proofs.filter(p => p.is_selected).forEach(p => {
      selected[p.order_item_id] = p.id;
    });
    setSelectedProofs(selected);
  }, [proofs]);

  const handleSelectProof = async (itemId, proofId) => {
    setSelectedProofs({ ...selectedProofs, [itemId]: proofId });
    await base44.functions.invoke('selectProof', { orderId, proofId });
    queryClient.invalidateQueries({ queryKey: ["order"] });
    queryClient.invalidateQueries({ queryKey: ["order-proofs"] });
    queryClient.invalidateQueries({ queryKey: ["order-items"] });
  };

  const handleApprove = async () => {
    await base44.functions.invoke('approveOrder', { orderId });
    queryClient.invalidateQueries({ queryKey: ["order"] });
    queryClient.invalidateQueries({ queryKey: ["order-items"] });
  };

  const handleRequestChanges = async () => {
    if (!changeMessage.trim()) return;
    await base44.functions.invoke('requestChanges', { orderId, message: changeMessage });
    setChangeMessage("");
    setShowChangeRequest(false);
    queryClient.invalidateQueries({ queryKey: ["order"] });
  };

  const handleRequestCancellation = async () => {
    if (!cancellationReason.trim()) return;
    const { data } = await base44.functions.invoke('requestCancellation', { orderId, reason: cancellationReason });
    alert(data.message || 'Cancellation request submitted');
    setCancellationReason("");
    setShowCancellation(false);
    queryClient.invalidateQueries({ queryKey: ["order"] });
  };

  if (!order) return <div className="flex items-center justify-center min-h-[60vh]"><Loader2 className="w-8 h-8 animate-spin" /></div>;

  const deliveredProofs = proofs.filter(p => p.is_delivered);
  const canSelectProof = order.status === 'PROOF_DELIVERED' || order.status === 'PROOF_SELECTED';
  const allItemsHaveSelection = items.every(item => {
    const itemProofs = deliveredProofs.filter(p => p.order_item_id === item.id);
    return itemProofs.length > 0 && selectedProofs[item.id];
  });
  const canApprove = canSelectProof && allItemsHaveSelection;
  const canRequestChanges = !['IN_PRODUCTION', 'COMPLETED', 'CANCELLED'].includes(order.status);
  const canRequestCancellation = !['IN_PRODUCTION', 'COMPLETED', 'CANCELLED', 'CANCELLATION_REQUESTED'].includes(order.status);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold">{order.order_number}</h1>
          <p className="text-sm mt-1" style={{ color: "var(--pm-text-muted)" }}>Placed {new Date(order.created_date).toLocaleDateString()}</p>
        </div>
        <PMBadge variant={STATUS_VARIANTS[order.status] || "default"}>{getClientStatusLabel(order.status)}</PMBadge>
      </div>

      {/* Items with Proof Comparison */}
      <div className="space-y-8 mb-8">
        <h2 className="text-lg font-semibold">Order Items</h2>
        {items.map((item) => {
          const itemProofs = deliveredProofs.filter(p => p.order_item_id === item.id);
          const originalFile = files.find(f => f.order_item_id === item.id && f.kind === 'CLIENT_ORIGINAL');
          const selectedProofId = selectedProofs[item.id];
          const selectedProof = itemProofs.find(p => p.id === selectedProofId);

          return (
            <div key={item.id} className="rounded-xl border p-6" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="font-semibold text-lg">{item.title}</h3>
                  <p className="text-sm mt-1" style={{ color: "var(--pm-text-muted)" }}>
                    {item.size}" · {item.material === "puremetalreserve" ? "PureMetal Reserve" : "Standard"} · Qty: {item.quantity}
                  </p>
                  <PMBadge variant={STATUS_VARIANTS[item.status]} className="mt-2">
                    {getClientStatusLabel(item.status)}
                  </PMBadge>
                </div>
              </div>

              {/* Proof Comparison View */}
              {itemProofs.length > 0 && (
                <div className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    {/* Original Reference */}
                    <div className="space-y-2">
                      <p className="text-xs font-semibold uppercase tracking-wide" style={{ color: "var(--pm-text-muted)" }}>Your Original</p>
                      <div className="aspect-square rounded-lg border bg-neutral-100 dark:bg-neutral-800 overflow-hidden" style={{ borderColor: "var(--pm-border)" }}>
                        {originalFile ? (
                          <img src={originalFile.file_url} alt="Original" className="w-full h-full object-contain" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <ImageIcon className="w-12 h-12 opacity-20" />
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Selected or First Proof */}
                    <div className="space-y-2">
                      <p className="text-xs font-semibold uppercase tracking-wide" style={{ color: "var(--pm-text-muted)" }}>
                        {selectedProof ? 'Your Selected Proof' : 'Studio Proof Preview'}
                      </p>
                      <div className="aspect-square rounded-lg border bg-neutral-100 dark:bg-neutral-800 overflow-hidden" style={{ borderColor: selectedProof ? "var(--pm-gold)" : "var(--pm-border)" }}>
                        {(selectedProof || itemProofs[0]) ? (
                          <img 
                            src={files.find(f => f.id === (selectedProof?.file_id || itemProofs[0]?.file_id))?.file_url} 
                            alt="Proof" 
                            className="w-full h-full object-contain" 
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <ImageIcon className="w-12 h-12 opacity-20" />
                          </div>
                        )}
                      </div>
                      {selectedProof?.admin_notes && (
                        <p className="text-xs p-2 rounded bg-neutral-100 dark:bg-neutral-800">
                          Note: {selectedProof.admin_notes}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Proof Selection Grid */}
                  {itemProofs.length > 1 && canSelectProof && (
                    <div>
                      <p className="text-sm font-medium mb-3">Choose Your Preferred Proof:</p>
                      <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                        {itemProofs.map((proof, idx) => {
                          const proofFile = files.find(f => f.id === proof.file_id);
                          const isSelected = selectedProofId === proof.id;
                          return (
                            <button
                              key={proof.id}
                              onClick={() => handleSelectProof(item.id, proof.id)}
                              className={`rounded-lg border-2 p-2 transition-all ${
                                isSelected 
                                  ? "border-emerald-500 ring-2 ring-emerald-200 dark:ring-emerald-800" 
                                  : "border-transparent hover:border-neutral-300"
                              }`}
                              style={{ backgroundColor: "var(--pm-surface)" }}
                            >
                              <div className="aspect-square bg-neutral-100 dark:bg-neutral-800 rounded overflow-hidden mb-2">
                                {proofFile && <img src={proofFile.file_url} alt={`Proof ${idx + 1}`} className="w-full h-full object-cover" />}
                              </div>
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-medium">Proof {idx + 1}</span>
                                {isSelected && <CheckCircle className="w-4 h-4 text-emerald-600" />}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {itemProofs.length === 0 && (
                <div className="text-center py-8 rounded-lg bg-neutral-50 dark:bg-neutral-900">
                  <p className="text-sm" style={{ color: "var(--pm-text-muted)" }}>
                    Proofs are being prepared by our studio. You'll be notified when they're ready for review.
                  </p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Shipping Info */}
      {parcels.length > 0 && (
        <div className="rounded-xl border p-6 mb-8" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}>
          <h2 className="text-lg font-semibold mb-4">Shipping</h2>
          <div className="space-y-4">
            {parcels.map((parcel, idx) => (
              <div key={parcel.id} className="flex items-start gap-4 p-4 rounded-lg bg-neutral-50 dark:bg-neutral-800">
                <div className="flex-1">
                  <p className="text-sm font-medium mb-1">
                    {parcels.length > 1 && `Package ${idx + 1} · `}{parcel.carrier}
                  </p>
                  <p className="text-sm mb-2" style={{ color: "var(--pm-text-muted)" }}>
                    Tracking: {parcel.tracking_number}
                  </p>
                  {parcel.ship_date && (
                    <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>
                      Shipped: {new Date(parcel.ship_date).toLocaleDateString()}
                    </p>
                  )}
                  {parcel.tracking_url && (
                    <a 
                      href={parcel.tracking_url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-sm font-medium mt-2 inline-block hover:underline"
                      style={{ color: "var(--pm-accent)" }}
                    >
                      Track Package →
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Approve Action */}
      {canSelectProof && (
        <div className="rounded-xl border p-5 mb-8 bg-emerald-50 dark:bg-emerald-900/20" style={{ borderColor: "var(--pm-border)" }}>
          <p className="font-medium mb-3">Ready to approve?</p>
          <p className="text-sm mb-4" style={{ color: "var(--pm-text-muted)" }}>
            {allItemsHaveSelection 
              ? "Once you approve, the studio will begin production. You can no longer make changes after approval."
              : "Please select your preferred proof for each item before approving."}
          </p>
          <Button 
            onClick={handleApprove} 
            disabled={!canApprove}
            className="gap-2 bg-emerald-600 hover:bg-emerald-700 text-white"
          >
            <CheckCircle className="w-4 h-4" /> Approve for Production
          </Button>
        </div>
      )}

      {/* Request Changes */}
      {canRequestChanges && !showChangeRequest && (
        <Button variant="outline" onClick={() => setShowChangeRequest(true)} className="mb-4">
          Request Changes
        </Button>
      )}

      {showChangeRequest && (
        <div className="rounded-xl border p-5 mb-8" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}>
          <h3 className="font-medium mb-3">Request Changes</h3>
          <Textarea value={changeMessage} onChange={(e) => setChangeMessage(e.target.value)} placeholder="Describe the changes you'd like..." className="mb-3" />
          <div className="flex gap-2">
            <Button onClick={handleRequestChanges} size="sm">Send Request</Button>
            <Button onClick={() => setShowChangeRequest(false)} size="sm" variant="outline">Cancel</Button>
          </div>
        </div>
      )}

      {/* Request Cancellation */}
      {canRequestCancellation && !showCancellation && (
        <Button variant="outline" onClick={() => setShowCancellation(true)} className="text-red-600 hover:text-red-700">
          Request Cancellation
        </Button>
      )}

      {showCancellation && (
        <div className="rounded-xl border p-5 mb-8 bg-red-50 dark:bg-red-900/20" style={{ borderColor: "var(--pm-border)" }}>
          <div className="flex items-start gap-2 mb-3">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-medium text-red-900 dark:text-red-100">Request Cancellation</h3>
              <p className="text-sm mt-1" style={{ color: "var(--pm-text-muted)" }}>
                A $15 prep fee may apply if work has already begun.
              </p>
            </div>
          </div>
          <Textarea value={cancellationReason} onChange={(e) => setCancellationReason(e.target.value)} placeholder="Reason for cancellation..." className="mb-3" />
          <div className="flex gap-2">
            <Button onClick={handleRequestCancellation} size="sm" variant="destructive">Submit Cancellation Request</Button>
            <Button onClick={() => setShowCancellation(false)} size="sm" variant="outline">Cancel</Button>
          </div>
        </div>
      )}
    </div>
  );
}