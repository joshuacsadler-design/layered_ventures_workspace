import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, ExternalLink } from "lucide-react";
import AdminLayout from "@/components/admin/AdminLayout";
import PMBadge from "@/components/ui/PMBadge";

export default function AdminLegacyAttachments() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      const me = await base44.auth.me();
      if (me.role !== "admin") { window.location.href = "/"; return; }
      setUser(me);
    })();
  }, []);

  const { data: legacyData, isLoading } = useQuery({
    queryKey: ["legacy-attachments"],
    queryFn: async () => {
      const { data } = await base44.functions.invoke('listLegacyAttachments', {});
      return data;
    },
    enabled: !!user,
  });

  if (!user) return null;

  return (
    <AdminLayout title="Legacy Attachment Security">
      <div className="space-y-6">
        <Card className="border-red-200 bg-red-50 dark:border-red-900 dark:bg-red-950">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-700 dark:text-red-400">
              <AlertTriangle className="w-5 h-5" />
              Security Warning: Public Attachment URLs
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-red-600 dark:text-red-300 space-y-2">
            <p>
              <strong>Issue:</strong> Messages with legacy <code>attachment_url</code> fields contain PUBLIC, 
              NON-EXPIRING file URLs accessible by anyone with the link.
            </p>
            <p>
              <strong>Status:</strong> The UI now blocks display of these URLs, but the files remain publicly accessible 
              if someone has the URL.
            </p>
            <p>
              <strong>Action Required:</strong> These attachments should be migrated to private storage or users should 
              be asked to re-upload.
            </p>
          </CardContent>
        </Card>

        {isLoading && (
          <p className="text-center py-8" style={{ color: "var(--pm-text-muted)" }}>Loading...</p>
        )}

        {legacyData && (
          <Card>
            <CardHeader>
              <CardTitle>
                Legacy Attachments Found: {legacyData.count}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {legacyData.count === 0 ? (
                <div className="text-center py-8">
                  <p className="text-green-600 font-semibold">✓ No legacy attachments found</p>
                  <p className="text-sm mt-2" style={{ color: "var(--pm-text-muted)" }}>
                    All message attachments are using secure private storage.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {legacyData.messages.map((msg) => (
                    <div
                      key={msg.id}
                      className="p-4 rounded-lg border"
                      style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <PMBadge variant={msg.thread_type === 'order' ? 'purple' : 'default'}>
                              {msg.thread_type}
                            </PMBadge>
                            <PMBadge variant={msg.from_role === 'admin' ? 'warning' : 'default'}>
                              {msg.from_role}
                            </PMBadge>
                          </div>
                          <p className="text-sm font-mono text-xs mb-1" style={{ color: "var(--pm-text-muted)" }}>
                            User: {msg.user_id} | Msg ID: {msg.id}
                          </p>
                          <p className="text-sm mb-2">{msg.body_preview}</p>
                          <div className="flex items-center gap-2">
                            <span className="text-xs" style={{ color: "var(--pm-text-muted)" }}>
                              Attachment: {msg.attachment_name || 'Unknown'}
                            </span>
                            {msg.attachment_url && (
                              <a
                                href={msg.attachment_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-xs text-red-600 hover:text-red-700 flex items-center gap-1"
                              >
                                <ExternalLink className="w-3 h-3" />
                                View Public URL
                              </a>
                            )}
                          </div>
                          <p className="text-xs mt-1" style={{ color: "var(--pm-text-muted)" }}>
                            Created: {new Date(msg.created_date).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                  <div className="mt-6 p-4 rounded-lg bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-900">
                    <p className="text-sm text-amber-800 dark:text-amber-300">
                      <strong>Recommended Action:</strong> Contact affected users and request they re-upload attachments 
                      through the new secure messaging system. The old public URLs cannot be revoked but are no longer 
                      accessible through the UI.
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </AdminLayout>
  );
}