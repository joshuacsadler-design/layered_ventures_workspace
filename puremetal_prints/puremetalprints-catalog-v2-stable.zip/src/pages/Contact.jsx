import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Send, Paperclip, Loader2, MessageSquare, Download } from "lucide-react";

export default function Contact() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [isAuth, setIsAuth] = useState(false);
  const [body, setBody] = useState("");
  const [file, setFile] = useState(null);
  const [sending, setSending] = useState(false);
  const [downloadingAttachment, setDownloadingAttachment] = useState(null);

  const handleDownloadAttachment = async (messageId, filename) => {
    setDownloadingAttachment(messageId);
    try {
      const { data } = await base44.functions.invoke('getMessageAttachment', { attachmentId: messageId });
      const link = document.createElement('a');
      link.href = data.signed_url;
      link.download = filename || 'attachment';
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      alert('Failed to download attachment: ' + error.message);
    } finally {
      setDownloadingAttachment(null);
    }
  };

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      setIsAuth(auth);
      if (auth) setUser(await base44.auth.me());
    })();
  }, []);

  const { data: messages = [] } = useQuery({
    queryKey: ["contact-messages", user?.id],
    queryFn: () => base44.entities.PMMessages.filter({ user_id: user.id, thread_type: "contact" }, "created_date"),
    enabled: !!user,
  });

  const sendMessage = async () => {
    if (!body.trim() && !file) return;
    setSending(true);

    let attachment_file_id = null;
    let attachment_filename = null;
    let attachment_mime_type = null;
    let attachment_byte_size = null;

    if (file) {
      const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
      attachment_file_id = file_uri;
      attachment_filename = file.name;
      attachment_mime_type = file.type;
      attachment_byte_size = file.size;
    }

    await base44.entities.PMMessages.create({
      thread_type: "contact",
      user_id: user.id,
      from_role: "client",
      body: body.trim(),
      attachment_file_id,
      attachment_filename,
      attachment_mime_type,
      attachment_byte_size,
      read_by_client: true,
      read_by_admin: false,
    });

    setBody("");
    setFile(null);
    setSending(false);
    queryClient.invalidateQueries({ queryKey: ["contact-messages"] });
  };

  if (!isAuth) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-30" />
        <h1 className="text-2xl font-bold mb-3">Contact Us</h1>
        <p className="mb-6" style={{ color: "var(--pm-text-muted)" }}>Sign in to send us a message.</p>
        <Button onClick={() => base44.auth.redirectToLogin()} className="bg-neutral-900 text-white hover:bg-neutral-800">Sign In</Button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold tracking-tight mb-2">Contact Us</h1>
      <p className="mb-8" style={{ color: "var(--pm-text-muted)" }}>Have a question? We're here to help.</p>

      <div className="rounded-2xl border overflow-hidden" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}>
        {/* Messages */}
        <div className="max-h-96 overflow-y-auto p-5 space-y-4">
          {messages.length === 0 && (
            <p className="text-center text-sm py-8" style={{ color: "var(--pm-text-muted)" }}>No messages yet. Start the conversation!</p>
          )}
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.from_role === "client" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 ${
                msg.from_role === "client"
                  ? "bg-neutral-900 text-white dark:bg-white dark:text-black"
                  : "bg-neutral-100 dark:bg-neutral-800"
              }`}>
                <p className="text-sm">{msg.body}</p>
                {msg.attachment_file_id && (
                  <button
                    onClick={() => handleDownloadAttachment(msg.id, msg.attachment_filename)}
                    disabled={downloadingAttachment === msg.id}
                    className="text-xs mt-2 flex items-center gap-1 opacity-75 hover:opacity-100 transition-opacity"
                  >
                    {downloadingAttachment === msg.id ? (
                      <Loader2 className="w-3 h-3 animate-spin" />
                    ) : (
                      <Download className="w-3 h-3" />
                    )}
                    {msg.attachment_filename || "Download Attachment"}
                  </button>
                )}
                {!msg.attachment_file_id && (msg.attachment_url || msg.attachment_name) && (
                  <p className="text-xs mt-2 text-amber-600 dark:text-amber-400">
                    ⚠️ Legacy attachment unavailable — please re-upload if needed
                  </p>
                )}
                <p className={`text-[10px] mt-1 ${msg.from_role === "client" ? "opacity-50" : "opacity-40"}`}>
                  {new Date(msg.created_date).toLocaleString()}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Input */}
        <div className="border-t p-4 flex gap-2" style={{ borderColor: "var(--pm-border)" }}>
          <label className="cursor-pointer p-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800">
            <Paperclip className="w-5 h-5" style={{ color: "var(--pm-text-muted)" }} />
            <input type="file" className="hidden" onChange={(e) => setFile(e.target.files?.[0] || null)} />
          </label>
          <Textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder="Type your message..."
            className="resize-none min-h-[44px] max-h-32"
            rows={1}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
          />
          <Button size="icon" onClick={sendMessage} disabled={sending || (!body.trim() && !file)} className="bg-neutral-900 text-white hover:bg-neutral-800 h-11 w-11 flex-shrink-0">
            {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </Button>
        </div>
        {file && <p className="px-4 pb-2 text-xs" style={{ color: "var(--pm-text-muted)" }}>📎 {file.name}</p>}
      </div>
    </div>
  );
}