import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";

export default function AdminHealth() {
  const [results, setResults] = useState([]);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    runChecks();
  }, []);

  const runChecks = async () => {
    setRefreshing(true);
    const checks = [];

    const calls = [
      { name: "getCatalogPublic", fn: () => base44.functions.invoke("getCatalogPublic", {}) },
      { name: "getCatalogAdmin", fn: () => base44.functions.invoke("getCatalogAdmin", {}) },
      { name: "getGalleryPublic", fn: () => base44.functions.invoke("getGalleryPublic", {}) },
      { name: "getCartBadgeCount", fn: () => base44.functions.invoke("getCartBadgeCount", {}) },
    ];

    const results = await Promise.allSettled(calls.map(c => c.fn()));

    results.forEach((result, idx) => {
      const callName = calls[idx].name;
      
      if (result.status === "rejected") {
        checks.push({
          name: callName,
          status: "FAIL",
          details: result.reason?.message || "Call failed",
          raw: null,
        });
        return;
      }

      const data = result.value?.data;

      if (callName === "getCatalogPublic") {
        const printOk = !!data?.printProduct;
        const variantsOk = (data?.printVariants ?? []).length >= 3;
        const variantsCents = (data?.printVariants ?? []).every(v => v.standard_price_cents);
        const mountsOk = (data?.mountsIncluded ?? []).length === 3;
        const nonPrintOk = (data?.nonPrintProducts ?? []).length === 2;
        const pricesOk = (data?.productPrices ?? []).length >= 2;
        
        const pass = printOk && variantsOk && variantsCents && mountsOk && nonPrintOk && pricesOk;
        
        checks.push({
          name: callName,
          status: pass ? "PASS" : "FAIL",
          details: pass
            ? `✓ printProduct, ${data.printVariants.length} variants (cents), ${data.mountsIncluded.length} mounts, ${data.nonPrintProducts.length} products, ${data.productPrices.length} prices`
            : `Missing: ${!printOk ? 'printProduct ' : ''}${!variantsOk ? 'variants ' : ''}${!variantsCents ? 'cents ' : ''}${!mountsOk ? 'mounts ' : ''}${!nonPrintOk ? 'products ' : ''}${!pricesOk ? 'prices' : ''}`,
          raw: data,
        });
      } else if (callName === "getCatalogAdmin") {
        const pass = !!(data?.products && data?.printVariants && data?.mounts);
        checks.push({
          name: callName,
          status: pass ? "PASS" : "FAIL",
          details: pass
            ? `${data.products.length} products, ${data.printVariants.length} variants, ${data.mounts.length} mounts`
            : "Missing required admin catalog data",
          raw: data,
        });
      } else if (callName === "getGalleryPublic") {
        const itemCount = (data?.items ?? []).length;
        checks.push({
          name: callName,
          status: itemCount === 0 ? "WARN" : "PASS",
          details: itemCount === 0 ? "No gallery items configured" : `${itemCount} gallery items`,
          raw: data,
        });
      } else if (callName === "getCartBadgeCount") {
        const pass = typeof data?.count === "number";
        checks.push({
          name: callName,
          status: pass ? "PASS" : "FAIL",
          details: pass ? `Count: ${data.count}` : "Invalid response",
          raw: data,
        });
      }
    });

    setResults(checks);
    setRefreshing(false);
  };

  const statusColor = (status) => {
    if (status === "PASS") return "#22c55e";
    if (status === "WARN") return "#f59e0b";
    return "#ef4444";
  };

  const statusIcon = (status) => {
    if (status === "PASS") return "✓";
    if (status === "WARN") return "⚠";
    return "✗";
  };

  return (
    <AdminLayout title="System Health">
      <div className="space-y-6">
        <div className="flex justify-end">
          <Button onClick={runChecks} disabled={refreshing}>
            {refreshing ? "Refreshing..." : "Refresh"}
          </Button>
        </div>

        <div className="space-y-4">
          {results.map((check, i) => (
            <div
              key={i}
              className="border rounded-xl p-6 bg-white dark:bg-zinc-900"
            >
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center gap-3">
                  <span style={{ fontSize: "24px", color: statusColor(check.status) }}>
                    {statusIcon(check.status)}
                  </span>
                  <h3 className="text-lg font-semibold">{check.name}</h3>
                </div>
                <span
                  style={{
                    padding: "4px 12px",
                    borderRadius: "12px",
                    fontSize: "12px",
                    fontWeight: "600",
                    background: check.status === "PASS" ? "#f0fdf4" : check.status === "WARN" ? "#fffbeb" : "#fef2f2",
                    color: statusColor(check.status),
                  }}
                >
                  {check.status}
                </span>
              </div>
              
              <div className="text-sm text-muted-foreground mb-4">
                {check.details}
              </div>

              <details>
                <summary className="cursor-pointer text-sm font-medium text-blue-600 hover:text-blue-700">
                  View Raw JSON
                </summary>
                <pre className="mt-3 p-4 bg-zinc-50 dark:bg-zinc-800 rounded-lg text-xs overflow-auto max-h-96">
                  {JSON.stringify(check.raw, null, 2)}
                </pre>
              </details>
            </div>
          ))}
        </div>
      </div>
    </AdminLayout>
  );
}