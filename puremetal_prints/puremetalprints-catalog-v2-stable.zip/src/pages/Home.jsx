import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/components/utils";
import { ArrowRight, Sparkles, Shield, Truck, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery } from "@tanstack/react-query";

const features = [
  { icon: Sparkles, title: "Premium Quality", desc: "HD printing on premium aluminum with vivid, lasting colors." },
  { icon: Shield, title: "Client Proofing", desc: "Review and approve digital proofs before production begins." },
  { icon: Truck, title: "Safe Delivery", desc: "Custom packaging ensures your prints arrive in perfect condition." },
];

export default function Home() {
  const [currentHeroIndex, setCurrentHeroIndex] = useState(0);
  const [heroCaption, setHeroCaption] = useState("Transform your memories into stunning metal prints that last a lifetime.");

  const { data: siteContent = [] } = useQuery({
    queryKey: ["home-site-content"],
    queryFn: () => base44.asServiceRole.entities.SiteContent.list(),
  });

  const { data: heroImages = [] } = useQuery({
    queryKey: ["home-hero-images"],
    queryFn: async () => {
      const images = await base44.asServiceRole.entities.GalleryImage.filter({ is_active: true });
      return images.sort((a, b) => a.sort_order - b.sort_order);
    },
  });

  const { data: heroFiles = [] } = useQuery({
    queryKey: ["home-hero-files"],
    queryFn: () => base44.asServiceRole.entities.File.filter({ kind: 'GALLERY' }),
    enabled: heroImages.length > 0,
  });

  const { data: announcements = [] } = useQuery({
    queryKey: ["home-announcements"],
    queryFn: () => base44.asServiceRole.entities.Announcement.filter({ is_active: true }),
  });

  const [dismissedAnnouncements, setDismissedAnnouncements] = useState([]);

  useEffect(() => {
    const caption = siteContent.find(c => c.key === 'hero_caption');
    if (caption) setHeroCaption(caption.value);
  }, [siteContent]);

  useEffect(() => {
    if (heroImages.length > 1) {
      const interval = setInterval(() => {
        setCurrentHeroIndex((prev) => (prev + 1) % heroImages.length);
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [heroImages.length]);

  const activeAnnouncements = announcements.filter(a => !dismissedAnnouncements.includes(a.id));
  const currentHeroImage = heroImages[currentHeroIndex];
  const currentHeroFile = currentHeroImage ? heroFiles.find(f => f.id === currentHeroImage.file_id) : null;
  const heroImageUrl = currentHeroFile?.file_url || "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80";

  const showCarouselControls = heroImages.length > 1;

  return (
    <div>
      {/* Announcement Bubble */}
      <AnimatePresence>
        {activeAnnouncements.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 max-w-md w-full mx-4"
          >
            <div className="bg-amber-50 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-800 rounded-xl shadow-lg p-4">
              {activeAnnouncements.map((announcement) => (
                <div key={announcement.id} className="flex items-start justify-between gap-3 mb-2 last:mb-0">
                  <div className="flex-1">
                    <p className="font-semibold text-sm text-amber-900 dark:text-amber-100">{announcement.title}</p>
                    <p className="text-xs text-amber-800 dark:text-amber-200 mt-1">{announcement.message}</p>
                  </div>
                  <button
                    onClick={() => setDismissedAnnouncements([...dismissedAnnouncements, announcement.id])}
                    className="text-amber-600 hover:text-amber-800 flex-shrink-0"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero with Carousel */}
      <section className="relative overflow-hidden" style={{ backgroundColor: "var(--pm-surface)" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-36">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <p className="text-sm font-semibold uppercase tracking-widest mb-4" style={{ color: "var(--pm-gold)" }}>
                Premium Metal Prints
              </p>
              <h1 className="text-4xl md:text-6xl font-bold tracking-tight leading-tight" style={{ color: "var(--pm-text)" }}>
                Your Images,<br />
                <span className="bg-gradient-to-r from-purple-600 to-amber-500 bg-clip-text text-transparent">
                  Forged in Metal
                </span>
              </h1>
              <p className="mt-6 text-lg max-w-lg" style={{ color: "var(--pm-text-muted)" }}>
                {heroCaption}
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link to={createPageUrl("CreatePrint")}>
                  <Button size="lg" className="bg-neutral-900 text-white hover:bg-neutral-800 dark:bg-white dark:text-black dark:hover:bg-neutral-200 gap-2">
                    Start Creating <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
                <Link to={createPageUrl("Gallery")}>
                  <Button size="lg" variant="outline" className="gap-2">
                    Browse Gallery
                  </Button>
                </Link>
              </div>
            </motion.div>

            <div className="relative">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentHeroIndex}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.5 }}
                  className="relative"
                >
                  <div className="aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl">
                    <img
                      src={heroImageUrl}
                      alt={currentHeroImage?.title || "Metal print showcase"}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </motion.div>
              </AnimatePresence>

              {showCarouselControls && (
                <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
                  {heroImages.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentHeroIndex(index)}
                      className={`w-2 h-2 rounded-full transition-all ${
                        index === currentHeroIndex
                          ? "bg-white w-6"
                          : "bg-white/50 hover:bg-white/75"
                      }`}
                    />
                  ))}
                </div>
              )}

              <div className="absolute -bottom-4 -left-4 bg-white dark:bg-neutral-800 rounded-xl shadow-lg p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm font-semibold">PureMetal Reserve</p>
                  <p className="text-xs text-muted-foreground">Industry-leading quality</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight" style={{ color: "var(--pm-text)" }}>Why PureMetal?</h2>
          <p className="mt-3 text-lg" style={{ color: "var(--pm-text-muted)" }}>Every print is a masterpiece, from upload to doorstep.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 * i, duration: 0.5 }}
              className="rounded-2xl p-8 border transition-all hover:shadow-lg"
              style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}
            >
              <div className="w-12 h-12 rounded-xl bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center mb-5">
                <f.icon className="w-6 h-6" style={{ color: "var(--pm-accent)" }} />
              </div>
              <h3 className="text-lg font-semibold mb-2">{f.title}</h3>
              <p className="text-sm leading-relaxed" style={{ color: "var(--pm-text-muted)" }}>{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center rounded-3xl p-12 md:p-16" style={{ backgroundColor: "var(--pm-surface)", border: `1px solid var(--pm-border)` }}>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Create?</h2>
          <p className="text-lg mb-8" style={{ color: "var(--pm-text-muted)" }}>Upload your image and we'll handle the rest. Premium metal prints starting at $45.</p>
          <Link to={createPageUrl("CreatePrint")}>
            <Button size="lg" className="bg-neutral-900 text-white hover:bg-neutral-800 dark:bg-white dark:text-black gap-2">
              Get Started <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}