import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/components/utils";
import { Search, CheckCircle, XCircle, AlertCircle, Clock, Loader2, MessageSquare } from "lucide-react";
import AdminLayout from "@/components/admin/AdminLayout";
import PMBadge from "@/components/ui/PMBadge";

const STATUS_FILTERS = [
  { value: "all", label: "All Orders" },
  { value: "UPLOADED", label: "New / Uploaded" },
  { value: "NEEDS_REVIEW", label: "Needs Review" },
  { value: "IN_PROOFING", label: "In Proofing" },
  { value: "PROOF_DELIVERED", label: "Proof Delivered" },
  { value: "PROOF_SELECTED", label: "Proof Selected" },
  { value: "APPROVED", label: "Approved (Ready)" },
  { value: "IN_PRODUCTION", label: "In Production" },
  { value: "COMPLETED", label: "Completed" },
  { value: "CANCELLATION_REQUESTED", label: "Cancellation Requested" },
  { value: "CANCELLED", label: "Cancelled" },
];

const STATUS_VARIANTS = {
  DRAFT: "default", UPLOADED: "purple", NEEDS_REVIEW: "warning", 
  PROOF_DELIVERED: "purple", PROOF_SELECTED: "success", APPROVED: "gold",
  IN_PRODUCTION: "purple", COMPLETED: "success", CANCELLATION_REQUESTED: "error", CANCELLED: "error",
};

export default function AdminOrders() {
  const [user, setUser] = useState(null);
  const [statusFilter, setStatusFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      const me = await base44.auth.me();
      if (me.role !== "admin") { window.location.href = "/"; return; }
      setUser(me);

      const params = new URLSearchParams(window.location.search);
      const status = params.get("status");
      if (status) setStatusFilter(status);
    })();
  }, []);

  const { data: orders = [], isLoading } = useQuery({
    queryKey: ["admin-orders"],
    queryFn: () => base44.asServiceRole.entities.Order.list('-created_date', 200),
    enabled: !!user,
  });

  const { data: clients = [] } = useQuery({
    queryKey: ["admin-clients"],
    queryFn: () => base44.asServiceRole.entities.Client.list(),
    enabled: !!user,
  });

  const { data: items = [] } = useQuery({
    queryKey: ["admin-items"],
    queryFn: () => base44.asServiceRole.entities.OrderItem.list(),
    enabled: !!user,
  });

  const { data: proofs = [] } = useQuery({
    queryKey: ["admin-proofs"],
    queryFn: () => base44.asServiceRole.entities.Proof.list(),
    enabled: !!user,
  });

  const { data: files = [] } = useQuery({
    queryKey: ["admin-files"],
    queryFn: () => base44.asServiceRole.entities.File.list(),
    enabled: !!user,
  });

  if (!user) return <div className="flex items-center justify-center min-h-screen"><Loader2 className="w-8 h-8 animate-spin" /></div>;

  const getClientName = (clientId) => {
    const client = clients.find(c => c.id === clientId);
    return client?.full_name || "Unknown";
  };

  const getOrderIndicators = (order) => {
    const orderItems = items.filter(i => i.order_id === order.id);
    const orderProofs = proofs.filter(p => orderItems.some(item => item.id === p.order_item_id));
    
    const hasDeliveredProof = orderProofs.some(p => p.is_delivered);
    const hasSelectedProof = orderProofs.some(p => p.is_selected);
    const isApproved = order.status === 'APPROVED' || order.status === 'IN_PRODUCTION' || order.status === 'COMPLETED';
    
    const printReadyFiles = files.filter(f => 
      f.kind === 'PRINT_READY' && orderItems.some(item => item.id === f.order_item_id)
    );
    const hasPrintReady = printReadyFiles.length > 0;
    
    const allInProduction = orderItems.length > 0 && orderItems.every(i => 
      i.status === 'IN_PRODUCTION' || i.status === 'COMPLETED'
    );
    const allCompleted = orderItems.length > 0 && orderItems.every(i => i.status === 'COMPLETED');

    return {
      proofDelivered: hasDeliveredProof,
      proofSelected: hasSelectedProof,
      approved: isApproved,
      printReady: hasPrintReady,
      inProduction: allInProduction,
      completed: allCompleted,
      cancellationRequested: order.status === 'CANCELLATION_REQUESTED',
    };
  };

  const filteredOrders = orders.filter(order => {
    if (statusFilter !== "all" && order.status !== statusFilter) return false;
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      const clientName = getClientName(order.client_id).toLowerCase();
      const orderNum = order.order_number?.toLowerCase() || "";
      return clientName.includes(query) || orderNum.includes(query);
    }
    
    return true;
  });

  return (
    <AdminLayout title="Orders">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: "var(--pm-text-muted)" }} />
            <Input
              placeholder="Search by client name or order number..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-64">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {STATUS_FILTERS.map(filter => (
                <SelectItem key={filter.value} value={filter.value}>{filter.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin" />
          </div>
        ) : (
          <div className="rounded-lg border overflow-hidden" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-bg)" }}>
                  <tr>
                    <th className="text-left p-4 text-sm font-semibold">Order #</th>
                    <th className="text-left p-4 text-sm font-semibold">Client</th>
                    <th className="text-left p-4 text-sm font-semibold">Status</th>
                    <th className="text-left p-4 text-sm font-semibold">Indicators</th>
                    <th className="text-left p-4 text-sm font-semibold">Items</th>
                    <th className="text-left p-4 text-sm font-semibold">Total</th>
                    <th className="text-left p-4 text-sm font-semibold">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredOrders.map((order) => {
                    const indicators = getOrderIndicators(order);
                    const orderItems = items.filter(i => i.order_id === order.id);

                    return (
                      <tr key={order.id} className="border-b hover:bg-neutral-50 dark:hover:bg-neutral-800 transition-colors" style={{ borderColor: "var(--pm-border)" }}>
                        <td className="p-4">
                          <Link to={createPageUrl(`AdminOrderDetail?id=${order.id}`)} className="font-medium hover:text-blue-600">
                            {order.order_number}
                          </Link>
                        </td>
                        <td className="p-4 text-sm">{getClientName(order.client_id)}</td>
                        <td className="p-4">
                          <PMBadge variant={STATUS_VARIANTS[order.status]}>
                            {order.status.replace(/_/g, ' ')}
                          </PMBadge>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            {indicators.proofDelivered && <CheckCircle className="w-4 h-4 text-emerald-600" title="Proof Delivered" />}
                            {indicators.proofSelected && <CheckCircle className="w-4 h-4 text-blue-600" title="Proof Selected" />}
                            {indicators.approved && <CheckCircle className="w-4 h-4 text-amber-600" title="Approved" />}
                            {indicators.printReady && <CheckCircle className="w-4 h-4 text-purple-600" title="Print Ready" />}
                            {indicators.inProduction && <Clock className="w-4 h-4 text-indigo-600" title="In Production" />}
                            {indicators.completed && <CheckCircle className="w-4 h-4 text-green-600" title="Completed" />}
                            {indicators.cancellationRequested && <AlertCircle className="w-4 h-4 text-red-600" title="Cancellation Requested" />}
                          </div>
                        </td>
                        <td className="p-4 text-sm">{orderItems.length}</td>
                        <td className="p-4 font-medium">${(order.total || 0).toFixed(2)}</td>
                        <td className="p-4 text-sm" style={{ color: "var(--pm-text-muted)" }}>
                          {new Date(order.created_date).toLocaleDateString()}
                        </td>
                      </tr>
                    );
                  })}
                  {filteredOrders.length === 0 && (
                    <tr>
                      <td colSpan="7" className="p-8 text-center" style={{ color: "var(--pm-text-muted)" }}>
                        No orders found
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}