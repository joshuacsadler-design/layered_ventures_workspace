import React, { useMemo, useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Lock } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";

// Price conversion helpers
const dollarsToCents = (v) => Math.round(Number(v) * 100);
const getStdCents = (variant) => variant?.standard_price_cents ?? (variant?.standard_price != null ? dollarsToCents(variant.standard_price) : null);
const getResCents = (variant) => variant?.reserve_price_cents ?? (variant?.reserve_price != null ? dollarsToCents(variant.reserve_price) : null);
const fmt = (cents) => cents ? `$${(cents / 100).toFixed(2)}` : "—";

export default function CreatePrint() {
  const navigate = useNavigate();
  const [sp] = useSearchParams();
  const skuParam = sp.get("sku") || "PM-METAL";
  const fromGallery = sp.get("fromGallery") === "1";
  const galleryId = sp.get("galleryId");

  const { data: catalog, isLoading: catalogLoading } = useQuery({
    queryKey: ["catalog-public-createprint"],
    queryFn: async () => (await base44.functions.invoke("getCatalogPublic", {})).data,
  });

  const { data: galleryConfig, isLoading: galleryLoading } = useQuery({
    queryKey: ["gallery-config", galleryId],
    queryFn: async () => {
      const resp = await base44.functions.invoke("getGalleryItemConfig", { gallery_image_id: galleryId });
      return resp.data;
    },
    enabled: fromGallery && !!galleryId,
  });

  const product = useMemo(() => catalog?.printProduct ?? null, [catalog]);
  const variants = useMemo(() => catalog?.printVariants ?? [], [catalog]);
  const mounts = useMemo(() => catalog?.mountsIncluded ?? [], [catalog]);

  const [isLocked, setIsLocked] = useState(false);
  const [size, setSize] = useState("");
  const [tier, setTier] = useState("standard");
  const [mountKey, setMountKey] = useState("PRINT_ONLY");
  const [quantity, setQuantity] = useState(1);
  const [showUnlockModal, setShowUnlockModal] = useState(false);
  const [pendingChange, setPendingChange] = useState(null);

  useEffect(() => {
    if (fromGallery && galleryConfig) {
      setSize(galleryConfig.configured_size);
      setTier(galleryConfig.configured_tier);
      setMountKey(galleryConfig.configured_mount_key);
      setQuantity(galleryConfig.configured_quantity);
      setIsLocked(true);
    } else if (variants?.length > 0 && !size) {
      setSize(variants[0].size);
    }
  }, [fromGallery, galleryConfig, variants, size]);

  useEffect(() => {
    if (mounts?.length > 0 && !mountKey) {
      const hasPrintOnly = mounts.some(m => m.key === "PRINT_ONLY");
      setMountKey(hasPrintOnly ? "PRINT_ONLY" : mounts[0].key);
    }
  }, [mounts, mountKey]);

  const selectedVariant = useMemo(() => variants?.find(v => v.size === size) ?? null, [variants, size]);
  
  const stdCents = selectedVariant ? getStdCents(selectedVariant) : null;
  const resCents = selectedVariant ? getResCents(selectedVariant) : null;
  const reserveAllowed = Boolean(
    selectedVariant?.reserve_enabled && 
    resCents && 
    resCents > 0 && 
    selectedVariant?.show_reserve_upsell
  );

  useEffect(() => {
    if (tier === "reserve" && !reserveAllowed && !isLocked) setTier("standard");
  }, [tier, reserveAllowed, isLocked]);

  const handleFieldChange = (field, value) => {
    if (isLocked) {
      setPendingChange({ field, value });
      setShowUnlockModal(true);
      return;
    }
    applyChange(field, value);
  };

  const applyChange = (field, value) => {
    if (field === "size") setSize(value);
    if (field === "tier") setTier(value);
    if (field === "mountKey") setMountKey(value);
    if (field === "quantity") setQuantity(value);
  };

  const handleUnlockConfirm = () => {
    setIsLocked(false);
    if (pendingChange) {
      applyChange(pendingChange.field, pendingChange.value);
      setPendingChange(null);
    }
    setShowUnlockModal(false);
  };

  const handleUnlockCancel = () => {
    setPendingChange(null);
    setShowUnlockModal(false);
  };

  const standardPriceCents = useMemo(() => {
    if (!selectedVariant) return null;
    const baseUnit = tier === "reserve" ? resCents : stdCents;
    if (!baseUnit || baseUnit <= 0) return null;
    return baseUnit * quantity;
  }, [selectedVariant, tier, quantity, stdCents, resCents]);

  const galleryPriceCents = useMemo(() => {
    if (!isLocked || !standardPriceCents || !galleryConfig) return null;
    const pct = Number(galleryConfig.gallery_discount_pct ?? 15);
    const discounted = Math.round(standardPriceCents * (1 - pct / 100));
    return discounted;
  }, [isLocked, standardPriceCents, galleryConfig]);

  const addToCart = useMutation({
    mutationFn: async () => {
      const resp = await base44.functions.invoke("addToCart", {
        kind: "print",
        product_id: product.id,
        size,
        tier,
        mount_key: mountKey,
        quantity,
        gallery_image_id: isLocked ? galleryId : null,
        gallery_pricing_applied: isLocked,
      });
      return resp.data;
    },
    onSuccess: () => navigate("/cart"),
  });

  if (catalogLoading || (fromGallery && galleryLoading)) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  if (!product || !product.active || !product.show_in_shop || !product.in_stock) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16">
        <Card>
          <CardHeader><CardTitle>Print Temporarily Unavailable</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
              This print is currently hidden or out of stock.
            </p>
            <p className="text-sm text-muted-foreground">
              If you are the studio owner, re-enable it in:<br />
              <span className="font-semibold text-foreground">Admin → Products → Metal Print</span>
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!variants?.length) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-12">
        <Card>
          <CardHeader><CardTitle>No sizes configured</CardTitle></CardHeader>
          <CardContent className="text-sm text-muted-foreground">Add size offerings in AdminProducts or run Initialize.</CardContent>
        </Card>
      </div>
    );
  }

  const displayPriceCents = isLocked && galleryPriceCents ? galleryPriceCents : standardPriceCents;
  const priceLabel = isLocked ? "Gallery Price" : "Price";

  return (
    <>
      <div className="max-w-4xl mx-auto px-4 py-10 space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{product.name}</h1>
          <p className="mt-2 text-muted-foreground">{product.short_description ?? "Build your print."}</p>
        </div>

        {isLocked && (
          <div className="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 rounded-lg p-4 flex items-start gap-3">
            <Lock className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <div className="font-semibold text-sm text-emerald-900 dark:text-emerald-100">
                Gallery Pricing Applied ({galleryConfig?.gallery_discount_pct ?? 15}% off)
              </div>
              <div className="text-xs text-emerald-800 dark:text-emerald-200 mt-1">
                Changing settings will change your price to standard pricing.
              </div>
            </div>
          </div>
        )}

        <Card>
          <CardHeader><CardTitle>Customize</CardTitle></CardHeader>
          <CardContent className="space-y-5">
            <div className="grid md:grid-cols-4 gap-4">
              <div>
                <div className="text-sm font-medium mb-2">Size</div>
                <select 
                  className="w-full border rounded-md p-2" 
                  value={size} 
                  onChange={(e) => handleFieldChange("size", e.target.value)}
                >
                  {variants.map(v => (
                    <option key={v.id} value={v.size}>{v.size}"</option>
                  ))}
                </select>
              </div>

              <div>
                <div className="text-sm font-medium mb-2">Edition</div>
                <select 
                  className="w-full border rounded-md p-2" 
                  value={tier} 
                  onChange={(e) => handleFieldChange("tier", e.target.value)}
                >
                  <option value="standard">Standard</option>
                  {reserveAllowed ? (
                    <option value="reserve">PureMetal Reserve (Premium finish)</option>
                  ) : (
                    <option value="reserve" disabled>Reserve not offered for this size</option>
                  )}
                </select>
                {!reserveAllowed && tier === "standard" && (
                  <div className="text-xs text-muted-foreground mt-1">
                    Reserve not offered for this size.
                  </div>
                )}
              </div>

              <div>
                <div className="text-sm font-medium mb-2">Mount (included)</div>
                <select 
                  className="w-full border rounded-md p-2" 
                  value={mountKey} 
                  onChange={(e) => handleFieldChange("mountKey", e.target.value)}
                >
                  {mounts.map(m => (
                    <option key={m.key} value={m.key}>{m.label}</option>
                  ))}
                </select>
              </div>

              <div>
                <div className="text-sm font-medium mb-2">Quantity</div>
                <input 
                  type="number" 
                  min="1" 
                  className="w-full border rounded-md p-2" 
                  value={quantity} 
                  onChange={(e) => handleFieldChange("quantity", Number(e.target.value))}
                />
              </div>
            </div>

            <div className="border-t pt-4">
              <div className="flex justify-between items-center mb-4">
                <span className="text-lg font-semibold">{priceLabel}</span>
                <div className="text-right">
                  {isLocked && standardPriceCents && (
                    <div className="text-xs text-muted-foreground line-through">
                      {fmt(standardPriceCents)}
                    </div>
                  )}
                  <div className="text-2xl font-bold">
                    {fmt(displayPriceCents)}
                  </div>
                </div>
              </div>

              <Button
                className="w-full"
                onClick={() => addToCart.mutate()}
                disabled={addToCart.isPending || !selectedVariant || !selectedVariant.purchasable}
              >
                {!selectedVariant?.purchasable ? "Size temporarily unavailable" : addToCart.isPending ? "Adding..." : "Add to cart"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Dialog open={showUnlockModal} onOpenChange={setShowUnlockModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Change Configuration?</DialogTitle>
            <DialogDescription>
              Changing settings will change your price from the Gallery Price to standard pricing.
              Do you want to continue?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={handleUnlockCancel}>Cancel</Button>
            <Button onClick={handleUnlockConfirm}>Yes, Change Settings</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}