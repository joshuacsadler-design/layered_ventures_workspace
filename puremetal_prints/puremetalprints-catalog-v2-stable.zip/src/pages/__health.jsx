// Route alias: This file creates the /__health route
// It re-exports the AdminHealth component
export { default } from './AdminHealth';