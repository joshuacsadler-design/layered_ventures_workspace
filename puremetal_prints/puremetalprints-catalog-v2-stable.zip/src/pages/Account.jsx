import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/components/utils";
import { Package, Eye, Clock, ChevronRight, User } from "lucide-react";
import PMBadge from "@/components/ui/PMBadge";
import { motion } from "framer-motion";
import { getClientStatusLabel } from "@/components/utils/statusDisplay";

const STATUS_VARIANT = {
  DRAFT: "default",
  UPLOADED: "purple",
  NEEDS_REVIEW: "warning",
  PROOF_DELIVERED: "purple",
  PROOF_SELECTED: "success",
  APPROVED: "gold",
  IN_PRODUCTION: "purple",
  COMPLETED: "success",
  CANCELLATION_REQUESTED: "error",
  CANCELLED: "error",
};

export default function Account() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      setUser(await base44.auth.me());
    })();
  }, []);

  const { data: orders = [] } = useQuery({
    queryKey: ["my-orders", user?.id],
    queryFn: () => base44.entities.Order.filter({ user_id: user.id }, "-created_date"),
    enabled: !!user,
  });

  if (!user) return null;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Profile header */}
      <div className="rounded-2xl border p-6 mb-8 flex items-center gap-4" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}>
        <div className="w-14 h-14 rounded-full bg-neutral-200 dark:bg-neutral-700 flex items-center justify-center">
          <User className="w-7 h-7" style={{ color: "var(--pm-text-muted)" }} />
        </div>
        <div>
          <h1 className="text-xl font-bold">{user.full_name}</h1>
          <p className="text-sm" style={{ color: "var(--pm-text-muted)" }}>{user.email}</p>
        </div>
      </div>

      {/* Orders */}
      <h2 className="text-xl font-semibold mb-4">My Orders</h2>
      {orders.length === 0 ? (
        <div className="text-center py-16 rounded-2xl border" style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}>
          <Package className="w-12 h-12 mx-auto mb-4 opacity-20" />
          <p className="text-lg font-medium">No orders yet</p>
          <p className="text-sm mt-1" style={{ color: "var(--pm-text-muted)" }}>Create your first metal print!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {orders.filter(o => o.status !== "DRAFT" && o.status !== "CANCELLED").map((order, i) => (
            <motion.div key={order.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>
              <Link
                to={createPageUrl(`OrderDetail?id=${order.id}`)}
                className="flex items-center justify-between rounded-xl border p-4 transition-all hover:shadow-md"
                style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center">
                    <Package className="w-5 h-5" style={{ color: "var(--pm-text-muted)" }} />
                  </div>
                  <div>
                    <p className="font-semibold">{order.order_number}</p>
                    <p className="text-xs flex items-center gap-1" style={{ color: "var(--pm-text-muted)" }}>
                      <Clock className="w-3 h-3" />
                      {new Date(order.created_date).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <PMBadge variant={STATUS_VARIANT[order.status]}>{getClientStatusLabel(order.status)}</PMBadge>
                  <span className="font-semibold">${(order.total || order.subtotal || 0).toFixed(2)}</span>
                  <ChevronRight className="w-4 h-4 opacity-30" />
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}