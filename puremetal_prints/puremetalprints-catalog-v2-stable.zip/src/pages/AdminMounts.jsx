import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import AdminLayout from "@/components/admin/AdminLayout";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

export default function AdminMounts() {
  const qc = useQueryClient();
  const [uploadingImage, setUploadingImage] = useState(null);
  const [showArchived, setShowArchived] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newMount, setNewMount] = useState({
    key: '',
    keyType: 'preset',
    customKey: '',
    label: '',
    description: '',
    included_with_prints: true,
    standalone_sellable: false,
    standalone_price: 0,
    active: true,
    in_stock: true,
    stock_mode: 'HIDE'
  });

  const { data: catalog, isLoading } = useQuery({
    queryKey: ["catalog-admin-mounts"],
    queryFn: async () => (await base44.functions.invoke("getCatalogAdmin", {})).data,
  });

  const updateMount = useMutation({
    mutationFn: ({ id, patch }) => base44.functions.invoke("updateMountAdmin", { id, patch }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["catalog-admin-mounts"] });
    },
  });

  const createMount = useMutation({
    mutationFn: (data) => base44.functions.invoke("createMountAdmin", data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["catalog-admin-mounts"] });
      setShowAddModal(false);
      setNewMount({
        key: '',
        keyType: 'preset',
        customKey: '',
        label: '',
        description: '',
        included_with_prints: true,
        standalone_sellable: false,
        standalone_price: 0,
        active: true,
        in_stock: true,
        stock_mode: 'HIDE'
      });
    },
  });

  const deleteMount = useMutation({
    mutationFn: (mount_offering_id) => base44.functions.invoke("deleteMountAdmin", { mount_offering_id }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["catalog-admin-mounts"] });
    },
  });

  const uploadImage = async (file, mountId) => {
    setUploadingImage(mountId);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const resp = await base44.functions.invoke("uploadPublicImage", formData);
      const { file_id } = resp.data;
      await updateMount.mutateAsync({ id: mountId, patch: { image_file_id: file_id } });
    } catch (e) {
      alert("Upload failed: " + e.message);
    } finally {
      setUploadingImage(null);
    }
  };

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin" />
        </div>
      </AdminLayout>
    );
  }

  const allMounts = catalog?.mounts ?? [];
  const mounts = allMounts.filter(m => showArchived || m.active);
  const activeMountsWithPrints = mounts.filter(m => m.active && m.included_with_prints).length;

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Mount Management</h1>
            <p className="text-sm text-muted-foreground mt-1">Configure mount options for prints</p>
          </div>
          <div className="flex gap-2">
            <div className="flex items-center gap-2">
              <Switch checked={showArchived} onCheckedChange={setShowArchived} />
              <Label>Show Archived</Label>
            </div>
            <Button onClick={() => setShowAddModal(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Mount
            </Button>
          </div>
        </div>

        <div className="space-y-4">
          {mounts.map((mount) => (
            <Card key={mount.id}>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>{mount.label} {!mount.active && <span className="text-xs text-muted-foreground">(Archived)</span>}</CardTitle>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => {
                      if (activeMountsWithPrints <= 1 && mount.active && mount.included_with_prints) {
                        alert('At least one mount option must remain available for prints.');
                        return;
                      }
                      if (confirm(`Archive ${mount.label}? It will no longer appear for prints.`)) {
                        deleteMount.mutate(mount.id);
                      }
                    }}
                    disabled={deleteMount.isPending}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-3">
                  <div>
                    <Label>Label</Label>
                    <Input
                      value={mount.label}
                      onChange={(e) => updateMount.mutate({ id: mount.id, patch: { label: e.target.value } })}
                    />
                  </div>
                  <div>
                    <Label>Standalone Price ($)</Label>
                    <Input
                      type="number"
                      value={mount.standalone_price ?? 0}
                      onChange={(e) => updateMount.mutate({ id: mount.id, patch: { standalone_price: Number(e.target.value) } })}
                      disabled={!mount.standalone_sellable}
                    />
                  </div>
                </div>

                <div>
                  <Label>Description</Label>
                  <Textarea
                    value={mount.description ?? ""}
                    onChange={(e) => updateMount.mutate({ id: mount.id, patch: { description: e.target.value } })}
                    rows={2}
                  />
                </div>

                <div>
                  <Label>Image</Label>
                  <div className="flex gap-2 items-center">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        if (e.target.files?.[0]) {
                          uploadImage(e.target.files[0], mount.id);
                        }
                      }}
                      disabled={uploadingImage === mount.id}
                      className="text-sm"
                    />
                    {uploadingImage === mount.id && <Loader2 className="w-4 h-4 animate-spin" />}
                  </div>
                </div>

                <div className="grid md:grid-cols-4 gap-3">
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={mount.active}
                      onCheckedChange={(c) => updateMount.mutate({ id: mount.id, patch: { active: c } })}
                    />
                    <Label>Active</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={mount.included_with_prints}
                      onCheckedChange={(c) => updateMount.mutate({ id: mount.id, patch: { included_with_prints: c } })}
                    />
                    <Label>Include with Prints</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={mount.standalone_sellable}
                      onCheckedChange={(c) => updateMount.mutate({ id: mount.id, patch: { standalone_sellable: c } })}
                    />
                    <Label>Sell Standalone</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={mount.in_stock}
                      onCheckedChange={(c) => updateMount.mutate({ id: mount.id, patch: { in_stock: c } })}
                    />
                    <Label>In Stock</Label>
                  </div>
                </div>

                <div>
                  <Label>Stock Mode</Label>
                  <select
                    className="w-full border rounded-md p-2"
                    value={mount.stock_mode ?? "HIDE"}
                    onChange={(e) => updateMount.mutate({ id: mount.id, patch: { stock_mode: e.target.value } })}
                  >
                    <option value="HIDE">Hide when unavailable</option>
                    <option value="DISABLE">Show as unavailable</option>
                  </select>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Add Mount Modal */}
        <Dialog open={showAddModal} onOpenChange={setShowAddModal}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New Mount</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Mount Key</Label>
                <div className="space-y-2">
                  <select
                    className="w-full border rounded-md p-2"
                    value={newMount.keyType}
                    onChange={(e) => setNewMount({ ...newMount, keyType: e.target.value, key: e.target.value === 'custom' ? newMount.customKey : '' })}
                  >
                    <option value="preset">Preset Key</option>
                    <option value="custom">Custom Key</option>
                  </select>
                  {newMount.keyType === 'preset' ? (
                    <select
                      className="w-full border rounded-md p-2"
                      value={newMount.key}
                      onChange={(e) => setNewMount({ ...newMount, key: e.target.value })}
                    >
                      <option value="">Select a key...</option>
                      <option value="PRINT_ONLY">PRINT_ONLY</option>
                      <option value="PURESHADOW_STANDARD">PURESHADOW_STANDARD</option>
                      <option value="PURESHADOW_BLACK">PURESHADOW_BLACK</option>
                    </select>
                  ) : (
                    <Input
                      placeholder="Enter custom key (e.g., CUSTOM_MOUNT)"
                      value={newMount.customKey}
                      onChange={(e) => setNewMount({ ...newMount, customKey: e.target.value, key: e.target.value })}
                    />
                  )}
                </div>
              </div>
              <div>
                <Label>Label</Label>
                <Input
                  value={newMount.label}
                  onChange={(e) => setNewMount({ ...newMount, label: e.target.value })}
                  placeholder="Print Only"
                />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea
                  value={newMount.description}
                  onChange={(e) => setNewMount({ ...newMount, description: e.target.value })}
                  rows={2}
                />
              </div>
              <div className="grid md:grid-cols-2 gap-3">
                <div className="flex items-center gap-2">
                  <Switch
                    checked={newMount.included_with_prints}
                    onCheckedChange={(c) => setNewMount({ ...newMount, included_with_prints: c })}
                  />
                  <Label>Include with Prints</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={newMount.standalone_sellable}
                    onCheckedChange={(c) => setNewMount({ ...newMount, standalone_sellable: c })}
                  />
                  <Label>Sell Standalone</Label>
                </div>
              </div>
              {newMount.standalone_sellable && (
                <div>
                  <Label>Standalone Price ($)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={newMount.standalone_price}
                    onChange={(e) => setNewMount({ ...newMount, standalone_price: Number(e.target.value) })}
                  />
                </div>
              )}
              <div className="grid md:grid-cols-3 gap-3">
                <div className="flex items-center gap-2">
                  <Switch
                    checked={newMount.active}
                    onCheckedChange={(c) => setNewMount({ ...newMount, active: c })}
                  />
                  <Label>Active</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={newMount.in_stock}
                    onCheckedChange={(c) => setNewMount({ ...newMount, in_stock: c })}
                  />
                  <Label>In Stock</Label>
                </div>
                <div>
                  <Label>Stock Mode</Label>
                  <select
                    className="w-full border rounded-md p-2"
                    value={newMount.stock_mode}
                    onChange={(e) => setNewMount({ ...newMount, stock_mode: e.target.value })}
                  >
                    <option value="HIDE">Hide</option>
                    <option value="DISABLE">Disable</option>
                  </select>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAddModal(false)}>Cancel</Button>
              <Button 
                onClick={() => {
                  const finalKey = newMount.keyType === 'custom' ? newMount.customKey : newMount.key;
                  if (!finalKey || !newMount.label) {
                    alert('Please enter key and label');
                    return;
                  }
                  createMount.mutate({
                    key: finalKey,
                    label: newMount.label,
                    description: newMount.description,
                    included_with_prints: newMount.included_with_prints,
                    standalone_sellable: newMount.standalone_sellable,
                    standalone_price: newMount.standalone_price,
                    active: newMount.active,
                    in_stock: newMount.in_stock,
                    stock_mode: newMount.stock_mode
                  });
                }}
                disabled={createMount.isPending}
              >
                {createMount.isPending ? "Creating..." : "Create Mount"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}