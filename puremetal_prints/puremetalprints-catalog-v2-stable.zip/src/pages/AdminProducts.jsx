import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import AdminLayout from "@/components/admin/AdminLayout";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Loader2, Plus, Upload, X } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

export default function AdminProducts() {
  const qc = useQueryClient();
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showNewModal, setShowNewModal] = useState(false);
  const [newProductData, setNewProductData] = useState({ type: "accessory", name: "" });
  const [uploadingImage, setUploadingImage] = useState(false);
  const [showArchived, setShowArchived] = useState(false);
  const [editingVariant, setEditingVariant] = useState(null);
  const [editingPrice, setEditingPrice] = useState(null);
  const [showNewPriceModal, setShowNewPriceModal] = useState(false);
  const [showAddSizeModal, setShowAddSizeModal] = useState(false);
  const [newSize, setNewSize] = useState({ 
    size: '', 
    customSize: '', 
    sizeType: 'preset',
    standard_price_dollars: 0, 
    reserve_enabled: false, 
    reserve_price_dollars: 0, 
    show_reserve_upsell: false,
    active: true,
    show_in_shop: true,
    in_stock: true,
    stock_mode: 'HIDE',
    sort_order: 0
  });

  const { data: catalog, isLoading } = useQuery({
    queryKey: ["catalog-admin"],
    queryFn: async () => (await base44.functions.invoke("getCatalogAdmin", {})).data,
  });

  const initCatalog = useMutation({
    mutationFn: () => base44.functions.invoke("ensureCatalogDefaults", {}),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["catalog-admin"] });
      alert("Catalog initialized successfully");
    },
  });

  const syncMounts = useMutation({
    mutationFn: () => base44.functions.invoke("syncMountProductsFromOfferings", {}),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["catalog-admin"] });
      alert("Mount products synced successfully");
    },
  });

  const repairMounts = useMutation({
    mutationFn: () => base44.functions.invoke("repairMountProducts", {}),
    onSuccess: (resp) => {
      qc.invalidateQueries({ queryKey: ["catalog-admin"] });
      alert(`Repaired mounts: ${resp.data.archived_count} duplicates archived, kept ${resp.data.kept.join(', ')}`);
    },
  });

  const createProduct = useMutation({
    mutationFn: (data) => base44.functions.invoke("createProductAdmin", data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["catalog-admin"] });
      setShowNewModal(false);
      setNewProductData({ type: "accessory", name: "" });
    },
  });

  const updateProduct = useMutation({
    mutationFn: ({ id, patch }) => base44.functions.invoke("updateProductAdmin", { id, patch }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["catalog-admin"] });
      setSelectedProduct(null);
    },
  });

  const upsertVariant = useMutation({
    mutationFn: (data) => base44.functions.invoke("upsertPrintVariantAdmin", data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["catalog-admin"] });
      setEditingVariant(null);
      setShowAddSizeModal(false);
      setNewSize({ 
        size: '', 
        customSize: '', 
        sizeType: 'preset',
        standard_price_dollars: 0, 
        reserve_enabled: false, 
        reserve_price_dollars: 0, 
        show_reserve_upsell: false,
        active: true,
        show_in_shop: true,
        in_stock: true,
        stock_mode: 'HIDE',
        sort_order: 0
      });
    },
  });

  const upsertPrice = useMutation({
    mutationFn: (data) => base44.functions.invoke("upsertProductPriceAdmin", data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["catalog-admin"] });
      setEditingPrice(null);
      setShowNewPriceModal(false);
    },
  });

  const archivePrice = useMutation({
    mutationFn: (id) => base44.functions.invoke("archiveProductPriceAdmin", { id }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["catalog-admin"] });
    },
  });

  const deleteProduct = useMutation({
    mutationFn: (product_id) => base44.functions.invoke("deleteProductAdmin", { product_id }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["catalog-admin"] });
      setSelectedProduct(null);
    },
  });

  const deleteVariant = useMutation({
    mutationFn: (print_variant_id) => base44.functions.invoke("deletePrintVariantAdmin", { print_variant_id }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["catalog-admin"] });
    },
  });

  const uploadImage = async (file, productId) => {
    setUploadingImage(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const resp = await base44.functions.invoke("uploadPublicImage", formData);
      const { file_id } = resp.data;
      await updateProduct.mutateAsync({ id: productId, patch: { image_file_id: file_id } });
    } catch (e) {
      alert("Upload failed: " + e.message);
    } finally {
      setUploadingImage(false);
    }
  };

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin" />
        </div>
      </AdminLayout>
    );
  }

  const allProducts = catalog?.products ?? [];
  const products = allProducts.filter(p => showArchived || p.active);
  
  // Dedupe displayed products by SKU (keep first, prefer active then show_in_shop)
  const productsMap = new Map();
  for (const p of products) {
    if (!productsMap.has(p.sku)) {
      productsMap.set(p.sku, p);
    } else {
      const existing = productsMap.get(p.sku);
      if (p.active && !existing.active) {
        productsMap.set(p.sku, p);
      } else if (p.active === existing.active && p.show_in_shop && !existing.show_in_shop) {
        productsMap.set(p.sku, p);
      }
    }
  }
  const displayedProducts = Array.from(productsMap.values());
  
  const printProduct = catalog?.printProduct;
  const allPrintVariants = catalog?.printVariants ?? [];
  const printVariants = allPrintVariants.filter(v => showArchived || v.active);
  const productPrices = catalog?.productPrices ?? [];
  
  const hasDuplicateMounts = allProducts.filter(p => p.type === 'mount').length > 2;

  const getPricesForProduct = (productId) => {
    return productPrices.filter(pp => pp.product_id === productId && (showArchived || pp.active));
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Product Management</h1>
            <p className="text-sm text-muted-foreground mt-1">Manage all shop products and pricing</p>
          </div>
          <div className="flex gap-2">
            <div className="flex items-center gap-2">
              <Switch checked={showArchived} onCheckedChange={setShowArchived} />
              <Label>Show Archived</Label>
            </div>
            <Button variant="outline" onClick={() => initCatalog.mutate()} disabled={initCatalog.isPending}>
              {initCatalog.isPending ? "Initializing..." : "Initialize / Repair Catalog"}
            </Button>
            <Button variant="outline" onClick={() => repairMounts.mutate()} disabled={repairMounts.isPending}>
              {repairMounts.isPending ? "Repairing..." : "Repair Mount Duplicates"}
            </Button>
            <Button onClick={() => setShowNewModal(true)}>
              <Plus className="w-4 h-4 mr-2" />
              New Product
            </Button>
          </div>
        </div>

        {!showArchived && hasDuplicateMounts && (
          <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-4">
            <p className="text-sm text-amber-900 dark:text-amber-100">
              ⚠️ Duplicates detected but archived. Turn on "Show Archived" to view or click "Repair Mount Duplicates" to clean up.
            </p>
          </div>
        )}

        {/* Print Variants Section */}
        {printProduct && (
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Metal Print Size Offerings</CardTitle>
                <Button onClick={() => {
                  const maxSort = printVariants.reduce((max, v) => Math.max(max, v.sort_order || 0), 0);
                  setNewSize({ 
                    ...newSize, 
                    sort_order: maxSort + 10 
                  });
                  setShowAddSizeModal(true);
                }}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Size
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {printVariants.map((v) => (
                <div key={v.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex justify-between items-center">
                    <div className="font-semibold">Size: {v.size}" {!v.active && <span className="text-xs text-muted-foreground">(Archived)</span>}</div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => setEditingVariant({ 
                        ...v, 
                        standard_price_dollars: (v.standard_price_cents || 0) / 100,
                        reserve_price_dollars: (v.reserve_price_cents || 0) / 100
                      })}>
                        Edit
                      </Button>
                      <Button size="sm" variant="destructive" onClick={() => {
                        if (confirm(`Archive size ${v.size}"? It will no longer appear to clients.`)) {
                          deleteVariant.mutate(v.id);
                        }
                      }} disabled={deleteVariant.isPending}>
                        Archive
                      </Button>
                    </div>
                  </div>
                  <div className="grid md:grid-cols-4 gap-3 text-sm">
                    <div>Standard: ${((v.standard_price_cents || 0) / 100).toFixed(2)}</div>
                    <div>Reserve: {v.reserve_enabled ? `$${((v.reserve_price_cents || 0) / 100).toFixed(2)}` : 'N/A'}</div>
                    <div>In Stock: {v.in_stock ? 'Yes' : 'No'}</div>
                    <div>Mode: {v.stock_mode}</div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Shop Products */}
        <Card>
          <CardHeader>
            <CardTitle>Shop Products</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {displayedProducts.map((p) => {
                const prices = getPricesForProduct(p.id);
                return (
                  <div key={p.id} className="border rounded-lg p-3">
                    <div
                      className="flex justify-between items-center cursor-pointer hover:bg-muted p-2 rounded"
                      onClick={() => setSelectedProduct(p)}
                    >
                      <div>
                        <div className="font-semibold">{p.name} {!p.active && <span className="text-xs text-muted-foreground">(Archived)</span>}</div>
                        <div className="text-xs text-muted-foreground">{p.sku} • {p.type}</div>
                      </div>
                      <div className="flex gap-2">
                        <span className={`text-xs px-2 py-1 rounded ${p.active ? "bg-green-100 text-green-800" : "bg-gray-100"}`}>
                          {p.active ? "Active" : "Inactive"}
                        </span>
                        <span className={`text-xs px-2 py-1 rounded ${p.in_stock ? "bg-blue-100 text-blue-800" : "bg-red-100 text-red-800"}`}>
                          {p.in_stock ? "In Stock" : "Out of Stock"}
                        </span>
                      </div>
                    </div>
                    
                    {p.type !== 'print' && (
                      <div className="mt-2 ml-4 space-y-1">
                        <div className="text-xs font-semibold text-muted-foreground">Pricing:</div>
                        {prices.length > 0 ? (
                          <>
                            {prices.map(pp => (
                              <div key={pp.id} className="text-xs flex justify-between items-center p-2 bg-muted rounded">
                                <div>
                                  <span className="font-medium">{pp.label || pp.sku}</span> - ${(pp.price_cents / 100).toFixed(2)}
                                  {!pp.active && <span className="ml-2 text-muted-foreground">(Archived)</span>}
                                </div>
                                <Button size="sm" variant="ghost" onClick={() => setEditingPrice({
                                  ...pp,
                                  price_dollars: pp.price_cents / 100
                                })}>
                                  Edit
                                </Button>
                              </div>
                            ))}
                            <Button size="sm" variant="outline" onClick={() => {
                              setEditingPrice({ product_id: p.id, price_dollars: 0, label: '', active: true, in_stock: true, stock_mode: 'HIDE' });
                              setShowNewPriceModal(true);
                            }}>
                              <Plus className="w-3 h-3 mr-1" /> Add Price Option
                            </Button>
                          </>
                        ) : (
                          <Button size="sm" variant="outline" onClick={() => {
                            setEditingPrice({ 
                              product_id: p.id, 
                              sku: p.sku + '-DEFAULT',
                              label: 'Default', 
                              price_dollars: 0, 
                              active: true, 
                              in_stock: true, 
                              stock_mode: 'HIDE' 
                            });
                            setShowNewPriceModal(true);
                          }}>
                            <Plus className="w-3 h-3 mr-1" /> Create Default Price
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Add Size Modal */}
      {showAddSizeModal && (
        <Dialog open={showAddSizeModal} onOpenChange={setShowAddSizeModal}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Size</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Size</Label>
                <div className="space-y-2">
                  <select
                    className="w-full border rounded-md p-2"
                    value={newSize.sizeType}
                    onChange={(e) => setNewSize({ ...newSize, sizeType: e.target.value, size: e.target.value === 'custom' ? newSize.customSize : '' })}
                  >
                    <option value="preset">Preset Size</option>
                    <option value="custom">Custom Size</option>
                  </select>
                  {newSize.sizeType === 'preset' ? (
                    <select
                      className="w-full border rounded-md p-2"
                      value={newSize.size}
                      onChange={(e) => setNewSize({ ...newSize, size: e.target.value })}
                    >
                      <option value="">Select a size...</option>
                      <option value="6x8">6x8</option>
                      <option value="8x10">8x10</option>
                      <option value="8x12">8x12</option>
                      <option value="8x16">8x16</option>
                      <option value="10x20">10x20</option>
                      <option value="11x14">11x14</option>
                      <option value="12x18">12x18</option>
                      <option value="16x24">16x24</option>
                      <option value="20x30">20x30</option>
                    </select>
                  ) : (
                    <Input
                      placeholder="Enter custom size (e.g., 5x7)"
                      value={newSize.customSize}
                      onChange={(e) => setNewSize({ ...newSize, customSize: e.target.value, size: e.target.value })}
                    />
                  )}
                </div>
                {printVariants.some(v => v.size === newSize.size) && newSize.size && (
                  <p className="text-xs text-red-600 mt-1">That size already exists.</p>
                )}
              </div>

              <div className="grid md:grid-cols-2 gap-3">
                <div>
                  <Label>Standard Price ($)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    value={newSize.standard_price_dollars}
                    onChange={(e) => setNewSize({ ...newSize, standard_price_dollars: Number(e.target.value) })}
                  />
                </div>
                <div>
                  <Label>Reserve Price ($)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    value={newSize.reserve_price_dollars}
                    onChange={(e) => setNewSize({ ...newSize, reserve_price_dollars: Number(e.target.value) })}
                    disabled={!newSize.reserve_enabled}
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-3">
                <div className="flex items-center gap-2">
                  <Switch
                    checked={newSize.reserve_enabled}
                    onCheckedChange={(c) => setNewSize({ ...newSize, reserve_enabled: c, show_reserve_upsell: c ? newSize.show_reserve_upsell : false })}
                  />
                  <Label>Reserve Enabled</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={newSize.show_reserve_upsell}
                    onCheckedChange={(c) => setNewSize({ ...newSize, show_reserve_upsell: c })}
                    disabled={!newSize.reserve_enabled}
                  />
                  <Label>Show Reserve Option</Label>
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-3">
                <div className="flex items-center gap-2">
                  <Switch
                    checked={newSize.active}
                    onCheckedChange={(c) => setNewSize({ ...newSize, active: c })}
                  />
                  <Label>Active</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={newSize.show_in_shop}
                    onCheckedChange={(c) => setNewSize({ ...newSize, show_in_shop: c })}
                  />
                  <Label>Show in Shop</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={newSize.in_stock}
                    onCheckedChange={(c) => setNewSize({ ...newSize, in_stock: c })}
                  />
                  <Label>In Stock</Label>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-3">
                <div>
                  <Label>Stock Mode</Label>
                  <select
                    className="w-full border rounded-md p-2"
                    value={newSize.stock_mode}
                    onChange={(e) => setNewSize({ ...newSize, stock_mode: e.target.value })}
                  >
                    <option value="HIDE">Hide</option>
                    <option value="DISABLE">Disable</option>
                  </select>
                </div>
                <div>
                  <Label>Sort Order</Label>
                  <Input
                    type="number"
                    value={newSize.sort_order}
                    onChange={(e) => setNewSize({ ...newSize, sort_order: Number(e.target.value) })}
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAddSizeModal(false)}>Cancel</Button>
              <Button 
                onClick={() => {
                  const finalSize = newSize.sizeType === 'custom' ? newSize.customSize : newSize.size;
                  if (!finalSize) {
                    alert('Please select or enter a size');
                    return;
                  }
                  if (printVariants.some(v => v.size === finalSize)) {
                    alert('That size already exists');
                    return;
                  }
                  if (newSize.standard_price_dollars <= 0) {
                    alert('Standard price must be greater than 0');
                    return;
                  }
                  if (newSize.reserve_enabled && newSize.reserve_price_dollars <= 0) {
                    alert('Reserve price must be greater than 0 when reserve is enabled');
                    return;
                  }
                  upsertVariant.mutate({
                    product_id: printProduct.id,
                    size: finalSize,
                    standard_price_dollars: newSize.standard_price_dollars,
                    reserve_enabled: newSize.reserve_enabled,
                    reserve_price_dollars: newSize.reserve_enabled ? newSize.reserve_price_dollars : null,
                    show_reserve_upsell: newSize.reserve_enabled ? newSize.show_reserve_upsell : false,
                    active: newSize.active,
                    show_in_shop: newSize.show_in_shop,
                    in_stock: newSize.in_stock,
                    stock_mode: newSize.stock_mode,
                    sort_order: newSize.sort_order
                  });
                }} 
                disabled={upsertVariant.isPending}
              >
                {upsertVariant.isPending ? "Creating..." : "Create Size"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Edit Variant Modal */}
      {editingVariant && (
        <Dialog open={!!editingVariant} onOpenChange={() => setEditingVariant(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Edit Size: {editingVariant.size}"</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid md:grid-cols-2 gap-3">
                <div>
                  <Label>Standard Price ($)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={editingVariant.standard_price_dollars}
                    onChange={(e) => setEditingVariant({ ...editingVariant, standard_price_dollars: Number(e.target.value) })}
                  />
                </div>
                <div>
                  <Label>Reserve Price ($)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={editingVariant.reserve_price_dollars}
                    onChange={(e) => setEditingVariant({ ...editingVariant, reserve_price_dollars: Number(e.target.value) })}
                    disabled={!editingVariant.reserve_enabled}
                  />
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-3">
                <div className="flex items-center gap-2">
                  <Switch
                    checked={editingVariant.reserve_enabled}
                    onCheckedChange={(c) => setEditingVariant({ ...editingVariant, reserve_enabled: c })}
                  />
                  <Label>Reserve Enabled</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={editingVariant.show_reserve_upsell}
                    onCheckedChange={(c) => setEditingVariant({ ...editingVariant, show_reserve_upsell: c })}
                    disabled={!editingVariant.reserve_enabled}
                  />
                  <Label>Show Reserve Option</Label>
                </div>
              </div>
              <div className="grid md:grid-cols-3 gap-3">
                <div className="flex items-center gap-2">
                  <Switch
                    checked={editingVariant.active}
                    onCheckedChange={(c) => setEditingVariant({ ...editingVariant, active: c })}
                  />
                  <Label>Active</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={editingVariant.in_stock}
                    onCheckedChange={(c) => setEditingVariant({ ...editingVariant, in_stock: c })}
                  />
                  <Label>In Stock</Label>
                </div>
                <div>
                  <Label>Stock Mode</Label>
                  <select
                    className="w-full border rounded-md p-2"
                    value={editingVariant.stock_mode}
                    onChange={(e) => setEditingVariant({ ...editingVariant, stock_mode: e.target.value })}
                  >
                    <option value="HIDE">Hide</option>
                    <option value="DISABLE">Disable</option>
                  </select>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditingVariant(null)}>Cancel</Button>
              <Button onClick={() => upsertVariant.mutate(editingVariant)} disabled={upsertVariant.isPending}>
                {upsertVariant.isPending ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Edit Price Modal */}
      {editingPrice && !showNewPriceModal && (
        <Dialog open={!!editingPrice} onOpenChange={() => setEditingPrice(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Price Option</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Label</Label>
                <Input
                  value={editingPrice.label || ''}
                  onChange={(e) => setEditingPrice({ ...editingPrice, label: e.target.value })}
                />
              </div>
              <div>
                <Label>Price ($)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={editingPrice.price_dollars}
                  onChange={(e) => setEditingPrice({ ...editingPrice, price_dollars: Number(e.target.value) })}
                />
              </div>
              <div className="grid md:grid-cols-2 gap-3">
                <div className="flex items-center gap-2">
                  <Switch
                    checked={editingPrice.in_stock}
                    onCheckedChange={(c) => setEditingPrice({ ...editingPrice, in_stock: c })}
                  />
                  <Label>In Stock</Label>
                </div>
                <div>
                  <Label>Stock Mode</Label>
                  <select
                    className="w-full border rounded-md p-2"
                    value={editingPrice.stock_mode}
                    onChange={(e) => setEditingPrice({ ...editingPrice, stock_mode: e.target.value })}
                  >
                    <option value="HIDE">Hide</option>
                    <option value="DISABLE">Disable</option>
                  </select>
                </div>
              </div>
            </div>
            <DialogFooter className="flex justify-between">
              <Button variant="destructive" onClick={() => {
                if (confirm('Archive this price option?')) {
                  archivePrice.mutate(editingPrice.id);
                  setEditingPrice(null);
                }
              }}>
                Archive
              </Button>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setEditingPrice(null)}>Cancel</Button>
                <Button onClick={() => upsertPrice.mutate(editingPrice)} disabled={upsertPrice.isPending}>
                  {upsertPrice.isPending ? "Saving..." : "Save"}
                </Button>
              </div>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* New Price Modal */}
      {showNewPriceModal && editingPrice && (
        <Dialog open={showNewPriceModal} onOpenChange={setShowNewPriceModal}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Price Option</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Label</Label>
                <Input
                  value={editingPrice.label || ''}
                  onChange={(e) => setEditingPrice({ ...editingPrice, label: e.target.value })}
                />
              </div>
              <div>
                <Label>Price ($)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={editingPrice.price_dollars}
                  onChange={(e) => setEditingPrice({ ...editingPrice, price_dollars: Number(e.target.value) })}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => {
                setShowNewPriceModal(false);
                setEditingPrice(null);
              }}>Cancel</Button>
              <Button onClick={() => upsertPrice.mutate(editingPrice)} disabled={upsertPrice.isPending}>
                {upsertPrice.isPending ? "Creating..." : "Create"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* New Product Modal */}
      <Dialog open={showNewModal} onOpenChange={setShowNewModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Product</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Product Type</Label>
              <select
                className="w-full border rounded-md p-2"
                value={newProductData.type}
                onChange={(e) => setNewProductData({ ...newProductData, type: e.target.value })}
              >
                <option value="accessory">Accessory</option>
                <option value="mount">Mount</option>
                <option value="service">Service</option>
              </select>
            </div>
            <div>
              <Label>Product Name</Label>
              <Input
                value={newProductData.name}
                onChange={(e) => setNewProductData({ ...newProductData, name: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNewModal(false)}>Cancel</Button>
            <Button onClick={() => createProduct.mutate(newProductData)} disabled={!newProductData.name}>
              Create
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Product Modal */}
      {selectedProduct && (
        <Dialog open={!!selectedProduct} onOpenChange={() => setSelectedProduct(null)}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit: {selectedProduct.name}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Name</Label>
                <Input
                  value={selectedProduct.name}
                  onChange={(e) => setSelectedProduct({ ...selectedProduct, name: e.target.value })}
                />
              </div>
              <div>
                <Label>Short Description</Label>
                <Input
                  value={selectedProduct.short_description ?? ""}
                  onChange={(e) => setSelectedProduct({ ...selectedProduct, short_description: e.target.value })}
                />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea
                  value={selectedProduct.description ?? ""}
                  onChange={(e) => setSelectedProduct({ ...selectedProduct, description: e.target.value })}
                  rows={3}
                />
              </div>
              <div>
                <Label>Image</Label>
                <div className="flex gap-2 items-center">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      if (e.target.files?.[0]) {
                        uploadImage(e.target.files[0], selectedProduct.id);
                      }
                    }}
                    disabled={uploadingImage}
                    className="text-sm"
                  />
                  {uploadingImage && <Loader2 className="w-4 h-4 animate-spin" />}
                </div>
              </div>
              {selectedProduct.type === 'service' && (
                <>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={selectedProduct.tiered_enabled ?? false}
                      onCheckedChange={(c) => setSelectedProduct({ ...selectedProduct, tiered_enabled: c })}
                    />
                    <Label>Tiered Pricing Enabled</Label>
                  </div>
                  {!selectedProduct.tiered_enabled && (
                    <div>
                      <Label>Flat Price ($)</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={selectedProduct.flat_price_cents ? (selectedProduct.flat_price_cents / 100) : 0}
                        onChange={(e) => setSelectedProduct({ 
                          ...selectedProduct, 
                          flat_price_cents: Math.round(Number(e.target.value) * 100) 
                        })}
                      />
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={selectedProduct.show_as_upsell ?? false}
                      onCheckedChange={(c) => setSelectedProduct({ ...selectedProduct, show_as_upsell: c })}
                    />
                    <Label>Show as Upsell</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={selectedProduct.upsell_for_prints ?? true}
                      onCheckedChange={(c) => setSelectedProduct({ ...selectedProduct, upsell_for_prints: c })}
                    />
                    <Label>Upsell for Prints</Label>
                  </div>
                </>
              )}

              <div className="grid md:grid-cols-2 gap-3">
                <div className="flex items-center gap-2">
                  <Switch
                    checked={selectedProduct.active}
                    onCheckedChange={(c) => setSelectedProduct({ ...selectedProduct, active: c })}
                  />
                  <Label>Active</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={selectedProduct.show_in_shop}
                    onCheckedChange={(c) => setSelectedProduct({ ...selectedProduct, show_in_shop: c })}
                  />
                  <Label>Show in Shop</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={selectedProduct.in_stock}
                    onCheckedChange={(c) => setSelectedProduct({ ...selectedProduct, in_stock: c })}
                    disabled={selectedProduct.type === "print"}
                  />
                  <Label>In Stock {selectedProduct.type === "print" && "(Always true for prints)"}</Label>
                </div>
              </div>
              <div>
                <Label>Stock Mode</Label>
                <select
                  className="w-full border rounded-md p-2"
                  value={selectedProduct.stock_mode ?? "HIDE"}
                  onChange={(e) => setSelectedProduct({ ...selectedProduct, stock_mode: e.target.value })}
                >
                  <option value="HIDE">Hide when unavailable</option>
                  <option value="DISABLE">Show as unavailable</option>
                </select>
              </div>
              <div>
                <Label>Shop Sort Order</Label>
                <Input
                  type="number"
                  value={selectedProduct.shop_sort_order ?? 0}
                  onChange={(e) => setSelectedProduct({ ...selectedProduct, shop_sort_order: Number(e.target.value) })}
                />
              </div>
            </div>
            <DialogFooter className="flex justify-between">
              <Button variant="destructive" onClick={() => {
                if (confirm(`Archive ${selectedProduct.name}? It will disappear from the shop.`)) {
                  deleteProduct.mutate(selectedProduct.id);
                }
              }} disabled={deleteProduct.isPending}>
                Archive Product
              </Button>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setSelectedProduct(null)}>Cancel</Button>
                <Button onClick={() => {
                  const { id, ...patch } = selectedProduct;
                  updateProduct.mutate({ id, patch });
                }}>
                  Save Changes
                </Button>
              </div>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </AdminLayout>
  );
}