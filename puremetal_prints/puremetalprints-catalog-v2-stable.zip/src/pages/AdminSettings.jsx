import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import AdminLayout from "@/components/admin/AdminLayout";

export default function AdminSettings() {
  const [user, setUser] = useState(null);
  const [brandName, setBrandName] = useState("PureMetal Prints");
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [smsNotifications, setSmsNotifications] = useState(false);

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      const me = await base44.auth.me();
      if (me.role !== "admin") { window.location.href = "/"; return; }
      setUser(me);
    })();
  }, []);

  if (!user) return null;

  return (
    <AdminLayout title="Settings">
      <div className="space-y-6 max-w-2xl">
        <Card>
          <CardHeader>
            <CardTitle>Branding</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Business Name</label>
              <Input
                value={brandName}
                onChange={(e) => setBrandName(e.target.value)}
                placeholder="PureMetal Prints"
              />
            </div>
            <Button>Save Branding</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Notifications</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Email Notifications</p>
                <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>
                  Receive email alerts for new orders and messages
                </p>
              </div>
              <Switch checked={emailNotifications} onCheckedChange={setEmailNotifications} />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">SMS Notifications</p>
                <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>
                  Receive text messages for urgent updates (if phone configured)
                </p>
              </div>
              <Switch checked={smsNotifications} onCheckedChange={setSmsNotifications} />
            </div>
            <Button>Save Notification Settings</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Integrations</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between p-3 rounded-lg border" style={{ borderColor: "var(--pm-border)" }}>
              <div>
                <p className="font-medium">Stripe</p>
                <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>Payment processing</p>
              </div>
              <span className="text-xs px-2 py-1 rounded-full bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400">
                Connected
              </span>
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg border" style={{ borderColor: "var(--pm-border)" }}>
              <div>
                <p className="font-medium">EasyPost</p>
                <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>Shipping rates (TODO: connect via dashboard)</p>
              </div>
              <span className="text-xs px-2 py-1 rounded-full bg-neutral-100 text-neutral-700 dark:bg-neutral-800 dark:text-neutral-300">
                Not Configured
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}