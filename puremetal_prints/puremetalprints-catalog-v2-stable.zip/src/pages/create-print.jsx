// Route alias: This file creates the /create-print route
// It re-exports the CreatePrint component
export { default } from './CreatePrint';