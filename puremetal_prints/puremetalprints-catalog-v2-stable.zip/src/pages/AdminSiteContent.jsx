import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import AdminLayout from "@/components/admin/AdminLayout";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";

export default function AdminSiteContent() {
  const qc = useQueryClient();
  const [contentState, setContentState] = useState({});

  const { data, isLoading } = useQuery({
    queryKey: ["site-content-admin"],
    queryFn: async () => {
      const resp = await base44.functions.invoke("getSiteContentAdmin", {});
      setContentState(resp.data.siteContent || {});
      return resp.data;
    },
  });

  const updateContent = useMutation({
    mutationFn: (updates) => base44.functions.invoke("updateSiteContentAdmin", updates),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["site-content-admin"] });
      alert("Content saved successfully");
    },
  });

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin" />
        </div>
      </AdminLayout>
    );
  }

  const handleSave = () => {
    updateContent.mutate({ siteContent: contentState });
  };

  return (
    <AdminLayout>
      <div className="space-y-6 max-w-4xl">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Site Content</h1>
            <p className="text-sm text-muted-foreground mt-1">Manage hero visuals, announcements, and text</p>
          </div>
          <Button onClick={handleSave} disabled={updateContent.isPending}>
            {updateContent.isPending ? "Saving..." : "Save Changes"}
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Text Content</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Hero Caption</Label>
              <Input
                value={contentState.hero_caption ?? ""}
                onChange={(e) => setContentState({ ...contentState, hero_caption: e.target.value })}
              />
            </div>
            <div>
              <Label>Gallery Helper Text</Label>
              <Textarea
                value={contentState.gallery_helper ?? ""}
                onChange={(e) => setContentState({ ...contentState, gallery_helper: e.target.value })}
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Hero Images</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Hero image management: {(data?.heroImages ?? []).length} images configured.
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              Detailed hero visual editor coming soon. For now, manage via Gallery admin.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Announcements</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Announcements: {(data?.announcements ?? []).length} configured.
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              Detailed announcement editor coming soon.
            </p>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}