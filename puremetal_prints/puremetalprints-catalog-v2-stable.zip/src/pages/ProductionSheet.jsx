import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Printer, Download } from "lucide-react";

export default function ProductionSheet() {
  const params = new URLSearchParams(window.location.search);
  const orderId = params.get("id");
  const [user, setUser] = useState(null);

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (auth) setUser(await base44.auth.me());
    })();
  }, []);

  const { data: order } = useQuery({
    queryKey: ["prod-order", orderId],
    queryFn: async () => { const all = await base44.entities.PMOrders.list(); return all.find(o => o.id === orderId); },
    enabled: !!orderId && !!user,
  });

  const { data: items = [] } = useQuery({
    queryKey: ["prod-items", orderId],
    queryFn: () => base44.entities.PMOrderItems.filter({ order_id: orderId }),
    enabled: !!orderId && !!user,
  });

  const { data: proofs = [] } = useQuery({
    queryKey: ["prod-proofs", orderId],
    queryFn: () => base44.entities.PMProofs.filter({ order_id: orderId }),
    enabled: !!orderId && !!user,
  });

  if (!order) return <div className="p-8 text-center">Loading...</div>;

  return (
    <div className="max-w-4xl mx-auto p-8">
      <div className="no-print flex justify-end gap-2 mb-6">
        <Button variant="outline" className="gap-2" onClick={() => window.print()}>
          <Printer className="w-4 h-4" /> Print
        </Button>
        <Button variant="outline" className="gap-2" onClick={() => window.print()}>
          <Download className="w-4 h-4" /> Download PDF
        </Button>
      </div>

      <div className="border rounded-xl p-8" style={{ borderColor: "#e5e5e5" }}>
        <div className="flex justify-between items-start mb-8 border-b pb-6" style={{ borderColor: "#e5e5e5" }}>
          <div>
            <h1 className="text-2xl font-bold">Production Sheet</h1>
            <p className="text-sm text-gray-500 mt-1">Order: {order.order_number}</p>
          </div>
          <div className="text-right text-sm text-gray-500">
            <p>Date: {new Date(order.created_date).toLocaleDateString()}</p>
            <p>Client: {order.client_name}</p>
            <p>{order.client_email}</p>
          </div>
        </div>

        {/* Shipping */}
        {order.shipping_address && (
          <div className="mb-6">
            <h3 className="text-sm font-semibold mb-2 uppercase text-gray-500">Ship To</h3>
            <p className="text-sm">{order.shipping_address.line1}</p>
            {order.shipping_address.line2 && <p className="text-sm">{order.shipping_address.line2}</p>}
            <p className="text-sm">{order.shipping_address.city}, {order.shipping_address.state} {order.shipping_address.zip}</p>
          </div>
        )}

        {/* Items table */}
        <table className="w-full text-sm mb-6">
          <thead>
            <tr className="border-b" style={{ borderColor: "#e5e5e5" }}>
              <th className="text-left py-2 font-semibold">Item</th>
              <th className="text-left py-2 font-semibold">Size</th>
              <th className="text-left py-2 font-semibold">Material</th>
              <th className="text-left py-2 font-semibold">Mount</th>
              <th className="text-center py-2 font-semibold">Qty</th>
              <th className="text-left py-2 font-semibold">Status</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <tr key={item.id} className="border-b" style={{ borderColor: "#f0f0f0" }}>
                <td className="py-3">{item.product_name}</td>
                <td className="py-3">{item.size}"</td>
                <td className="py-3">{item.material === "puremetalreserve" ? "PureMetal Reserve" : "Standard Aluminum"}</td>
                <td className="py-3">{item.mount_type}</td>
                <td className="py-3 text-center">{item.quantity}</td>
                <td className="py-3">{item.status}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Approved Proofs */}
        <div>
          <h3 className="text-sm font-semibold mb-3 uppercase text-gray-500">Approved Proofs / Files</h3>
          <div className="grid grid-cols-2 gap-4">
            {items.map(item => {
              const approvedProof = proofs.find(p => p.order_item_id === item.id && p.is_selected);
              return (
                <div key={item.id} className="border rounded-lg p-3" style={{ borderColor: "#e5e5e5" }}>
                  <p className="text-xs font-medium mb-2">{item.product_name}</p>
                  {approvedProof ? (
                    <div>
                      <img src={approvedProof.proof_url} alt="" className="w-full aspect-[4/3] object-contain bg-gray-50 rounded mb-2" />
                      <a href={approvedProof.master_url || approvedProof.proof_url} target="_blank" className="text-xs text-blue-600 underline no-print">
                        Download Master File
                      </a>
                    </div>
                  ) : (
                    <div>
                      {item.original_upload_url && (
                        <>
                          <img src={item.original_upload_url} alt="" className="w-full aspect-[4/3] object-contain bg-gray-50 rounded mb-2" />
                          <a href={item.original_upload_url} target="_blank" className="text-xs text-blue-600 underline no-print">Download Original</a>
                        </>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {order.notes && (
          <div className="mt-6 pt-4 border-t" style={{ borderColor: "#e5e5e5" }}>
            <h3 className="text-sm font-semibold mb-1">Notes</h3>
            <p className="text-sm text-gray-600">{order.notes}</p>
          </div>
        )}
      </div>
    </div>
  );
}