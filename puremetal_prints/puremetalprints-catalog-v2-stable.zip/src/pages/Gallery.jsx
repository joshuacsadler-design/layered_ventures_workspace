import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ImageIcon, Loader2 } from "lucide-react";
import { motion } from "framer-motion";

export default function Gallery() {
  const navigate = useNavigate();

  const { data, isLoading } = useQuery({
    queryKey: ["gallery-public"],
    queryFn: async () => (await base44.functions.invoke("getGalleryPublic", {})).data,
  });

  const { data: catalog } = useQuery({
    queryKey: ["catalog-public-gallery"],
    queryFn: async () => (await base44.functions.invoke("getCatalogPublic", {})).data,
  });

  const items = data?.items ?? [];

  const computeStandardPrice = (configured_size, configured_tier) => {
    const variant = catalog?.printVariants?.find(v => v.size === configured_size);
    if (!variant) return null;
    return configured_tier === "reserve" ? variant.reserve_price : variant.standard_price;
  };

  const computeGalleryPrice = (standardPrice, discount_pct) => {
    if (!standardPrice) return null;
    const discounted = standardPrice * (1 - (discount_pct / 100));
    return discounted;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">Gallery</h1>
        <p className="text-lg text-muted-foreground">Featured prints with exclusive gallery pricing (15% off).</p>
      </div>

      {items.length === 0 ? (
        <div className="text-center py-20 rounded-2xl border">
          <ImageIcon className="w-16 h-16 mx-auto mb-4 opacity-20" />
          <p className="text-xl font-medium">Gallery Coming Soon</p>
          <p className="text-sm mt-2 text-muted-foreground">We're curating stunning prints for inspiration.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map((item, i) => {
            const standardPrice = computeStandardPrice(item.configured_size, item.configured_tier);
            const galleryPrice = computeGalleryPrice(standardPrice, item.gallery_discount_pct);

            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05, duration: 0.4 }}
                className="rounded-2xl border overflow-hidden hover:shadow-xl transition-all"
              >
                <div className="aspect-square bg-neutral-100 dark:bg-neutral-800">
                  <img src={`/api/files/${item.file_id}`} alt={item.title} className="w-full h-full object-cover" />
                </div>
                <div className="p-5">
                  <h3 className="font-semibold text-lg mb-3">{item.title}</h3>
                  <div className="mb-4 text-sm text-muted-foreground">
                    {item.configured_size}" • {item.configured_tier === "reserve" ? "Reserve" : "Standard"}
                  </div>
                  {galleryPrice && (
                    <div className="mb-4">
                      <div className="text-xs text-muted-foreground line-through">${standardPrice.toFixed(2)}</div>
                      <div className="text-2xl font-bold text-emerald-600">
                        ${galleryPrice.toFixed(2)}
                        <span className="text-sm font-normal text-muted-foreground ml-2">Gallery Price</span>
                      </div>
                    </div>
                  )}
                  <Button
                    className="w-full"
                    onClick={() => navigate(`/create-print?fromGallery=1&galleryId=${item.id}`)}
                  >
                    Start Creating
                  </Button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}