import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { createPageUrl } from "@/utils";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Edit2, Trash2 } from "lucide-react";
import AdminLayout from "@/components/admin/AdminLayout";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function AdminProducts() {
  const [user, setUser] = useState(null);
  const [editingProduct, setEditingProduct] = useState(null);
  const [editingPrice, setEditingPrice] = useState(null);
  const [showDialog, setShowDialog] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      const me = await base44.auth.me();
      if (me.role !== "admin") { window.location.href = "/"; return; }
      setUser(me);
    })();
  }, []);

  const { data: products = [] } = useQuery({
    queryKey: ["admin-products"],
    queryFn: () => base44.entities.Product.list(),
    enabled: !!user,
  });

  const { data: prices = [] } = useQuery({
    queryKey: ["admin-prices"],
    queryFn: () => base44.entities.ProductPrice.list(),
    enabled: !!user,
  });

  const saveProductMutation = useMutation({
    mutationFn: async (data) => {
      if (editingProduct?.id) {
        await base44.entities.Product.update(editingProduct.id, data);
      } else {
        await base44.entities.Product.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-products"]);
      setShowDialog(false);
      setEditingProduct(null);
    },
  });

  const savePriceMutation = useMutation({
    mutationFn: async (data) => {
      if (editingPrice?.id) {
        await base44.entities.ProductPrice.update(editingPrice.id, data);
      } else {
        await base44.entities.ProductPrice.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-prices"]);
      setEditingPrice(null);
    },
  });

  const deleteProductMutation = useMutation({
    mutationFn: (id) => base44.entities.Product.delete(id),
    onSuccess: () => queryClient.invalidateQueries(["admin-products"]),
  });

  const getProductPrices = (productId) => {
    return prices.filter((p) => p.product === productId);
  };

  const handleSaveProduct = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    saveProductMutation.mutate({
      name: formData.get("name"),
      sku: formData.get("sku"),
      type: formData.get("type"),
      description: formData.get("description"),
      active: true,
    });
  };

  const materialLabels = {
    standard: "Standard Aluminum",
    puremetalreserve: "PureMetal Reserve",
  };

  if (!user) return null;

  return (
    <AdminLayout 
      title="Products & Pricing"
      actions={
        <Button onClick={() => { setEditingProduct({}); setShowDialog(true); }}>
          <Plus className="w-4 h-4 mr-2" /> Add Product
        </Button>
      }
    >
      <div className="space-y-6">
        {products.map((product) => (
          <Card key={product.id}>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>{product.name}</CardTitle>
                <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>
                  SKU: {product.sku} · Type: {product.type}
                </p>
              </div>
              <div className="flex gap-2">
                <Button variant="ghost" size="sm" onClick={() => { setEditingProduct(product); setShowDialog(true); }}>
                  <Edit2 className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="sm" onClick={() => deleteProductMutation.mutate(product.id)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <p className="text-sm font-medium mb-2">Prices</p>
                {getProductPrices(product.id).map((price) => (
                  <div
                    key={price.id}
                    className="flex items-center justify-between p-3 rounded-lg border"
                    style={{ borderColor: "var(--pm-border)" }}
                  >
                    <div>
                      <p className="text-sm font-medium">{price.variant_key}</p>
                      <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>
                        {price.size && `Size: ${price.size}`} 
                        {price.material && ` · ${materialLabels[price.material] || price.material}`}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-semibold">${price.price.toFixed(2)}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setEditingPrice(price)}
                      >
                        <Edit2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setEditingPrice({ product: product.id })}
                >
                  <Plus className="w-3 h-3 mr-1" /> Add Price Variant
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}

        {products.length === 0 && (
          <p className="text-center py-12 text-sm" style={{ color: "var(--pm-text-muted)" }}>
            No products yet. Add your first product.
          </p>
        )}
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingProduct?.id ? "Edit Product" : "New Product"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSaveProduct} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Name</label>
              <Input name="name" defaultValue={editingProduct?.name} required />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">SKU</label>
              <Input name="sku" defaultValue={editingProduct?.sku} required />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Type</label>
              <Select name="type" defaultValue={editingProduct?.type || "print"}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="print">Print</SelectItem>
                  <SelectItem value="accessory">Accessory</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Description</label>
              <Input name="description" defaultValue={editingProduct?.description} />
            </div>
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                Cancel
              </Button>
              <Button type="submit">Save</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {editingPrice && (
        <Dialog open={!!editingPrice} onOpenChange={() => setEditingPrice(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingPrice.id ? "Edit Price" : "New Price"}</DialogTitle>
            </DialogHeader>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                savePriceMutation.mutate({
                  product: editingPrice.product,
                  variant_key: formData.get("variant_key"),
                  size: formData.get("size") || null,
                  material: formData.get("material") || null,
                  price: parseFloat(formData.get("price")),
                  active: true,
                });
              }}
              className="space-y-4"
            >
              <div>
                <label className="block text-sm font-medium mb-1">Variant Key</label>
                <Input name="variant_key" defaultValue={editingPrice.variant_key} placeholder="e.g. 8x10-standard" required />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Size (optional)</label>
                <Input name="size" defaultValue={editingPrice.size} placeholder="e.g. 8x10" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Material (optional)</label>
                <Select name="material" defaultValue={editingPrice.material}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select material" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="standard">Standard Aluminum</SelectItem>
                    <SelectItem value="puremetalreserve">PureMetal Reserve</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Price</label>
                <Input name="price" type="number" step="0.01" defaultValue={editingPrice.price} required />
              </div>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setEditingPrice(null)}>
                  Cancel
                </Button>
                <Button type="submit">Save</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </AdminLayout>
  );
}