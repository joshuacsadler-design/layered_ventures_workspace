import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Input } from "@/components/ui/input";
import { Search, User, ChevronRight } from "lucide-react";
import AdminLayout from "@/components/admin/AdminLayout";

export default function AdminClients() {
  const [user, setUser] = useState(null);
  const [search, setSearch] = useState("");

  useEffect(() => {
    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      const me = await base44.auth.me();
      if (me.role !== "admin") { window.location.href = "/"; return; }
      setUser(me);
    })();
  }, []);

  const { data: clients = [] } = useQuery({
    queryKey: ["admin-clients"],
    queryFn: () => base44.entities.Client.list(),
    enabled: !!user,
  });

  const { data: orders = [] } = useQuery({
    queryKey: ["admin-orders-for-clients"],
    queryFn: () => base44.entities.Order.list(),
    enabled: !!user,
  });

  const getClientOrderCount = (clientId) => {
    return orders.filter(o => o.client === clientId && o.status !== "Draft").length;
  };

  const getLastOrderDate = (clientId) => {
    const clientOrders = orders
      .filter(o => o.client === clientId && o.status !== "Draft")
      .sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    return clientOrders[0] ? new Date(clientOrders[0].created_date).toLocaleDateString() : "—";
  };

  const filtered = clients.filter(
    (c) =>
      !search ||
      c.full_name?.toLowerCase().includes(search.toLowerCase()) ||
      c.email?.toLowerCase().includes(search.toLowerCase())
  );

  if (!user) return null;

  return (
    <AdminLayout title="Clients">
      <div className="space-y-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 opacity-40" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search clients by name or email..."
            className="pl-9"
          />
        </div>

        <div className="space-y-2">
          {filtered.map((client) => (
            <Link
              key={client.id}
              to={createPageUrl(`AdminClientDetail?id=${client.id}`)}
              className="flex items-center justify-between p-4 rounded-xl border transition-all hover:shadow-md"
              style={{ borderColor: "var(--pm-border)", backgroundColor: "var(--pm-surface)" }}
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center">
                  <User className="w-5 h-5 opacity-40" />
                </div>
                <div>
                  <p className="font-semibold">{client.full_name}</p>
                  <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>
                    {client.email}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="text-right">
                  <p className="text-sm font-medium">{getClientOrderCount(client.id)} orders</p>
                  <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>
                    Last: {getLastOrderDate(client.id)}
                  </p>
                </div>
                <ChevronRight className="w-4 h-4 opacity-30" />
              </div>
            </Link>
          ))}
          {filtered.length === 0 && (
            <p className="text-center py-12 text-sm" style={{ color: "var(--pm-text-muted)" }}>
              No clients found.
            </p>
          )}
        </div>
      </div>
    </AdminLayout>
  );
}