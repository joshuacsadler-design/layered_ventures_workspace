import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, Send, Check, Loader2, FileText, PlayCircle, CheckCircle, Star, Plus, XCircle, DollarSign, AlertCircle } from "lucide-react";
import PMBadge from "@/components/ui/PMBadge";
import AdminLayout from "@/components/admin/AdminLayout";

export default function AdminOrderDetail() {
  const [user, setUser] = useState(null);
  const [orderId, setOrderId] = useState(null);
  const [uploadingProof, setUploadingProof] = useState(false);
  const [uploadingPrintReady, setUploadingPrintReady] = useState(false);
  const [proofNotes, setProofNotes] = useState("");
  const [showPrintLog, setShowPrintLog] = useState({});
  const [printLogNotes, setPrintLogNotes] = useState("");
  const [printLogRating, setPrintLogRating] = useState(3);
  const queryClient = useQueryClient();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const id = params.get("id");
    setOrderId(id);

    (async () => {
      const auth = await base44.auth.isAuthenticated();
      if (!auth) { base44.auth.redirectToLogin(); return; }
      const me = await base44.auth.me();
      if (me.role !== "admin") { window.location.href = "/"; return; }
      setUser(me);
    })();
  }, []);

  const { data: order } = useQuery({
    queryKey: ["admin-order", orderId],
    queryFn: async () => {
      const orders = await base44.entities.Order.filter({ id: orderId });
      return orders[0];
    },
    enabled: !!orderId && !!user,
  });

  const { data: orderItems = [] } = useQuery({
    queryKey: ["admin-order-items", orderId],
    queryFn: () => base44.entities.OrderItem.filter({ order_id: orderId }),
    enabled: !!orderId && !!user,
  });

  const { data: client } = useQuery({
    queryKey: ["admin-client", order?.client_id],
    queryFn: async () => {
      const clients = await base44.entities.Client.filter({ id: order.client_id });
      return clients[0];
    },
    enabled: !!order?.client_id && !!user,
  });

  const { data: proofs = [] } = useQuery({
    queryKey: ["admin-proofs", orderId],
    queryFn: async () => {
      const allProofs = await base44.entities.Proof.filter({});
      return allProofs.filter(p => orderItems.some(item => item.id === p.order_item_id));
    },
    enabled: orderItems.length > 0 && !!user,
  });

  const { data: files = [] } = useQuery({
    queryKey: ["admin-files", orderId],
    queryFn: async () => {
      const allFiles = await base44.entities.File.filter({});
      return allFiles.filter(f => orderItems.some(item => item.id === f.order_item_id));
    },
    enabled: orderItems.length > 0 && !!user,
  });

  const { data: printLogs = [] } = useQuery({
    queryKey: ["admin-print-logs", orderId],
    queryFn: async () => {
      const allLogs = await base44.entities.PrintLog.filter({});
      return allLogs.filter(log => orderItems.some(item => item.id === log.order_item));
    },
    enabled: orderItems.length > 0 && !!user,
  });

  const { data: printLogPhotos = [] } = useQuery({
    queryKey: ["admin-print-log-photos", orderId],
    queryFn: () => base44.entities.PrintLogPhoto.list(),
    enabled: printLogs.length > 0 && !!user,
  });

  const { data: cancellationRequest } = useQuery({
    queryKey: ["admin-cancellation-request", orderId],
    queryFn: async () => {
      const requests = await base44.asServiceRole.entities.CancellationRequest.filter({ order_id: orderId, status: 'PENDING' });
      return requests[0];
    },
    enabled: !!orderId && !!user,
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ newStatus }) => {
      await base44.functions.invoke('updateOrderStatus', { orderId, newStatus });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-order", orderId]);
      queryClient.invalidateQueries(["admin-order-items", orderId]);
    },
    onError: (error) => {
      const errorData = error.response?.data || error;
      if (errorData.violations) {
        alert('Production Start Failed:\n\n' + errorData.violations.join('\n'));
      } else {
        alert('Error: ' + (errorData.error || error.message));
      }
    },
  });

  const uploadProofMutation = useMutation({
    mutationFn: async ({ file, itemId }) => {
      setUploadingProof(true);
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      const proofFile = await base44.asServiceRole.entities.File.create({
        order_item_id: itemId,
        kind: 'ADMIN_PROOF',
        file_url: file_url,
        filename: file.name,
        source_file_id: null,
        is_delivered_to_client: false,
        metadata: {},
      });

      await base44.asServiceRole.entities.Proof.create({
        order_item_id: itemId,
        file_id: proofFile.id,
        is_delivered: false,
        is_selected: false,
        admin_notes: proofNotes,
      });

      setUploadingProof(false);
      setProofNotes("");
    },
    onSuccess: () => queryClient.invalidateQueries(["admin-proofs", orderId]),
  });

  const deliverProofMutation = useMutation({
    mutationFn: async (proofId) => {
      await base44.functions.invoke('deliverProof', { proofId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-proofs", orderId]);
      queryClient.invalidateQueries(["admin-order", orderId]);
    },
  });

  const handleUploadProof = (e, itemId) => {
    const file = e.target.files?.[0];
    if (file) uploadProofMutation.mutate({ file, itemId });
  };

  const uploadPrintReadyMutation = useMutation({
    mutationFn: async ({ file, itemId }) => {
      setUploadingPrintReady(true);
      const formData = new FormData();
      formData.append('file', file);
      formData.append('orderItemId', itemId);
      
      await base44.functions.invoke('uploadPrintReady', formData);
      setUploadingPrintReady(false);
    },
    onSuccess: () => queryClient.invalidateQueries(["admin-files", orderId]),
  });

  const updateItemStatusMutation = useMutation({
    mutationFn: async ({ itemId, newStatus }) => {
      await base44.functions.invoke('updateItemStatus', { itemId, newStatus });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-order-items", orderId]);
      queryClient.invalidateQueries(["admin-order", orderId]);
    },
  });

  const addPrintLogMutation = useMutation({
    mutationFn: async ({ orderItemId, notes, rating }) => {
      await base44.functions.invoke('addPrintLog', { orderItemId, notes, rating });
      setPrintLogNotes("");
      setPrintLogRating(3);
      setShowPrintLog({ ...showPrintLog, [orderItemId]: false });
    },
    onSuccess: () => queryClient.invalidateQueries(["admin-print-logs", orderId]),
  });

  const handleUploadPrintReady = (e, itemId) => {
    const file = e.target.files?.[0];
    if (file) uploadPrintReadyMutation.mutate({ file, itemId });
  };

  if (!user || !order) return <div className="flex items-center justify-center min-h-screen"><Loader2 className="w-8 h-8 animate-spin" /></div>;

  const STATUS_VARIANTS = {
    DRAFT: "default", UPLOADED: "purple", NEEDS_REVIEW: "warning", 
    PROOF_DELIVERED: "purple", PROOF_SELECTED: "success", APPROVED: "gold",
    IN_PRODUCTION: "purple", COMPLETED: "success", CANCELLATION_REQUESTED: "error", CANCELLED: "error",
  };

  return (
    <AdminLayout 
      title={`Order ${order.order_number}`} 
      showBack 
      actions={
        <div className="flex items-center gap-3">
          {order.status === 'APPROVED' && (
            <Button
              onClick={() => updateStatusMutation.mutate({ newStatus: 'IN_PRODUCTION' })}
              disabled={updateStatusMutation.isPending}
              className="gap-2"
            >
              <PlayCircle className="w-4 h-4" />
              Start Production
            </Button>
          )}
          <Select value={order.status} onValueChange={(newStatus) => updateStatusMutation.mutate({ newStatus })}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="NEEDS_REVIEW">Needs Review</SelectItem>
              <SelectItem value="PROOF_DELIVERED">Proof Delivered</SelectItem>
              <SelectItem value="APPROVED">Approved</SelectItem>
              <SelectItem value="IN_PRODUCTION">In Production</SelectItem>
              <SelectItem value="COMPLETED">Completed</SelectItem>
            </SelectContent>
          </Select>
        </div>
      }
    >
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Order Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm" style={{ color: "var(--pm-text-muted)" }}>Status</span>
              <PMBadge variant={STATUS_VARIANTS[order.status]}>{order.status.replace(/_/g, ' ')}</PMBadge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm" style={{ color: "var(--pm-text-muted)" }}>Total</span>
              <span className="font-semibold">${(order.total || 0).toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm" style={{ color: "var(--pm-text-muted)" }}>Created</span>
              <span className="text-sm">{new Date(order.created_date).toLocaleString()}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Client Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div><span className="text-sm font-medium">Name:</span> {client?.full_name}</div>
            <div><span className="text-sm font-medium">Email:</span> {client?.email}</div>
            <div><span className="text-sm font-medium">Phone:</span> {client?.phone || "—"}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Order Items & Proofing</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {orderItems.map((item) => {
                const itemProofs = proofs.filter(p => p.order_item_id === item.id);
                const itemFiles = files.filter(f => f.order_item_id === item.id);
                const originalFile = itemFiles.find(f => f.kind === 'CLIENT_ORIGINAL');
                const printReadyFile = itemFiles.find(f => f.kind === 'PRINT_READY');
                const itemLogs = printLogs.filter(log => log.order_item === item.id);
                const hasSelectedProof = itemProofs.some(p => p.is_selected);
                const productionGateMet = item.status === 'APPROVED' && hasSelectedProof && printReadyFile;
                
                return (
                  <div key={item.id} className="rounded-lg border p-4" style={{ borderColor: "var(--pm-border)" }}>
                    <div className="flex items-start justify-between gap-4 mb-4">
                    <div className="flex-1">
                      <p className="font-medium">{item.title}</p>
                      <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>
                        {item.size} · {item.material} · Qty: {item.quantity}
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        <PMBadge variant={STATUS_VARIANTS[item.status]}>
                          {item.status.replace(/_/g, ' ')}
                        </PMBadge>
                        {item.cancellation_locked && (
                          <PMBadge variant="error" className="text-xs">🔒 Locked</PMBadge>
                        )}
                      </div>

                      {item.status === 'APPROVED' && (
                        <div className="flex items-center gap-2 mt-2 text-xs">
                          <div className={`flex items-center gap-1 ${hasSelectedProof ? 'text-green-600' : 'text-red-600'}`}>
                            {hasSelectedProof ? <CheckCircle className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                            Selected Proof
                          </div>
                          <div className={`flex items-center gap-1 ${printReadyFile ? 'text-green-600' : 'text-red-600'}`}>
                            {printReadyFile ? <CheckCircle className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                            Print-Ready File
                          </div>
                        </div>
                      )}
                    </div>
                      <div className="flex flex-col gap-2">
                        {item.status === 'APPROVED' && (
                          <Button 
                            size="sm" 
                            onClick={() => updateItemStatusMutation.mutate({ itemId: item.id, newStatus: 'IN_PRODUCTION' })} 
                            disabled={!productionGateMet}
                            className="gap-1"
                            title={!productionGateMet ? 'Requires selected proof and print-ready file' : 'Start production for this item'}
                          >
                            <PlayCircle className="w-4 h-4" /> Start Production
                          </Button>
                        )}
                        {item.status === 'IN_PRODUCTION' && (
                          <Button size="sm" variant="outline" onClick={() => updateItemStatusMutation.mutate({ itemId: item.id, newStatus: 'COMPLETED' })} className="gap-1">
                            <CheckCircle className="w-4 h-4" /> Mark Completed
                          </Button>
                        )}
                      </div>
                    </div>

                    {originalFile && (
                      <div className="mb-4 p-3 rounded bg-neutral-50 dark:bg-neutral-800">
                        <p className="text-xs font-medium mb-1">Client Original</p>
                        <a href={originalFile.file_url} target="_blank" className="text-sm text-blue-600 hover:underline flex items-center gap-1">
                          <FileText className="w-3 h-3" /> {originalFile.filename}
                        </a>
                      </div>
                    )}

                    <div className="mb-4">
                      <div className="flex items-center gap-2 mb-2">
                        <label className="cursor-pointer">
                          <Button variant="outline" size="sm" disabled={uploadingProof} asChild>
                            <span><Upload className="w-4 h-4 mr-1" /> Upload Proof</span>
                          </Button>
                          <input type="file" accept="image/*" className="hidden" onChange={(e) => handleUploadProof(e, item.id)} />
                        </label>
                      </div>
                      <Input
                        placeholder="Notes for client (optional)"
                        value={proofNotes}
                        onChange={(e) => setProofNotes(e.target.value)}
                        className="text-sm"
                      />
                    </div>

                    <div className="space-y-2 mb-4">
                      <p className="text-xs font-medium">Proofs:</p>
                      {itemProofs.map((proof) => (
                        <div key={proof.id} className="flex items-center gap-3 p-2 rounded border" style={{ borderColor: "var(--pm-border)" }}>
                          <div className="flex-1">
                            <p className="text-sm">Proof #{proof.id.slice(-6)}</p>
                            <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>{proof.admin_notes}</p>
                          </div>
                          {proof.is_delivered ? (
                            <PMBadge variant="success">Delivered</PMBadge>
                          ) : (
                            <Button size="sm" onClick={() => deliverProofMutation.mutate(proof.id)}>
                              <Send className="w-3 h-3 mr-1" /> Deliver
                            </Button>
                          )}
                          {proof.is_selected && <PMBadge variant="gold">Selected by Client</PMBadge>}
                        </div>
                      ))}
                      {itemProofs.length === 0 && (
                        <p className="text-xs text-center py-2" style={{ color: "var(--pm-text-muted)" }}>No proofs yet</p>
                      )}
                    </div>

                    <div className="mb-4 p-3 rounded bg-blue-50 dark:bg-blue-900/20 border" style={{ borderColor: "var(--pm-border)" }}>
                      <div className="flex items-center justify-between mb-2">
                        <p className="text-xs font-medium">Print Ready File:</p>
                        {!printReadyFile && (
                          <label className="cursor-pointer">
                            <Button 
                              variant="outline" 
                              size="sm" 
                              disabled={uploadingPrintReady || item.status !== 'APPROVED' || !hasSelectedProof} 
                              asChild
                              title={item.status !== 'APPROVED' ? 'Item must be approved' : !hasSelectedProof ? 'Item must have selected proof' : 'Upload print-ready file'}
                            >
                              <span><Upload className="w-3 h-3 mr-1" /> Upload</span>
                            </Button>
                            <input type="file" accept="image/*" className="hidden" onChange={(e) => handleUploadPrintReady(e, item.id)} />
                          </label>
                        )}
                      </div>
                      {printReadyFile ? (
                        <div>
                          <a href={printReadyFile.file_url} target="_blank" className="text-sm text-blue-600 hover:underline flex items-center gap-1">
                            <CheckCircle className="w-3 h-3 text-green-600" /> {printReadyFile.filename}
                          </a>
                          <p className="text-xs mt-1" style={{ color: "var(--pm-text-muted)" }}>
                            Uploaded {new Date(printReadyFile.created_date).toLocaleDateString()}
                          </p>
                        </div>
                      ) : (
                        <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>
                          {item.status !== 'APPROVED' ? 'Approve item first' : !hasSelectedProof ? 'Client must select proof first' : 'No print-ready file yet'}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-medium">Print Logs:</p>
                        <Button variant="ghost" size="sm" onClick={() => setShowPrintLog({ ...showPrintLog, [item.id]: !showPrintLog[item.id] })} className="gap-1">
                          <Plus className="w-3 h-3" /> Add Log
                        </Button>
                      </div>
                      
                      {showPrintLog[item.id] && (
                        <div className="p-3 rounded border space-y-2" style={{ borderColor: "var(--pm-border)" }}>
                          <Textarea
                            placeholder="Print notes..."
                            value={printLogNotes}
                            onChange={(e) => setPrintLogNotes(e.target.value)}
                            rows={2}
                          />
                          <div className="flex items-center gap-2">
                            <span className="text-xs">Rating:</span>
                            {[1, 2, 3, 4, 5].map((r) => (
                              <Star
                                key={r}
                                className={`w-4 h-4 cursor-pointer ${r <= printLogRating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`}
                                onClick={() => setPrintLogRating(r)}
                              />
                            ))}
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" onClick={() => addPrintLogMutation.mutate({ orderItemId: item.id, notes: printLogNotes, rating: printLogRating })}>
                              Save Log
                            </Button>
                            <Button size="sm" variant="ghost" onClick={() => setShowPrintLog({ ...showPrintLog, [item.id]: false })}>
                              Cancel
                            </Button>
                          </div>
                        </div>
                      )}

                      {itemLogs.map((log) => (
                        <div key={log.id} className="p-2 rounded border text-xs" style={{ borderColor: "var(--pm-border)" }}>
                          <div className="flex items-center gap-2 mb-1">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} className={`w-3 h-3 ${i < (log.rating || 0) ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`} />
                            ))}
                            <span style={{ color: "var(--pm-text-muted)" }}>· {new Date(log.created_date).toLocaleDateString()}</span>
                          </div>
                          <p>{log.result_notes}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {cancellationRequest && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-600">
                <AlertCircle className="w-5 h-5" />
                Cancellation Request Pending
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <p className="text-sm font-medium mb-1">Reason:</p>
                  <p className="text-sm">{cancellationRequest.reason}</p>
                </div>
                {cancellationRequest.prep_fee_applies && (
                  <PMBadge variant="warning" className="flex items-center gap-1">
                    <DollarSign className="w-3 h-3" /> $15 Prep Fee Will Apply
                  </PMBadge>
                )}
                <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>
                  Requested {new Date(cancellationRequest.created_date).toLocaleString()}
                </p>
                <p className="text-xs" style={{ color: "var(--pm-text-muted)" }}>
                  Handle this request in the Cancellations admin page.
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </AdminLayout>
  );
}