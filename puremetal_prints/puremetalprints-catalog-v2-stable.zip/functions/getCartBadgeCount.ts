import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ count: 0 });
    }

    // Find user's draft order
    const draftOrders = await base44.entities.Order.filter({ 
      user_id: user.id,
      status: 'DRAFT'
    });

    if (draftOrders.length === 0) {
      return Response.json({ count: 0 });
    }

    // Get items for the draft order
    const items = await base44.entities.OrderItem.filter({ 
      order_id: draftOrders[0].id 
    });

    // Sum quantities
    const total = items.reduce((sum, item) => sum + (item.quantity || 1), 0);

    return Response.json({ count: total });
  } catch (error) {
    return Response.json({ count: 0 });
  }
});