import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    // Get last 50 order items (newest first)
    const items = await base44.asServiceRole.entities.OrderItem.list('-created_date', 50);
    
    // Get associated orders for client info
    const orderIds = [...new Set(items.map(i => i.order_id))];
    const orders = await base44.asServiceRole.entities.Order.filter({ 
      id: { $in: orderIds } 
    });
    
    // Get users for client display
    const userIds = [...new Set(orders.map(o => o.user_id).filter(Boolean))];
    const users = await base44.asServiceRole.entities.User.filter({ 
      id: { $in: userIds } 
    });
    
    // Get latest jobs and results
    const jobIds = items.map(i => i.last_analysis_job_id).filter(Boolean);
    const resultIds = items.map(i => i.last_analysis_result_id).filter(Boolean);
    
    const jobs = jobIds.length > 0 
      ? await base44.asServiceRole.entities.AIAnalysisJob.filter({ id: { $in: jobIds } })
      : [];
    
    const results = resultIds.length > 0
      ? await base44.asServiceRole.entities.AIAnalysisResult.filter({ id: { $in: resultIds } })
      : [];
    
    // Build enriched items
    const enrichedItems = items.map(item => {
      const order = orders.find(o => o.id === item.order_id);
      const user = users.find(u => u.id === order?.user_id);
      const job = jobs.find(j => j.id === item.last_analysis_job_id);
      const result = results.find(r => r.id === item.last_analysis_result_id);
      
      return {
        ...item,
        client_email: user?.email || order?.client_id || 'Unknown',
        client_name: user?.full_name || '',
        latest_job: job || null,
        latest_result: result || null
      };
    });

    return Response.json({ 
      items: enrichedItems,
      total: enrichedItems.length 
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});