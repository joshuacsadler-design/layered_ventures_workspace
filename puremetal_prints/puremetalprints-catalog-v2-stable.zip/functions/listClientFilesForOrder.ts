import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Authentication required' }, { status: 401 });
    }

    const { orderId } = await req.json();
    if (!orderId) {
      return Response.json({ error: 'orderId required' }, { status: 400 });
    }

    // Verify order ownership
    const orders = await base44.entities.Order.filter({ id: orderId, user_id: user.id });
    if (orders.length === 0) {
      return Response.json({ error: 'Order not found or access denied' }, { status: 403 });
    }

    // Get order items for this order
    const orderItems = await base44.entities.OrderItem.filter({ order_id: orderId });
    const itemIds = orderItems.map(item => item.id);

    // Fetch all files for these items
    const allFiles = await base44.asServiceRole.entities.File.filter({
      order_item_id: { $in: itemIds }
    });

    // Filter to only allowed file types for clients
    const allowedFiles = allFiles.filter(file => {
      // Allow CLIENT_ORIGINAL (their own uploads)
      if (file.kind === 'CLIENT_ORIGINAL') return true;
      
      // Allow ADMIN_PROOF only if delivered to client
      if (file.kind === 'ADMIN_PROOF' && file.is_delivered_to_client) return true;
      
      // Block all other types (PRINT_READY, ANALYZER_WORKING_COPY, etc.)
      return false;
    });

    return Response.json({ files: allowedFiles });
  } catch (error) {
    console.error('List client files error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});