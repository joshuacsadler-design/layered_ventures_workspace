import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { recipientEmail, recipientName, notificationType, data } = await req.json();

    if (!recipientEmail || !notificationType) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Notification templates
    const templates = {
      PROOF_DELIVERED: {
        subject: 'Your proofs are ready for review',
        body: `Hi ${recipientName || 'there'},\n\nYour print proofs for order ${data.orderNumber} are now ready for your review. Please log in to your account to view and select your preferred proof.\n\nThank you,\nPureMetal Prints`,
      },
      PROOF_OPTION_ADDED: {
        subject: 'New proof option available for your order',
        body: `Hi ${recipientName || 'there'},\n\nWe've added a new proof option for your order ${data.orderNumber}. Please log in to review and select your preferred proof to continue with production.\n\nThank you,\nPureMetal Prints`,
      },
      ORDER_APPROVED: {
        subject: 'Your order has been approved for production',
        body: `Hi ${recipientName || 'there'},\n\nThank you for approving your order ${data.orderNumber}. We're now preparing your print for production.\n\nThank you,\nPureMetal Prints`,
      },
      REVISION_REQUESTED: {
        subject: 'Revision request received for your order',
        body: `Hi ${recipientName || 'there'},\n\nWe've received your revision request for order ${data.orderNumber}. Our team will review your request and get back to you shortly.\n\nThank you,\nPureMetal Prints`,
      },
      ORDER_SHIPPED: {
        subject: 'Your order has shipped!',
        body: `Hi ${recipientName || 'there'},\n\nGreat news! Your order ${data.orderNumber} has shipped.\n\nTracking: ${data.trackingNumber}\nCarrier: ${data.carrier}\n${data.trackingUrl ? `Track your shipment: ${data.trackingUrl}` : ''}\n\nThank you,\nPureMetal Prints`,
      },
      CANCELLATION_APPROVED: {
        subject: 'Your cancellation request has been approved',
        body: `Hi ${recipientName || 'there'},\n\nYour cancellation request for order ${data.orderNumber} has been approved. ${data.refundAmount ? `A refund of $${data.refundAmount.toFixed(2)} will be processed to your original payment method.` : ''}\n\nThank you,\nPureMetal Prints`,
      },
      CANCELLATION_DENIED: {
        subject: 'Your cancellation request',
        body: `Hi ${recipientName || 'there'},\n\nRegarding your cancellation request for order ${data.orderNumber}:\n\n${data.adminResponse || 'Your request cannot be processed at this time as the order is already in production.'}\n\nThank you,\nPureMetal Prints`,
      },
      PRODUCTION_STARTED: {
        subject: 'Your order is now in production',
        body: `Hi ${recipientName || 'there'},\n\nYour order ${data.orderNumber} is now in production. We'll notify you once it ships.\n\nThank you,\nPureMetal Prints`,
      },
    };

    const template = templates[notificationType];
    if (!template) {
      return Response.json({ error: 'Invalid notification type' }, { status: 400 });
    }

    // Send email via Core.SendEmail integration
    await base44.integrations.Core.SendEmail({
      from_name: 'PureMetal Prints',
      to: recipientEmail,
      subject: template.subject,
      body: template.body,
    });

    // Log audit
    await base44.functions.invoke('logAudit', {
      action: 'NOTIFICATION_SENT',
      entity_type: 'Notification',
      entity_id: recipientEmail,
      details: { type: notificationType, recipient: recipientEmail },
    });

    return Response.json({ success: true });
  } catch (error) {
    console.error('Error sending notification:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});