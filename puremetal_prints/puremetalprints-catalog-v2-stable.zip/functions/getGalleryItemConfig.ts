import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { gallery_image_id } = body || {};

    if (!gallery_image_id) return Response.json({ error: "gallery_image_id required" }, { status: 400 });

    const items = await base44.asServiceRole.entities.GalleryImage.filter({ id: gallery_image_id });
    const item = items[0];

    if (!item || !item.is_active) {
      return Response.json({ error: "Gallery item not found or inactive" }, { status: 404 });
    }

    return Response.json({
      id: item.id,
      title: item.title,
      file_id: item.file_id,
      configured_size: item.configured_size,
      configured_tier: item.configured_tier,
      configured_mount_key: item.configured_mount_key,
      configured_quantity: item.configured_quantity ?? 1,
      gallery_discount_pct: item.gallery_discount_pct ?? 15,
      allow_customization_unlock: item.allow_customization_unlock ?? true
    });
  } catch (e) {
    return Response.json({ error: e?.message ?? "Unknown error", stack: e?.stack }, { status: 500 });
  }
});