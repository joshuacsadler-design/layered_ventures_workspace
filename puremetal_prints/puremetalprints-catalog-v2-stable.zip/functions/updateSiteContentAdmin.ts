import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { siteContent, heroImages, announcements } = await req.json();

    // Update site content key-values
    if (siteContent) {
      for (const [key, value] of Object.entries(siteContent)) {
        const existing = (await base44.asServiceRole.entities.SiteContent.filter({ key }))[0];
        if (existing) {
          await base44.asServiceRole.entities.SiteContent.update(existing.id, { value });
        } else {
          await base44.asServiceRole.entities.SiteContent.create({ key, value });
        }
      }
    }

    // Update hero images
    if (heroImages) {
      for (const hero of heroImages) {
        if (hero.id) {
          await base44.asServiceRole.entities.GalleryImage.update(hero.id, hero);
        } else {
          await base44.asServiceRole.entities.GalleryImage.create(hero);
        }
      }
    }

    // Update announcements
    if (announcements) {
      for (const announcement of announcements) {
        if (announcement.id) {
          await base44.asServiceRole.entities.Announcement.update(announcement.id, announcement);
        } else {
          await base44.asServiceRole.entities.Announcement.create(announcement);
        }
      }
    }

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});