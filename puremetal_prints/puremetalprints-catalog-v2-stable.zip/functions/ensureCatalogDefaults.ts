import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const results = { products: [], variants: [], mounts: [], prices: [] };

    // 1. Ensure print product exists
    let printProduct = (await base44.asServiceRole.entities.Product.filter({ sku: 'PM-METAL' }))[0];
    if (!printProduct) {
      printProduct = await base44.asServiceRole.entities.Product.create({
        sku: 'PM-METAL',
        name: 'Metal Print',
        type: 'print',
        purchase_flow: 'CUSTOMIZER',
        active: true,
        show_in_shop: true,
        in_stock: true,
        shop_sort_order: 0
      });
      results.products.push({ action: 'created', sku: 'PM-METAL' });
    } else {
      await base44.asServiceRole.entities.Product.update(printProduct.id, {
        type: 'print',
        purchase_flow: 'CUSTOMIZER',
        in_stock: true,
        active: true,
        show_in_shop: true
      });
      results.products.push({ action: 'updated', sku: 'PM-METAL' });
    }

    // 2. Ensure print variants with data repair (cents migration + reserve visibility enforcement)
    const allVariants = await base44.asServiceRole.entities.PrintVariant.filter({ product_id: printProduct.id });
    
    for (const variant of allVariants) {
      const updates = {};
      let needsUpdate = false;

      // Migrate legacy standard_price to standard_price_cents
      if (!variant.standard_price_cents && variant.standard_price) {
        updates.standard_price_cents = Math.round(variant.standard_price * 100);
        needsUpdate = true;
      }

      // Migrate legacy reserve_price to reserve_price_cents
      if (!variant.reserve_price_cents && variant.reserve_price) {
        updates.reserve_price_cents = Math.round(variant.reserve_price * 100);
        needsUpdate = true;
      }

      // ENFORCE OPTION 1 RESERVE VISIBILITY
      const reservePriceCents = updates.reserve_price_cents ?? variant.reserve_price_cents;
      const reserveEnabled = variant.reserve_enabled === true;
      const reserveOffered = reserveEnabled && reservePriceCents && reservePriceCents > 0;

      if (!reserveOffered && variant.show_reserve_upsell !== false) {
        updates.show_reserve_upsell = false;
        needsUpdate = true;
      }

      if (!reserveEnabled && reservePriceCents) {
        updates.reserve_price_cents = null;
        needsUpdate = true;
      }

      if (needsUpdate) {
        await base44.asServiceRole.entities.PrintVariant.update(variant.id, updates);
        results.variants.push({ action: 'repaired', size: variant.size, updates });
      }
    }

    // Ensure default variant configs
    const variantConfigs = [
      { size: '6x8', standard_price: 20, reserve_enabled: false, reserve_price: null, show_reserve_upsell: false },
      { size: '8x10', standard_price: 30, reserve_enabled: false, reserve_price: null, show_reserve_upsell: false },
      { size: '8x12', standard_price: 40, reserve_enabled: true, reserve_price: 60, show_reserve_upsell: true }
    ];

    for (const config of variantConfigs) {
      let variant = (await base44.asServiceRole.entities.PrintVariant.filter({
        product_id: printProduct.id,
        size: config.size
      }))[0];

      if (!variant) {
        await base44.asServiceRole.entities.PrintVariant.create({
          product_id: printProduct.id,
          size: config.size,
          standard_price_cents: config.standard_price * 100,
          reserve_enabled: config.reserve_enabled,
          reserve_price_cents: config.reserve_price ? config.reserve_price * 100 : null,
          show_reserve_upsell: config.show_reserve_upsell,
          active: true,
          show_in_shop: true,
          in_stock: true,
          stock_mode: 'HIDE',
          sort_order: 0
        });
        results.variants.push({ action: 'created', size: config.size });
      }
    }

    // 3. Ensure mount offerings
    const mountConfigs = [
      { key: 'PRINT_ONLY', label: 'Print Only', included: true, sellable: false, price: 0 },
      { key: 'PURESHADOW_STANDARD', label: 'PureShadow (Standard)', included: true, sellable: true, price: 7 },
      { key: 'PURESHADOW_BLACK', label: 'PureShadow Black (Magnetic)', included: true, sellable: true, price: 10 }
    ];

    for (const config of mountConfigs) {
      let mount = (await base44.asServiceRole.entities.MountOffering.filter({ key: config.key }))[0];
      
      if (!mount) {
        mount = await base44.asServiceRole.entities.MountOffering.create({
          key: config.key,
          label: config.label,
          included_with_prints: config.included,
          standalone_sellable: config.sellable,
          standalone_price: config.price,
          active: true,
          in_stock: true,
          stock_mode: 'HIDE',
          sort_order: 0
        });
        results.mounts.push({ action: 'created', key: config.key });
      } else {
        await base44.asServiceRole.entities.MountOffering.update(mount.id, {
          label: config.label,
          included_with_prints: config.included,
          standalone_sellable: config.sellable,
          standalone_price: config.price
        });
        results.mounts.push({ action: 'updated', key: config.key });
      }

      // 4. Create mount products for sellable mounts
      if (config.sellable) {
        const mountSkuMap = {
          'PURESHADOW_STANDARD': 'PM-MOUNT-PS-STD',
          'PURESHADOW_BLACK': 'PM-MOUNT-PS-BLK'
        };
        const mountSku = mountSkuMap[config.key];
        
        const shortDescMap = {
          'PURESHADOW_STANDARD': 'Wall mount for PureMetal prints.',
          'PURESHADOW_BLACK': 'Magnetic wall mount for PureMetal prints.'
        };
        const fullDescMap = {
          'PURESHADOW_STANDARD': 'PureShadow (Standard) wall mount. Sold separately.',
          'PURESHADOW_BLACK': 'PureShadow Black (Magnetic) wall mount. Sold separately.'
        };
        
        let mountProduct = (await base44.asServiceRole.entities.Product.filter({ sku: mountSku }))[0];
        
        if (!mountProduct) {
          mountProduct = await base44.asServiceRole.entities.Product.create({
            sku: mountSku,
            name: config.label,
            type: 'mount',
            mount_key: config.key,
            purchase_flow: 'DIRECT_CART',
            active: true,
            show_in_shop: true,
            in_stock: mount.in_stock,
            stock_mode: 'DISABLE',
            short_description: shortDescMap[config.key] || '',
            description: fullDescMap[config.key] || '',
            shop_sort_order: 100
          });
          results.products.push({ action: 'created', sku: mountSku });
        } else {
          await base44.asServiceRole.entities.Product.update(mountProduct.id, {
            mount_key: config.key,
            active: true,
            show_in_shop: true,
            stock_mode: 'DISABLE'
          });
          results.products.push({ action: 'updated', sku: mountSku });
        }

        // 5. Ensure ProductPrice exists for mount
        const existingPrices = await base44.asServiceRole.entities.ProductPrice.filter({ product_id: mountProduct.id });
        if (existingPrices.length === 0) {
          await base44.asServiceRole.entities.ProductPrice.create({
            product_id: mountProduct.id,
            sku: mountSku + '-DEFAULT',
            label: 'Default',
            price_cents: config.price * 100,
            active: true,
            in_stock: true,
            stock_mode: 'HIDE',
            sort_order: 0
          });
          results.prices.push({ action: 'created', product_sku: mountSku });
        }
      }
    }

    // 6. Archive non-canonical mount products
    const canonicalMountSkus = ['PM-MOUNT-PS-STD', 'PM-MOUNT-PS-BLK'];
    const allProducts = await base44.asServiceRole.entities.Product.list();
    const allMounts = allProducts.filter(p => p.type === 'mount');
    
    for (const mount of allMounts) {
      if (!canonicalMountSkus.includes(mount.sku)) {
        await base44.asServiceRole.entities.Product.update(mount.id, {
          active: false,
          show_in_shop: false
        });
        results.products.push({ action: 'archived_non_canonical', sku: mount.sku });
      }
    }

    // 7. Dedupe canonical mount products (keep one per SKU)
    const skuGroups = {};
    for (const mount of allMounts) {
      if (!skuGroups[mount.sku]) skuGroups[mount.sku] = [];
      skuGroups[mount.sku].push(mount);
    }

    for (const [sku, group] of Object.entries(skuGroups)) {
      if (group.length <= 1) continue;

      const sortedGroup = [...group].sort((a, b) => {
        if (a.active && !b.active) return -1;
        if (!a.active && b.active) return 1;
        if (a.show_in_shop && !b.show_in_shop) return -1;
        if (!a.show_in_shop && b.show_in_shop) return 1;
        const aDate = new Date(a.updated_date || a.created_date || 0);
        const bDate = new Date(b.updated_date || b.created_date || 0);
        return bDate - aDate;
      });

      const canonical = sortedGroup[0];
      const duplicates = sortedGroup.slice(1);

      await base44.asServiceRole.entities.Product.update(canonical.id, {
        active: true,
        show_in_shop: canonicalMountSkus.includes(sku),
        purchase_flow: 'DIRECT_CART'
      });

      for (const dup of duplicates) {
        await base44.asServiceRole.entities.Product.update(dup.id, {
          active: false,
          show_in_shop: false
        });
        results.products.push({ action: 'archived_duplicate', sku: dup.sku });
      }
    }

    // 8. Ensure service products
    const serviceConfigs = [
      {
        sku: 'PM-SVC-ENHANCE',
        name: 'Photo Enhancement',
        type: 'service',
        short_description: 'Optional enhancement for best print results.',
        description: 'Color, contrast, and clarity adjustments to optimize for metal printing.',
        tiered_enabled: false,
        flat_price_cents: 1500,
        show_as_upsell: true,
        upsell_for_prints: true
      }
    ];

    for (const config of serviceConfigs) {
      let service = (await base44.asServiceRole.entities.Product.filter({ sku: config.sku }))[0];
      
      if (!service) {
        await base44.asServiceRole.entities.Product.create({
          ...config,
          purchase_flow: 'DIRECT_CART',
          active: true,
          show_in_shop: true,
          in_stock: true,
          stock_mode: 'DISABLE',
          shop_sort_order: 200
        });
        results.products.push({ action: 'created_service', sku: config.sku });
      } else {
        await base44.asServiceRole.entities.Product.update(service.id, {
          ...config,
          purchase_flow: 'DIRECT_CART'
        });
        results.products.push({ action: 'updated_service', sku: config.sku });
      }
    }

    // 9. Cleanup legacy per-size print products
    const legacyPatterns = ['PRINT-', '6x8', '8x10', '8x12'];
    const legacyProducts = allProducts.filter(p => {
      if (p.type !== 'print') return false;
      if (p.sku === 'PM-METAL') return false;
      return legacyPatterns.some(pattern => p.sku.includes(pattern) || (p.name && p.name.includes(pattern)));
    });

    for (const product of legacyProducts) {
      const newDesc = product.description 
        ? `${product.description} [ARCHIVED legacy size product — replaced by PrintVariant]`
        : '[ARCHIVED legacy size product — replaced by PrintVariant]';
      
      await base44.asServiceRole.entities.Product.update(product.id, {
        active: false,
        show_in_shop: false,
        description: newDesc
      });
      results.products.push({ action: 'archived_legacy', sku: product.sku });
    }

    return Response.json({ success: true, results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});