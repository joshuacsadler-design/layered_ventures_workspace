import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    // Find all messages with legacy attachment_url field populated
    // These are insecure public URLs that need migration or blocking
    const allMessages = await base44.asServiceRole.entities.PMMessages.list();
    
    const legacyAttachments = allMessages.filter(msg => {
      // Legacy: has attachment_url OR attachment_name but NO attachment_file_id
      return (msg.attachment_url || msg.attachment_name) && !msg.attachment_file_id;
    });

    return Response.json({
      count: legacyAttachments.length,
      messages: legacyAttachments.map(msg => ({
        id: msg.id,
        user_id: msg.user_id,
        thread_type: msg.thread_type,
        order_id: msg.order_id,
        from_role: msg.from_role,
        created_date: msg.created_date,
        attachment_url: msg.attachment_url,
        attachment_name: msg.attachment_name,
        body_preview: msg.body?.substring(0, 50) + '...',
      })),
      warning: 'These messages contain PUBLIC non-expiring file URLs. They should be migrated to private storage or marked for re-upload.',
    });
  } catch (error) {
    console.error('List legacy attachments error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});