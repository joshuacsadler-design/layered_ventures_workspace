import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const body = await req.json();
    const { 
      key, 
      label, 
      description, 
      image_file_id, 
      included_with_prints = true, 
      standalone_sellable = false, 
      standalone_price = 0,
      active = true,
      in_stock = true,
      stock_mode = 'HIDE',
      sort_order = 0
    } = body;

    if (!key || !label) {
      return Response.json({ error: 'key and label required' }, { status: 400 });
    }

    // Check if mount with this key already exists
    const existing = await base44.asServiceRole.entities.MountOffering.filter({ key });
    if (existing.length > 0) {
      return Response.json({ error: 'Mount with this key already exists' }, { status: 400 });
    }

    // Auto-generate SKU
    const count = (await base44.asServiceRole.entities.MountOffering.list()).length;
    const sku = `PM-MOUNT-${String(count + 1).padStart(4, '0')}`;

    const mount = await base44.asServiceRole.entities.MountOffering.create({
      key,
      sku,
      label,
      description: description || '',
      image_file_id: image_file_id || null,
      active,
      included_with_prints,
      standalone_sellable,
      standalone_price: standalone_sellable ? standalone_price : 0,
      in_stock,
      stock_mode,
      sort_order
    });

    // If standalone sellable, create a Product for it
    if (standalone_sellable) {
      const productSku = `PM-MNT-${key}`;
      await base44.asServiceRole.entities.Product.create({
        sku: productSku,
        name: label,
        type: 'mount',
        description: description || '',
        image_file_id: image_file_id || null,
        purchase_flow: 'DIRECT_CART',
        mount_key: key,
        active,
        show_in_shop: active,
        in_stock,
        stock_mode,
        shop_sort_order: sort_order
      });

      // Create ProductPrice for standalone mount
      await base44.asServiceRole.entities.ProductPrice.create({
        product_id: (await base44.asServiceRole.entities.Product.filter({ sku: productSku }))[0].id,
        sku: `${productSku}-BASE`,
        label: 'Standard',
        price_cents: Math.round(standalone_price * 100),
        active: true,
        in_stock: true,
        stock_mode: 'HIDE',
        sort_order: 0
      });
    }

    return Response.json({ success: true, mount });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});