import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { order_item_id, input_file_id, input_filename, input_mime_type, input_byte_size } = await req.json();
    
    if (!order_item_id || !input_file_id) {
      return Response.json({ error: 'order_item_id and input_file_id required' }, { status: 400 });
    }

    const items = await base44.asServiceRole.entities.OrderItem.filter({ id: order_item_id });
    const item = items[0];
    
    if (!item) {
      return Response.json({ error: 'OrderItem not found' }, { status: 404 });
    }

    await base44.asServiceRole.entities.OrderItem.update(order_item_id, {
      analyzer_input_file_id: input_file_id,
      analyzer_status: 'READY'
    });

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});