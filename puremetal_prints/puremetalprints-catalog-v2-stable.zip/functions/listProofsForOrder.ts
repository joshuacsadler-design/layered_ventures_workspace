import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Authentication required' }, { status: 401 });
    }

    const { order_id } = await req.json();
    
    if (!order_id) {
      return Response.json({ error: 'order_id is required' }, { status: 400 });
    }

    // Verify ownership
    const orders = await base44.entities.Order.filter({ id: order_id, user_id: user.id });
    if (orders.length === 0) {
      return Response.json({ error: 'Order not found or access denied' }, { status: 404 });
    }

    // Get all order items for this order (service role OK after ownership check)
    const items = await base44.asServiceRole.entities.OrderItem.filter({ order_id });
    const itemIds = items.map(i => i.id);

    if (itemIds.length === 0) {
      return Response.json({ proofs: [] });
    }

    // Get proofs for these items - only delivered proofs
    const allProofs = await base44.asServiceRole.entities.Proof.filter({
      order_item_id: { $in: itemIds },
      is_delivered: true,
    });

    return Response.json({ proofs: allProofs });
  } catch (error) {
    console.error('List proofs error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});