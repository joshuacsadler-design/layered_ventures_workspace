import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const formData = await req.formData();
    const file = formData.get('file');
    if (!file) {
      return Response.json({ error: 'No file provided' }, { status: 400 });
    }

    const uploadRes = await base44.integrations.Core.UploadFile({ file });
    const fileUrl = uploadRes.file_url;

    const fileRecord = await base44.asServiceRole.entities.File.create({
      kind: 'SHOP_IMAGE',
      file_url: fileUrl,
      filename: file.name
    });

    return Response.json({ success: true, file_id: fileRecord.id, url: fileUrl });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});