import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    let user = null;
    try {
      user = await base44.auth.me();
    } catch (e) {
      // User not authenticated
    }

    // Audit log the attempt
    await base44.asServiceRole.entities.AuditLog.create({
      entity_type: 'Function',
      entity_id: 'logAudit',
      action: 'SECURITY_BLOCKED_FUNCTION_CALL',
      user_id: user?.id || null,
      notes: `Attempted call to internal function by ${user?.email || 'anonymous'}`,
      timestamp: new Date().toISOString(),
    });

    return Response.json(
      { error: 'Forbidden: Internal function not callable' },
      { status: 403 }
    );
  } catch (error) {
    return Response.json(
      { error: 'Forbidden: Internal function not callable' },
      { status: 403 }
    );
  }
});