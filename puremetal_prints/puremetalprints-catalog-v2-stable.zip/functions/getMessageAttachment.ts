import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Authentication required' }, { status: 401 });
    }

    const { attachmentId } = await req.json();
    if (!attachmentId) {
      return Response.json({ error: 'attachmentId required' }, { status: 400 });
    }

    // Get the message with this attachment
    const messages = await base44.asServiceRole.entities.PMMessages.filter({ 
      id: attachmentId 
    });

    if (messages.length === 0) {
      return Response.json({ error: 'Attachment not found' }, { status: 404 });
    }

    const message = messages[0];

    // Verify the message has an attachment
    if (!message.attachment_file_id) {
      return Response.json({ error: 'No attachment on this message' }, { status: 404 });
    }

    // Authorization check:
    // - If admin: allow access to all attachments
    // - If client: only allow access to their own messages
    const isAdmin = user.role === 'admin';
    const isOwner = message.user_id === user.id;

    if (!isAdmin && !isOwner) {
      return Response.json({ error: 'Access denied' }, { status: 403 });
    }

    // Generate signed URL with 15-minute expiration
    const { signed_url } = await base44.asServiceRole.integrations.Core.CreateFileSignedUrl({
      file_uri: message.attachment_file_id,
      expires_in: 900, // 15 minutes
    });

    return Response.json({ 
      signed_url,
      filename: message.attachment_filename,
      mime_type: message.attachment_mime_type,
      byte_size: message.attachment_byte_size,
    });
  } catch (error) {
    console.error('Get message attachment error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});