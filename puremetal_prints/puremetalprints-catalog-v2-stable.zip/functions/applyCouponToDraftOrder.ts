import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { code } = await req.json();

    if (!code) {
      return Response.json({ error: 'code is required' }, { status: 400 });
    }

    const normalizedCode = code.toUpperCase();

    // Find coupon
    const coupons = await base44.asServiceRole.entities.Coupon.filter({ code: normalizedCode });
    if (coupons.length === 0) {
      return Response.json({ error: 'Coupon not found' }, { status: 404 });
    }

    const coupon = coupons[0];

    // Validate coupon
    if (!coupon.active) {
      return Response.json({ error: 'Coupon is not active' }, { status: 400 });
    }

    const now = new Date();
    if (coupon.start_at && new Date(coupon.start_at) > now) {
      return Response.json({ error: 'Coupon not yet valid' }, { status: 400 });
    }
    if (coupon.end_at && new Date(coupon.end_at) < now) {
      return Response.json({ error: 'Coupon expired' }, { status: 400 });
    }

    if (coupon.max_redemptions && coupon.redemption_count >= coupon.max_redemptions) {
      return Response.json({ error: 'Coupon max redemptions reached' }, { status: 400 });
    }

    // Find draft order
    const orders = await base44.asServiceRole.entities.Order.filter({ user_id: user.id, status: 'DRAFT' });
    if (orders.length === 0) {
      return Response.json({ error: 'No draft order found' }, { status: 404 });
    }

    const order = orders[0];

    // Validate min order amount
    if (coupon.min_order_amount && order.subtotal < coupon.min_order_amount) {
      return Response.json({ 
        error: `Order must be at least $${coupon.min_order_amount} to use this coupon` 
      }, { status: 400 });
    }

    // Compute discount
    let discount = 0;
    if (coupon.discount_type === 'PERCENT' && coupon.percent_off) {
      discount = order.subtotal * (coupon.percent_off / 100);
    } else if (coupon.discount_type === 'AMOUNT' && coupon.amount_off) {
      discount = Math.min(coupon.amount_off, order.subtotal);
    }

    const discountJson = {
      code: coupon.code,
      type: coupon.discount_type,
      value: coupon.percent_off || coupon.amount_off,
      computed: discount,
    };

    const newTotal = Math.max(0, order.subtotal - discount + (order.shipping || 0) + (order.tax || 0));

    await base44.asServiceRole.entities.Order.update(order.id, {
      total: newTotal,
    });

    return Response.json({
      ok: true,
      order_id: order.id,
      discount,
      new_total: newTotal,
      coupon_name: coupon.name,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});