import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { order_item_id } = await req.json();
    
    if (!order_item_id) {
      return Response.json({ error: 'order_item_id required' }, { status: 400 });
    }

    // Load OrderItem
    const items = await base44.asServiceRole.entities.OrderItem.filter({ id: order_item_id });
    const item = items[0];
    
    if (!item) {
      return Response.json({ error: 'OrderItem not found' }, { status: 404 });
    }

    // Create snapshot
    const input_snapshot = {
      size: item.size || null,
      tier: item.tier || null,
      mount_key: item.mount_key || null,
      quantity: item.quantity || 1,
      pricing_source: item.pricing_source || 'STANDARD',
      gallery_pricing_applied: item.gallery_pricing_applied || false,
      gallery_image_id: item.gallery_image_id || null,
      kind: item.kind,
      sku: item.sku,
      input_file_attached: !!item.analyzer_input_file_id
    };

    // Create AIAnalysisJob
    const now = new Date().toISOString();
    const job = await base44.asServiceRole.entities.AIAnalysisJob.create({
      order_id: item.order_id,
      order_item_id: item.id,
      client_id: null,
      status: 'RUNNING',
      requested_by_user_id: user.id,
      requested_by_email: user.email,
      started_at: now,
      input_snapshot,
      input_file_id: item.analyzer_input_file_id || null,
      is_ad_hoc: false
    });

    // Perform manual-first analysis
    const findings = [];
    const recommendations = [];
    let verdict = 'OK';

    // Check 1: Quantity validation
    if (!item.quantity || item.quantity < 1) {
      verdict = 'FAIL';
      findings.push('Invalid quantity: must be at least 1');
    }

    // Check 2: Reserve tier validation
    if (item.tier === 'reserve' && item.kind === 'print') {
      // Check if reserve was properly configured
      if (item.print_variant_id) {
        const variants = await base44.asServiceRole.entities.PrintVariant.filter({ 
          id: item.print_variant_id 
        });
        const variant = variants[0];
        
        if (variant && (!variant.reserve_enabled || !variant.reserve_price_cents)) {
          verdict = 'FAIL';
          findings.push('Reserve tier selected but not properly enabled or priced for this size');
        }
      }
    }

    // Check 3: Mount validation
    if (item.kind === 'print' && !item.mount_key) {
      if (verdict !== 'FAIL') verdict = 'WARN';
      findings.push('No mount option selected');
    }

    // Check 4: Gallery pricing consistency
    if (item.pricing_source === 'GALLERY' && !item.gallery_pricing_applied) {
      if (verdict !== 'FAIL') verdict = 'WARN';
      findings.push('Pricing source is GALLERY but gallery_pricing_applied is false');
    }

    // Add standard recommendations
    recommendations.push('Verify file resolution is 300 DPI+ at target print size before production');
    recommendations.push('Confirm crop margins and safe area for metal panel bleed');
    
    if (item.tier === 'reserve') {
      recommendations.push('Confirm gloss stock selection matches PureMetal Reserve specifications');
    } else {
      recommendations.push('Confirm standard metal stock selection');
    }

    if (item.analyzer_input_file_id) {
      findings.push('Analyzer input file attached (file ID on record)');
    }

    if (findings.length === 0) {
      findings.push('Configuration appears valid');
    }

    const details_json = {
      checks: [
        { name: 'quantity_validation', passed: item.quantity >= 1 },
        { name: 'tier_validation', passed: verdict !== 'FAIL' },
        { name: 'mount_validation', passed: !!item.mount_key },
        { name: 'pricing_consistency', passed: !(item.pricing_source === 'GALLERY' && !item.gallery_pricing_applied) }
      ],
      snapshot: input_snapshot,
      file_metadata: item.analyzer_input_file_id ? { file_id: item.analyzer_input_file_id } : null,
      analyzer_version: 'manual-v1'
    };

    const output_summary = `Analysis complete: ${verdict} - ${findings.length} finding(s), ${recommendations.length} recommendation(s)`;
    const output_json = { verdict, findings, recommendations, details_json };

    // Create AIAnalysisResult
    const result = await base44.asServiceRole.entities.AIAnalysisResult.create({
      order_item_id: item.id,
      analysis_job_id: job.id,
      verdict,
      findings,
      recommendations,
      details_json
    });

    // Update job to COMPLETED
    await base44.asServiceRole.entities.AIAnalysisJob.update(job.id, {
      status: 'COMPLETED',
      completed_at: new Date().toISOString(),
      output_summary,
      output_json
    });

    // Update OrderItem
    await base44.asServiceRole.entities.OrderItem.update(item.id, {
      analyzer_status: 'HAS_RESULT',
      last_analysis_job_id: job.id,
      last_analysis_result_id: result.id
    });

    return Response.json({ 
      ok: true, 
      job: { ...job, status: 'COMPLETED', completed_at: new Date().toISOString(), output_summary, output_json },
      result 
    });
  } catch (error) {
    return Response.json({ error: error.message, stack: error.stack }, { status: 500 });
  }
});