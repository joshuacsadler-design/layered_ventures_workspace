import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { total_cents, discount_pct } = body || {};

    if (total_cents === undefined) {
      return Response.json({ error: "total_cents required" }, { status: 400 });
    }

    const pct = Number(discount_pct ?? 15);
    const discount_amount_cents = Math.round(total_cents * (pct / 100));
    const discounted_total_cents = total_cents - discount_amount_cents;

    return Response.json({ 
      discounted_total_cents, 
      discount_amount_cents, 
      discount_pct: pct 
    });
  } catch (e) {
    return Response.json({ error: e?.message ?? "Unknown error", stack: e?.stack }, { status: 500 });
  }
});