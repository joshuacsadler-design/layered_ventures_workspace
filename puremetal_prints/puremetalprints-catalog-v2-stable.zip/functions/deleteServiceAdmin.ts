import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { product_id } = await req.json();
    
    // Delegate to deleteProductAdmin
    const resp = await base44.functions.invoke('deleteProductAdmin', { product_id });
    return Response.json(resp.data);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});