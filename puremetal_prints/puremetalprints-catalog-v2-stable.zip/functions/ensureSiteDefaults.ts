import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const defaults = [
      {
        key: 'hero_caption',
        value: 'Transform your memories into stunning metal prints that last a lifetime.',
      },
      {
        key: 'gallery_helper_text',
        value: 'Browse our featured gallery or upload your own image to get started.',
      },
    ];

    const created = [];

    for (const def of defaults) {
      const existing = await base44.asServiceRole.entities.SiteContent.filter({ key: def.key });
      if (existing.length === 0) {
        const record = await base44.asServiceRole.entities.SiteContent.create(def);
        created.push(record);
      }
    }

    // Ensure at least one default hero exists in GalleryImage
    const existingHeroes = await base44.asServiceRole.entities.GalleryImage.filter({ is_default_hero: true });
    if (existingHeroes.length === 0) {
      // Create a placeholder default hero (admin should upload actual image)
      const defaultHero = await base44.asServiceRole.entities.GalleryImage.create({
        title: 'Default Hero Image',
        file_id: 'placeholder', // Admin must update with real file_id
        is_default_hero: true,
        is_active: true,
        sort_order: 0,
        default_size: '8x10',
        default_material: 'standard',
        allow_reserve_upsell: true,
      });
      created.push(defaultHero);
    }

    return Response.json({
      success: true,
      created: created,
      message: created.length > 0 ? 'Defaults created' : 'Defaults already exist',
    });
  } catch (error) {
    console.error('Error ensuring site defaults:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});