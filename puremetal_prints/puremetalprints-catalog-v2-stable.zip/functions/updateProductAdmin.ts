import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { id, patch } = await req.json();
    if (!id || !patch) {
      return Response.json({ error: 'Missing id or patch' }, { status: 400 });
    }

    const product = await base44.asServiceRole.entities.Product.get(id);
    if (!product) {
      return Response.json({ error: 'Product not found' }, { status: 404 });
    }

    // Enforce type-based rules
    let updates = { ...patch };
    if (product.type === 'print' || updates.type === 'print') {
      updates.purchase_flow = 'CUSTOMIZER';
      updates.in_stock = true;
    } else if (updates.type && updates.type !== 'print') {
      updates.purchase_flow = 'DIRECT_CART';
    }

    // Clear mount_key if type changes away from mount
    if (updates.type && updates.type !== 'mount') {
      updates.mount_key = null;
    }

    // Service validation
    if ((product.type === 'service' || updates.type === 'service') && updates.tiered_enabled === false) {
      if (!updates.flat_price_cents && !product.flat_price_cents) {
        return Response.json({ error: 'flat_price_cents required when tiered_enabled=false' }, { status: 400 });
      }
    }

    // Allow service-specific fields
    if (product.type === 'service' || updates.type === 'service') {
      // Keep service fields in updates
    } else {
      // Clear service fields if not a service
      if (updates.tiered_enabled !== undefined) delete updates.tiered_enabled;
      if (updates.flat_price_cents !== undefined) delete updates.flat_price_cents;
      if (updates.show_as_upsell !== undefined) delete updates.show_as_upsell;
      if (updates.upsell_for_prints !== undefined) delete updates.upsell_for_prints;
    }

    const updated = await base44.asServiceRole.entities.Product.update(id, updates);
    return Response.json({ success: true, product: updated });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});