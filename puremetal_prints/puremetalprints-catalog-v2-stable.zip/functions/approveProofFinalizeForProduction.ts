import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Authentication required' }, { status: 401 });
    }

    const { orderId, proofId } = await req.json();

    if (!orderId || !proofId) {
      return Response.json({ error: 'orderId and proofId required' }, { status: 400 });
    }

    // Verify order ownership
    const orders = await base44.entities.Order.filter({ id: orderId, user_id: user.id });
    const order = orders[0];
    if (!order) {
      return Response.json({ error: 'Order not found' }, { status: 404 });
    }

    // Get the approved proof
    const proofs = await base44.entities.Proof.filter({ id: proofId, order: orderId });
    const approvedProof = proofs[0];
    if (!approvedProof) {
      return Response.json({ error: 'Proof not found' }, { status: 404 });
    }

    // Mark approved proof as selected (use service role after ownership check)
    await base44.asServiceRole.entities.Proof.update(proofId, { is_selected: true });

    // Delete all other proofs for this order
    const allProofs = await base44.asServiceRole.entities.Proof.filter({ order: orderId });
    for (const proof of allProofs) {
      if (proof.id !== proofId) {
        await base44.asServiceRole.entities.Proof.delete(proof.id);
      }
    }

    // Update order status to PrintReady
    await base44.asServiceRole.entities.Order.update(orderId, {
      status: 'PrintReady',
    });

    // Create/update ClientFile records for permanent storage
    const clients = await base44.entities.Client.filter({ user_id: user.id });
    const client = clients[0];

    if (client && approvedProof.order_item) {
      await base44.asServiceRole.entities.ClientFile.create({
        client: client.id,
        order: orderId,
        order_item: approvedProof.order_item,
        file_type: 'proof',
        file_url: approvedProof.proof_image_url,
        filename: `proof-${proofId}.jpg`,
      });

      if (approvedProof.master_file_url) {
        await base44.asServiceRole.entities.ClientFile.create({
          client: client.id,
          order: orderId,
          order_item: approvedProof.order_item,
          file_type: 'master',
          file_url: approvedProof.master_file_url,
          filename: `master-${proofId}.jpg`,
        });
      }
    }

    // Send notification to admin
    await base44.asServiceRole.integrations.Core.SendEmail({
      to: 'admin@puremetalprints.pro',
      subject: `Order ${order.order_number} Approved - Ready for Production`,
      body: `Client has approved their proof.\n\nOrder: ${order.order_number}\nClient: ${user.full_name}\n\nOrder is now ready for production.`,
    });

    return Response.json({ 
      success: true,
      message: 'Proof approved and order ready for production',
    });
  } catch (error) {
    console.error('Approve proof error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});