import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Get print product
    const printProduct = (await base44.asServiceRole.entities.Product.filter({
      sku: 'PM-METAL',
      active: true,
      show_in_shop: true
    }))[0] || null;

    // Get print variants
    let printVariants = [];
    if (printProduct) {
      const allVariants = await base44.asServiceRole.entities.PrintVariant.filter({ product_id: printProduct.id });
      printVariants = allVariants
        .filter(v => v.active && v.show_in_shop)
        .filter(v => {
          if (!v.in_stock && v.stock_mode === 'HIDE') return false;
          return true;
        })
        .map(v => ({
          ...v,
          purchasable: v.in_stock
        }))
        .sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));
    }

    // Get mount offerings included with prints
    const allMounts = await base44.asServiceRole.entities.MountOffering.list('sort_order');
    const mountsIncluded = allMounts
      .filter(m => m.active && m.included_with_prints)
      .filter(m => {
        if (!m.in_stock && m.stock_mode === 'HIDE') return false;
        return true;
      })
      .map(m => ({
        ...m,
        purchasable: m.in_stock
      }));

    // Get non-print products (mounts sold separately)
    const allProducts = await base44.asServiceRole.entities.Product.filter({
      active: true,
      show_in_shop: true
    });
    
    let nonPrintProducts = allProducts
      .filter(p => p.type !== 'print')
      .filter(p => {
        if (!p.in_stock && p.stock_mode === 'HIDE') return false;
        return true;
      })
      .map(p => ({
        ...p,
        purchasable: p.in_stock
      }))
      .sort((a, b) => (a.shop_sort_order || 0) - (b.shop_sort_order || 0));
    
    // Deduplicate by SKU (keep first occurrence)
    const seenSkus = new Set();
    nonPrintProducts = nonPrintProducts.filter(p => {
      if (seenSkus.has(p.sku)) return false;
      seenSkus.add(p.sku);
      return true;
    });

    // Get services (type=service)
    const allServices = await base44.asServiceRole.entities.Product.filter({
      type: 'service',
      active: true,
      show_in_shop: true
    });

    const services = allServices
      .filter(s => {
        if (!s.in_stock && s.stock_mode === 'HIDE') return false;
        return true;
      })
      .map(s => ({
        ...s,
        purchasable: s.in_stock
      }))
      .sort((a, b) => (a.shop_sort_order || 0) - (b.shop_sort_order || 0));

    // Get product prices for non-print products
    const allPrices = await base44.asServiceRole.entities.ProductPrice.list('sort_order');
    const productPrices = allPrices
      .filter(pp => {
        const productExists = nonPrintProducts.some(p => p.id === pp.product_id);
        return productExists && pp.active;
      })
      .filter(pp => {
        if (!pp.in_stock && pp.stock_mode === 'HIDE') return false;
        return true;
      })
      .map(pp => ({
        ...pp,
        purchasable: pp.in_stock
      }));

    // Build service prices map
    const servicePricesByProductId = {};
    const servicePrices = allPrices.filter(pp => services.some(s => s.id === pp.product_id) && pp.active);
    for (const price of servicePrices) {
      if (!servicePricesByProductId[price.product_id]) {
        servicePricesByProductId[price.product_id] = [];
      }
      servicePricesByProductId[price.product_id].push(price);
    }

    return Response.json({
      printProduct,
      printVariants,
      mountsIncluded,
      nonPrintProducts,
      services,
      productPrices,
      servicePricesByProductId
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});