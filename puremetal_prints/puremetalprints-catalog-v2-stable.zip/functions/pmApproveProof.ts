import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { proofId, orderItemId } = await req.json();
    if (!proofId || !orderItemId) {
      return Response.json({ error: 'Missing proofId or orderItemId' }, { status: 400 });
    }

    // Get proof and verify ownership
    const proofs = await base44.entities.PMProofs.filter({ id: proofId, user_id: user.id });
    const proof = proofs[0];
    if (!proof) {
      return Response.json({ error: 'Proof not found' }, { status: 404 });
    }

    // Get order item
    const items = await base44.entities.PMOrderItems.filter({ id: orderItemId, user_id: user.id });
    const item = items[0];
    if (!item) {
      return Response.json({ error: 'Order item not found' }, { status: 404 });
    }

    // Mark this proof as selected, deselect others
    const allProofs = await base44.entities.PMProofs.filter({ order_item_id: orderItemId });
    for (const p of allProofs) {
      await base44.entities.PMProofs.update(p.id, { is_selected: p.id === proofId });
    }

    // Update item status
    await base44.entities.PMOrderItems.update(orderItemId, {
      status: 'Approved',
      approved_proof_id: proofId,
    });

    // Check if all items in order are approved
    const orderItems = await base44.entities.PMOrderItems.filter({ order_id: item.order_id });
    const allApproved = orderItems.every(i => i.status === 'Approved' || i.status === 'Production Ready');
    
    if (allApproved) {
      // Update order status
      await base44.entities.PMOrders.update(item.order_id, {
        status: 'Approved For Production',
      });

      // Mark all approved items as production ready
      for (const i of orderItems.filter(i => i.status === 'Approved')) {
        await base44.entities.PMOrderItems.update(i.id, { status: 'Production Ready' });
      }
    }

    return Response.json({ success: true, allApproved });
  } catch (error) {
    console.error('Approve proof error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});