import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Authentication required' }, { status: 401 });
    }

    const formData = await req.formData();
    const file = formData.get('file');
    const orderItemId = formData.get('orderItemId');

    if (!file || !orderItemId) {
      return Response.json({ error: 'file and orderItemId required' }, { status: 400 });
    }

    // Verify order item ownership
    const items = await base44.entities.OrderItem.filter({ id: orderItemId });
    const orderItem = items[0];
    if (!orderItem) {
      return Response.json({ error: 'Order item not found' }, { status: 404 });
    }

    const orders = await base44.entities.Order.filter({ id: orderItem.order_id, user_id: user.id });
    if (orders.length === 0) {
      return Response.json({ error: 'Access denied' }, { status: 403 });
    }

    // Upload original (IMMUTABLE - never modified)
    const { file_url: originalUrl } = await base44.integrations.Core.UploadFile({ file });

    const originalFile = await base44.entities.File.create({
      order_item_id: orderItemId,
      kind: 'CLIENT_ORIGINAL',
      file_url: originalUrl,
      filename: file.name,
      source_file_id: null,
      is_delivered_to_client: false,
      metadata: {},
    });

    // Run analyzer (creates working copy)
    const analysisResult = await base44.integrations.Core.InvokeLLM({
      prompt: `Analyze this image for metal print production. Detect:
1. Effective PPI/resolution
2. Whether cropping is recommended
3. Infusion risk level (low/medium/high based on contrast, detail, color complexity)
4. Recommended adjustments (scaling, sharpening, tonal refinement)

Return JSON only.`,
      file_urls: [originalUrl],
      response_json_schema: {
        type: 'object',
        properties: {
          detected_ppi: { type: 'number' },
          crop_recommended: { type: 'boolean' },
          infusion_risk_level: { type: 'string', enum: ['low', 'medium', 'high'] },
          adjustments_recommended: { type: 'array', items: { type: 'string' } },
          manual_work_required: { type: 'boolean' },
        },
      },
    });

    // Create working copy (derived from original)
    const workingFile = await base44.entities.File.create({
      order_item_id: orderItemId,
      kind: 'ANALYZER_WORKING_COPY',
      file_url: originalUrl, // For now, same URL (future: apply standard prep)
      filename: `working_${file.name}`,
      source_file_id: originalFile.id,
      is_delivered_to_client: false,
      metadata: {
        ppi: analysisResult.detected_ppi,
        crop_recommended: analysisResult.crop_recommended,
      },
    });

    // Log analyzer job
    await base44.entities.AnalyzerJob.create({
      order_item_id: orderItemId,
      input_file_id: originalFile.id,
      output_file_id: workingFile.id,
      detected_ppi: analysisResult.detected_ppi || null,
      crop_recommended: analysisResult.crop_recommended || false,
      infusion_risk_level: analysisResult.infusion_risk_level || 'low',
      prep_tier: 'standard',
      adjustments_applied: analysisResult.adjustments_recommended || [],
      manual_work_required: analysisResult.manual_work_required || false,
    });

    // Update order status to UPLOADED
    await base44.asServiceRole.entities.Order.update(orders[0].id, { status: 'UPLOADED' });

    // Update item status
    await base44.asServiceRole.entities.OrderItem.update(orderItemId, { status: 'IN_PROOFING' });

    // Audit log
    await base44.asServiceRole.entities.AuditLog.create({
      entity_type: 'OrderItem',
      entity_id: orderItemId,
      action: 'file_upload_and_analysis',
      user_id: user.id,
      after_state: { original_file_id: originalFile.id, working_file_id: workingFile.id },
      notes: 'Client uploaded original, analyzer created working copy',
    });

    return Response.json({
      success: true,
      original_file_id: originalFile.id,
      working_file_id: workingFile.id,
      analysis: analysisResult,
    });
  } catch (error) {
    console.error('Upload error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});