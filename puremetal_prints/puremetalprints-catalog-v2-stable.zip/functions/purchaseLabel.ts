import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { orderId, parcels } = await req.json();
    if (!orderId || !parcels || !Array.isArray(parcels) || parcels.length === 0) {
      return Response.json({ error: 'orderId and parcels array required' }, { status: 400 });
    }

    // Get order
    const orders = await base44.asServiceRole.entities.Order.filter({ id: orderId });
    if (orders.length === 0) {
      return Response.json({ error: 'Order not found' }, { status: 404 });
    }

    const order = orders[0];

    // Verify all items are COMPLETED
    const items = await base44.asServiceRole.entities.OrderItem.filter({ order_id: orderId });
    const allCompleted = items.every(item => item.status === 'COMPLETED');
    if (!allCompleted) {
      return Response.json({ 
        error: 'All order items must be COMPLETED before purchasing label' 
      }, { status: 400 });
    }

    // Create shipment parcels atomically
    const shipDate = new Date().toISOString().split('T')[0];
    const parcelRecords = [];

    for (const parcel of parcels) {
      const { carrier, tracking_number, tracking_url, label_url } = parcel;
      if (!carrier || !tracking_number) {
        return Response.json({ error: 'Each parcel must have carrier and tracking_number' }, { status: 400 });
      }

      const parcelRecord = await base44.asServiceRole.entities.ShipmentParcel.create({
        order_id: orderId,
        carrier,
        tracking_number,
        tracking_url: tracking_url || null,
        label_url: label_url || null,
        ship_date: shipDate,
        purchased_at: new Date().toISOString(),
      });

      parcelRecords.push(parcelRecord);
    }

    // Update order status (atomic with parcel creation)
    await base44.asServiceRole.entities.Order.update(orderId, { 
      status: 'COMPLETED',
    });

    // Audit log
    await base44.asServiceRole.entities.AuditLog.create({
      entity_type: 'Order',
      entity_id: orderId,
      action: 'purchase_label',
      user_id: user.id,
      after_state: { 
        parcel_count: parcels.length,
        ship_date: shipDate,
      },
      notes: `Admin purchased shipping label(s) - ${parcels.length} parcel(s)`,
    });

    // Notify client
    const client = (await base44.asServiceRole.entities.Client.filter({ id: order.client_id }))[0];
    if (client) {
      const trackingInfo = parcels.map(p => 
        `${p.carrier}: ${p.tracking_number}${p.tracking_url ? ` (${p.tracking_url})` : ''}`
      ).join('\n');

      await base44.asServiceRole.integrations.Core.SendEmail({
        to: client.email,
        subject: `Your Order Has Shipped - ${order.order_number}`,
        body: `Hello ${client.full_name},

Great news! Your order ${order.order_number} has been shipped.

Tracking Information:
${trackingInfo}

Thank you for your order!
PureMetal Prints`,
      });
    }

    return Response.json({ 
      success: true, 
      parcels: parcelRecords.length,
    });
  } catch (error) {
    console.error('Purchase label error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});