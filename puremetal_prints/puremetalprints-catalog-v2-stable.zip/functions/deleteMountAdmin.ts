import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { mount_offering_id } = await req.json();
    if (!mount_offering_id) {
      return Response.json({ error: 'mount_offering_id required' }, { status: 400 });
    }

    const mounts = await base44.asServiceRole.entities.MountOffering.filter({ id: mount_offering_id });
    const mount = mounts[0];
    if (!mount) {
      return Response.json({ error: 'Mount not found' }, { status: 404 });
    }

    // Archive mount offering
    await base44.asServiceRole.entities.MountOffering.update(mount_offering_id, {
      active: false,
      included_with_prints: false,
      standalone_sellable: false
    });

    // Archive linked standalone mount product if exists
    const linkedProducts = await base44.asServiceRole.entities.Product.filter({ 
      type: 'mount', 
      mount_key: mount.key 
    });
    for (const product of linkedProducts) {
      await base44.asServiceRole.entities.Product.update(product.id, {
        active: false,
        show_in_shop: false
      });
    }

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});