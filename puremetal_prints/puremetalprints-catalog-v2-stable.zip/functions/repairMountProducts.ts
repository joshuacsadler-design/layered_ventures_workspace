import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const canonicalSkus = ['PM-MOUNT-PS-STD', 'PM-MOUNT-PS-BLK'];
    
    // Fetch all mount products
    const allMounts = await base44.asServiceRole.entities.Product.filter({ type: 'mount' });
    
    // Group by SKU
    const skuGroups = {};
    for (const mount of allMounts) {
      if (!skuGroups[mount.sku]) {
        skuGroups[mount.sku] = [];
      }
      skuGroups[mount.sku].push(mount);
    }

    const kept = [];
    let archivedCount = 0;

    const skuDetails = [];

    // Process each SKU group
    for (const [sku, group] of Object.entries(skuGroups)) {
      if (group.length === 0) continue;

      // Pick canonical: prefer active=true, then show_in_shop=true, then newest
      const sortedGroup = [...group].sort((a, b) => {
        if (a.active && !b.active) return -1;
        if (!a.active && b.active) return 1;
        if (a.show_in_shop && !b.show_in_shop) return -1;
        if (!a.show_in_shop && b.show_in_shop) return 1;
        const aDate = new Date(a.updated_date || a.created_date || 0);
        const bDate = new Date(b.updated_date || b.created_date || 0);
        return bDate - aDate;
      });

      const canonical = sortedGroup[0];
      const duplicates = sortedGroup.slice(1);

      // Update canonical
      await base44.asServiceRole.entities.Product.update(canonical.id, {
        active: true,
        show_in_shop: canonicalSkus.includes(sku),
        purchase_flow: 'DIRECT_CART'
      });

      if (canonicalSkus.includes(sku)) {
        kept.push(sku);
      }

      // Archive duplicates
      const archivedIds = [];
      for (const dup of duplicates) {
        await base44.asServiceRole.entities.Product.update(dup.id, {
          active: false,
          show_in_shop: false
        });
        archivedIds.push(dup.id);
        archivedCount++;
      }

      // Archive non-canonical SKUs
      if (!canonicalSkus.includes(sku)) {
        await base44.asServiceRole.entities.Product.update(canonical.id, {
          show_in_shop: false
        });
      }

      skuDetails.push({
        sku,
        kept_id: canonical.id,
        archived_ids: archivedIds
      });
    }

    return Response.json({ 
      success: true, 
      archived_count: archivedCount, 
      kept,
      skus: skuDetails
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});