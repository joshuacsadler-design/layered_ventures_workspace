import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import Stripe from 'npm:stripe@17.6.0';

const stripe = new Stripe(Deno.env.get('STRIPE_API_KEY'));
const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  
  try {
    const signature = req.headers.get('stripe-signature');
    const body = await req.text();

    if (!signature || !webhookSecret) {
      return Response.json({ error: 'Missing signature or webhook secret' }, { status: 400 });
    }

    // Verify webhook signature (async for Deno)
    const event = await stripe.webhooks.constructEventAsync(body, signature, webhookSecret);

    // Handle checkout completion
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      const orderId = session.metadata?.order_id;

      if (!orderId) {
        console.error('No order_id in session metadata');
        return Response.json({ error: 'No order_id' }, { status: 400 });
      }

      // Update order (new schema)
      await base44.asServiceRole.entities.Order.update(orderId, {
        status: 'NEEDS_REVIEW',
        stripe_payment_intent: session.payment_intent,
        total: session.amount_total / 100,
        shipping: session.total_details?.amount_shipping ? session.total_details.amount_shipping / 100 : 0,
        tax: session.total_details?.amount_tax ? session.total_details.amount_tax / 100 : 0,
        shipping_address: session.shipping_details?.address ? {
          line1: session.shipping_details.address.line1 || '',
          line2: session.shipping_details.address.line2 || '',
          city: session.shipping_details.address.city || '',
          state: session.shipping_details.address.state || '',
          zip: session.shipping_details.address.postal_code || '',
          country: session.shipping_details.address.country || 'US',
        } : null,
      });

      // Update all items to PENDING
      const items = await base44.asServiceRole.entities.OrderItem.filter({ order_id: orderId });
      for (const item of items) {
        await base44.asServiceRole.entities.OrderItem.update(item.id, { status: 'PENDING' });
      }

      // Get client and send confirmation
      const orders = await base44.asServiceRole.entities.Order.list();
      const order = orders.find(o => o.id === orderId);
      if (order) {
        const clients = await base44.asServiceRole.entities.Client.filter({ id: order.client_id });
        const client = clients[0];
        if (client) {
          await base44.asServiceRole.integrations.Core.SendEmail({
            to: client.email,
            subject: `Order Confirmed - ${order.order_number}`,
            body: `Hi ${client.full_name},\n\nThank you for your order! Your payment has been received.\n\nOrder Number: ${order.order_number}\nTotal: $${order.total?.toFixed(2)}\n\nWe'll start working on your prints and send you proofs for approval soon.\n\nBest regards,\nPureMetal Prints Team`,
          });
        }
      }

      // Log audit
      await base44.asServiceRole.functions.invoke('logAudit', {
        orderId,
        action: 'PAYMENT_COMPLETED',
        performedBy: 'system',
        details: { payment_intent: session.payment_intent, amount: session.amount_total / 100 },
      });
    }

    return Response.json({ received: true });
  } catch (error) {
    console.error('Webhook error:', error);
    return Response.json({ error: error.message }, { status: 400 });
  }
});