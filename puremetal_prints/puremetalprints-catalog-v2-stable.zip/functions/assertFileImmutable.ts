import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const { fileId } = await req.json();
    if (!fileId) {
      return Response.json({ error: 'fileId required' }, { status: 400 });
    }

    const files = await base44.asServiceRole.entities.File.filter({ id: fileId });
    const file = files[0];
    
    if (!file) {
      return Response.json({ error: 'File not found' }, { status: 404 });
    }

    if (file.kind === 'CLIENT_ORIGINAL') {
      return Response.json({ 
        error: 'Cannot modify or replace CLIENT_ORIGINAL files. Original files are immutable.',
        immutable: true 
      }, { status: 403 });
    }

    return Response.json({ immutable: false });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});