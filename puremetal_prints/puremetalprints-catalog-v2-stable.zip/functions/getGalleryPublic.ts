import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const items = await base44.asServiceRole.entities.GalleryImage.filter({ is_active: true });
    const sorted = (items ?? []).sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0));

    return Response.json({
      items: sorted.map(i => ({
        id: i.id,
        title: i.title,
        file_id: i.file_id,
        configured_size: i.configured_size,
        configured_tier: i.configured_tier,
        configured_mount_key: i.configured_mount_key,
        configured_quantity: i.configured_quantity ?? 1,
        gallery_discount_pct: i.gallery_discount_pct ?? 15,
        allow_customization_unlock: i.allow_customization_unlock ?? true
      }))
    });
  } catch (e) {
    return Response.json({ error: e?.message ?? "Unknown error", stack: e?.stack }, { status: 500 });
  }
});