import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { input_file_id, input_filename, input_mime_type, input_byte_size, input_notes } = await req.json();
    
    if (!input_file_id || !input_filename) {
      return Response.json({ error: 'input_file_id and input_filename required' }, { status: 400 });
    }

    const job = await base44.asServiceRole.entities.AIAnalysisJob.create({
      order_id: null,
      order_item_id: null,
      client_id: null,
      status: 'QUEUED',
      requested_by_user_id: user.id,
      requested_by_email: user.email,
      is_ad_hoc: true,
      input_file_id,
      input_filename,
      input_mime_type: input_mime_type || null,
      input_byte_size: input_byte_size || null,
      input_notes: input_notes || null,
      input_snapshot: { is_ad_hoc: true, filename: input_filename }
    });

    return Response.json({ ok: true, job });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});