import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { orderItemId, pressSettings, materialsUsed, environmentNotes, observations } = await req.json();
    if (!orderItemId || !observations) {
      return Response.json({ error: 'orderItemId and observations required' }, { status: 400 });
    }

    // Create print log
    const printLog = await base44.asServiceRole.entities.PrintLog.create({
      order_item_id: orderItemId,
      press_settings: pressSettings || {},
      materials_used: materialsUsed || '',
      environment_notes: environmentNotes || null,
      observations: observations,
      created_by_user_id: user.id,
    });

    // Audit log
    await base44.asServiceRole.entities.AuditLog.create({
      entity_type: 'PrintLog',
      entity_id: printLog.id,
      action: 'print_log_created',
      user_id: user.id,
      after_state: { order_item_id: orderItemId },
      notes: 'Admin created print log entry',
    });

    return Response.json({ success: true, print_log_id: printLog.id });
  } catch (error) {
    console.error('Create print log error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});