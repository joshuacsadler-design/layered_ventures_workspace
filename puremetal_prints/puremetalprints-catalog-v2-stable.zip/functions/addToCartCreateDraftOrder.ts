import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Authentication required' }, { status: 401 });
    }

    const body = await req.json();
    const { productId, variantKey, quantity = 1, imageUrl, originalFilename } = body;

    if (!productId || !variantKey) {
      return Response.json({ error: 'productId and variantKey required' }, { status: 400 });
    }

    // Get or create Client
    let clients = await base44.entities.Client.filter({ user_id: user.id });
    let client = clients[0];
    if (!client) {
      client = await base44.entities.Client.create({
        user_id: user.id,
        full_name: user.full_name,
        email: user.email,
      });
    }

    // Get or create Draft Order
    let orders = await base44.entities.Order.filter({ user_id: user.id, status: 'Draft' });
    let order = orders[0];
    if (!order) {
      order = await base44.entities.Order.create({
        order_number: `PM-${Date.now()}`,
        client: client.id,
        user_id: user.id,
        status: 'Draft',
        subtotal: 0,
        shipping: 0,
        tax: 0,
        total: 0,
      });
    }

    // Get product and price
    const product = await base44.entities.Product.get(productId);
    const prices = await base44.entities.ProductPrice.filter({ product: productId, variant_key: variantKey, active: true });
    const price = prices[0];

    if (!product || !price) {
      return Response.json({ error: 'Product or price not found' }, { status: 404 });
    }

    // Create order item
    const orderItem = await base44.entities.OrderItem.create({
      order: order.id,
      product: product.id,
      sku: product.sku,
      type: product.type,
      title: product.name,
      quantity,
      unit_price: price.price,
      size: price.size || null,
      material: price.material || null,
      image_url: imageUrl || null,
      original_filename: originalFilename || null,
    });

    // Recalculate order totals
    const allItems = await base44.entities.OrderItem.filter({ order: order.id });
    const subtotal = allItems.reduce((sum, item) => sum + (item.unit_price * item.quantity), 0);

    await base44.entities.Order.update(order.id, {
      subtotal,
      total: subtotal, // shipping/tax calculated later
    });

    // Get cart count
    const cartCount = allItems.reduce((sum, item) => sum + item.quantity, 0);

    return Response.json({
      success: true,
      orderId: order.id,
      orderItemId: orderItem.id,
      cartCount,
    });
  } catch (error) {
    console.error('Add to cart error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});