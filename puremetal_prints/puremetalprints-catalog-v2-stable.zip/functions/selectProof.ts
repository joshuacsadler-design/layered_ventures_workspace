import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Authentication required' }, { status: 401 });
    }

    const { orderId, proofId } = await req.json();
    if (!orderId || !proofId) {
      return Response.json({ error: 'orderId and proofId required' }, { status: 400 });
    }

    // Verify ownership
    const orders = await base44.entities.Order.filter({ id: orderId, user_id: user.id });
    if (orders.length === 0) {
      return Response.json({ error: 'Order not found' }, { status: 404 });
    }

    const order = orders[0];

    // Get proof
    const proofs = await base44.entities.Proof.filter({ id: proofId, order_item_id: { $exists: true } });
    if (proofs.length === 0) {
      return Response.json({ error: 'Proof not found' }, { status: 404 });
    }

    const proof = proofs[0];

    // Check if proof is delivered
    if (!proof.is_delivered) {
      return Response.json({ error: 'Proof not yet delivered by admin' }, { status: 400 });
    }

    // Clear all other selections for this order item (use service role after ownership check)
    const allProofs = await base44.asServiceRole.entities.Proof.filter({ order_item_id: proof.order_item_id });
    for (const p of allProofs) {
      if (p.id !== proofId && p.is_selected) {
        await base44.asServiceRole.entities.Proof.update(p.id, { is_selected: false });
      }
    }

    // Select this proof
    await base44.asServiceRole.entities.Proof.update(proofId, { is_selected: true });

    // Update order status to PROOF_SELECTED
    await base44.asServiceRole.entities.Order.update(orderId, { status: 'PROOF_SELECTED' });

    // Audit log
    await base44.asServiceRole.entities.AuditLog.create({
      entity_type: 'Order',
      entity_id: orderId,
      action: 'proof_selected',
      user_id: user.id,
      after_state: { proof_id: proofId },
      notes: 'Client selected proof',
    });

    return Response.json({ success: true });
  } catch (error) {
    console.error('Select proof error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});