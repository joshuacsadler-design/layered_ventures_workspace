import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { id, patch } = await req.json();
    if (!id || !patch) {
      return Response.json({ error: 'Missing id or patch' }, { status: 400 });
    }

    const mount = await base44.asServiceRole.entities.MountOffering.update(id, patch);
    
    // Sync linked product if exists
    if (mount.standalone_sellable) {
      const product = (await base44.asServiceRole.entities.Product.filter({ mount_key: mount.key }))[0];
      if (product) {
        await base44.asServiceRole.entities.Product.update(product.id, {
          in_stock: mount.in_stock,
          stock_mode: mount.stock_mode,
          active: mount.active
        });
      }
    }

    return Response.json({ success: true, mount });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});