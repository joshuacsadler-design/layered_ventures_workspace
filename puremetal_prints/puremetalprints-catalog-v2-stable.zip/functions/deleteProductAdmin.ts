import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { product_id } = await req.json();
    if (!product_id) {
      return Response.json({ error: 'product_id required' }, { status: 400 });
    }

    const products = await base44.asServiceRole.entities.Product.filter({ id: product_id });
    const product = products[0];
    if (!product) {
      return Response.json({ error: 'Product not found' }, { status: 404 });
    }

    // Protect main print product
    if (product.type === 'print' && product.sku === 'PM-METAL') {
      return Response.json({ error: 'The main print product cannot be deleted. Disable sizes instead.' }, { status: 400 });
    }

    // Archive product
    await base44.asServiceRole.entities.Product.update(product_id, {
      active: false,
      show_in_shop: false
    });

    // Archive all associated prices
    const prices = await base44.asServiceRole.entities.ProductPrice.filter({ product_id });
    for (const price of prices) {
      await base44.asServiceRole.entities.ProductPrice.update(price.id, {
        active: false
      });
    }

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});