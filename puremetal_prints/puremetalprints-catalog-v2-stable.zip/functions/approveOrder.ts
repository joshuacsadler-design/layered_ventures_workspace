import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Authentication required' }, { status: 401 });
    }

    const { orderId } = await req.json();
    if (!orderId) {
      return Response.json({ error: 'orderId required' }, { status: 400 });
    }

    // Verify ownership
    const orders = await base44.entities.Order.filter({ id: orderId, user_id: user.id });
    if (orders.length === 0) {
      return Response.json({ error: 'Order not found' }, { status: 404 });
    }

    const order = orders[0];

    // Verify proof is selected
    const items = await base44.entities.OrderItem.filter({ order_id: orderId });
    for (const item of items) {
      const proofs = await base44.entities.Proof.filter({ order_item_id: item.id, is_selected: true });
      if (proofs.length === 0) {
        return Response.json({ 
          error: 'All items must have a selected proof before approval' 
        }, { status: 400 });
      }
    }

    // Update order status to APPROVED (does NOT start production)
    await base44.asServiceRole.entities.Order.update(orderId, { status: 'APPROVED' });

    // Update all items to APPROVED
    for (const item of items) {
      await base44.asServiceRole.entities.OrderItem.update(item.id, { status: 'APPROVED' });
    }

    // Audit log
    await base44.asServiceRole.entities.AuditLog.create({
      entity_type: 'Order',
      entity_id: orderId,
      action: 'client_approval',
      user_id: user.id,
      before_state: { status: order.status },
      after_state: { status: 'APPROVED' },
      notes: 'Client approved order - awaiting admin production start',
    });

    // Notify admin
    await base44.asServiceRole.integrations.Core.SendEmail({
      to: 'admin@puremetalprints.pro',
      subject: `Order ${order.order_number} Approved by Client`,
      body: `Client ${user.full_name} has approved order ${order.order_number}.\n\nOrder is ready for production.`,
    });

    return Response.json({ success: true, message: 'Order approved - admin will start production' });
  } catch (error) {
    console.error('Approve order error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});