import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const jobs = await base44.asServiceRole.entities.AIAnalysisJob.filter(
      { is_ad_hoc: true },
      '-created_date',
      50
    );

    const jobIds = jobs.map(j => j.id);
    const results = jobIds.length > 0
      ? await base44.asServiceRole.entities.AIAnalysisResult.filter({ 
          analysis_job_id: { $in: jobIds } 
        })
      : [];

    const enrichedJobs = jobs.map(job => ({
      ...job,
      latest_result: results.find(r => r.analysis_job_id === job.id) || null
    }));

    return Response.json({ 
      jobs: enrichedJobs,
      total: enrichedJobs.length 
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});