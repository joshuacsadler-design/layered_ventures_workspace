import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

const VALID_TRANSITIONS = {
  DRAFT: ['UPLOADED', 'CANCELLED'],
  UPLOADED: ['NEEDS_REVIEW', 'CANCELLED'],
  NEEDS_REVIEW: ['PROOF_DELIVERED', 'CANCELLED'],
  PROOF_DELIVERED: ['PROOF_SELECTED', 'NEEDS_REVIEW'],
  PROOF_SELECTED: ['APPROVED', 'NEEDS_REVIEW'],
  APPROVED: ['IN_PRODUCTION'],
  IN_PRODUCTION: ['COMPLETED'],
  COMPLETED: [],
  CANCELLATION_REQUESTED: ['CANCELLED', 'NEEDS_REVIEW'],
  CANCELLED: [],
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { orderId, newStatus } = await req.json();
    if (!orderId || !newStatus) {
      return Response.json({ error: 'orderId and newStatus required' }, { status: 400 });
    }

    // Get order
    const orders = await base44.asServiceRole.entities.Order.filter({ id: orderId });
    if (orders.length === 0) {
      return Response.json({ error: 'Order not found' }, { status: 404 });
    }

    const order = orders[0];

    // Validate state transition
    const allowedTransitions = VALID_TRANSITIONS[order.status] || [];
    if (!allowedTransitions.includes(newStatus)) {
      return Response.json({ 
        error: `Invalid transition from ${order.status} to ${newStatus}`,
        allowed: allowedTransitions,
      }, { status: 400 });
    }

    // PRODUCTION START GATE: Enforce strict validation
    if (newStatus === 'IN_PRODUCTION') {
      const items = await base44.asServiceRole.entities.OrderItem.filter({ order_id: orderId });
      
      const violations = [];
      
      for (const item of items) {
        // Check 1: Item must be APPROVED
        if (item.status !== 'APPROVED') {
          violations.push(`Item ${item.title} is not approved (status: ${item.status})`);
        }
        
        // Check 2: Item must have selected proof
        const proofs = await base44.asServiceRole.entities.Proof.filter({ 
          order_item_id: item.id, 
          is_selected: true 
        });
        if (proofs.length === 0) {
          violations.push(`Item ${item.title} has no selected proof`);
        }
        
        // Check 3: Item must have PRINT_READY file
        const files = await base44.asServiceRole.entities.File.filter({ 
          order_item_id: item.id, 
          kind: 'PRINT_READY' 
        });
        if (files.length === 0) {
          violations.push(`Item ${item.title} has no print-ready file`);
        }
      }
      
      if (violations.length > 0) {
        return Response.json({ 
          error: 'Cannot start production - validation failed',
          violations: violations,
        }, { status: 400 });
      }

      // All checks passed - lock all items and trigger notifications
      for (const item of items) {
        await base44.asServiceRole.entities.OrderItem.update(item.id, {
          status: 'IN_PRODUCTION',
          cancellation_locked: true,
        });
      }

      // Send production started notification
      const clients = await base44.asServiceRole.entities.Client.filter({ id: order.client_id });
      if (clients.length > 0) {
        const client = clients[0];
        await base44.functions.invoke('sendNotification', {
          recipientEmail: client.email,
          recipientName: client.full_name,
          notificationType: 'PRODUCTION_STARTED',
          data: { orderNumber: order.order_number },
        });
      }
    }

    // Update order status
    await base44.asServiceRole.entities.Order.update(orderId, { status: newStatus });

    // Audit log
    await base44.functions.invoke('logAudit', {
      action: 'ORDER_STATUS_UPDATED',
      entity_type: 'Order',
      entity_id: orderId,
      user_id: user.id,
      before_state: { status: order.status },
      after_state: { status: newStatus },
      notes: `Admin updated order status from ${order.status} to ${newStatus}`,
    });

    return Response.json({ success: true });
  } catch (error) {
    console.error('Update order status error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});