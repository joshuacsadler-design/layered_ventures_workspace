import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const summary = { created: 0, updated: 0, skipped: 0 };
    const offerings = await base44.asServiceRole.entities.MountOffering.list();

    for (const offering of offerings) {
      if (!offering.standalone_sellable) {
        summary.skipped++;
        continue;
      }

      const mountSku = `PM-MOUNT-${offering.key}`;
      let product = (await base44.asServiceRole.entities.Product.filter({ mount_key: offering.key }))[0];

      if (!product) {
        await base44.asServiceRole.entities.Product.create({
          sku: mountSku,
          name: offering.label,
          type: 'mount',
          mount_key: offering.key,
          purchase_flow: 'DIRECT_CART',
          active: offering.active,
          show_in_shop: offering.active,
          in_stock: offering.in_stock,
          stock_mode: offering.stock_mode,
          image_file_id: offering.image_file_id,
          description: offering.description,
          shop_sort_order: 100
        });
        summary.created++;
      } else {
        await base44.asServiceRole.entities.Product.update(product.id, {
          name: offering.label,
          in_stock: offering.in_stock,
          stock_mode: offering.stock_mode,
          active: offering.active,
          image_file_id: offering.image_file_id,
          description: offering.description
        });
        summary.updated++;
      }
    }

    return Response.json({ success: true, summary });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});