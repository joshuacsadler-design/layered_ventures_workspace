import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { analysis_job_id } = await req.json();
    
    if (!analysis_job_id) {
      return Response.json({ error: 'analysis_job_id required' }, { status: 400 });
    }

    const jobs = await base44.asServiceRole.entities.AIAnalysisJob.filter({ id: analysis_job_id, is_ad_hoc: true });
    const job = jobs[0];
    
    if (!job) {
      return Response.json({ error: 'Ad-hoc job not found' }, { status: 404 });
    }

    const now = new Date().toISOString();
    await base44.asServiceRole.entities.AIAnalysisJob.update(job.id, {
      status: 'RUNNING',
      started_at: now
    });

    const findings = [];
    const recommendations = [];
    let verdict = 'OK';

    if (!job.input_file_id) {
      verdict = 'FAIL';
      findings.push('No file uploaded');
    } else {
      findings.push(`File uploaded and queued for manual review: ${job.input_filename}`);
    }

    recommendations.push('Check DPI against target size before production');
    recommendations.push('Confirm crop/bleed margins');
    recommendations.push('Confirm color curve for gloss metal');

    const details_json = {
      file_metadata: {
        file_id: job.input_file_id,
        filename: job.input_filename,
        mime_type: job.input_mime_type,
        byte_size: job.input_byte_size
      },
      notes: job.input_notes,
      analyzer_version: 'manual-v1-adhoc'
    };

    const result = await base44.asServiceRole.entities.AIAnalysisResult.create({
      order_item_id: null,
      analysis_job_id: job.id,
      verdict,
      findings,
      recommendations,
      details_json
    });

    const output_summary = `Ad-hoc analysis complete: ${verdict} - ${findings.length} finding(s)`;
    const output_json = { verdict, findings, recommendations, details_json };

    await base44.asServiceRole.entities.AIAnalysisJob.update(job.id, {
      status: 'COMPLETED',
      completed_at: new Date().toISOString(),
      output_summary,
      output_json
    });

    return Response.json({ 
      ok: true, 
      job: { ...job, status: 'COMPLETED', completed_at: new Date().toISOString(), output_summary, output_json },
      result 
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});