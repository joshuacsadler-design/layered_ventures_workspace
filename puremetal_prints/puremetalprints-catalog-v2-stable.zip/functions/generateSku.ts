import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

function slugify(text, maxLength = 14) {
  return text
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, '')
    .substring(0, maxLength);
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { category, name } = await req.json();

    if (!category || !name) {
      return Response.json({ error: 'category and name are required' }, { status: 400 });
    }

    const slug = slugify(name);
    let sequence = 1;
    let productSku;
    let exists = true;

    // Find unique SKU by incrementing sequence
    while (exists && sequence < 1000) {
      const seqStr = String(sequence).padStart(3, '0');
      productSku = `PM-${category}-${slug}-${seqStr}`;
      
      const products = await base44.asServiceRole.entities.Product.filter({ sku: productSku });
      exists = products.length > 0;
      
      if (exists) {
        sequence++;
      }
    }

    if (exists) {
      return Response.json({ error: 'Could not generate unique SKU' }, { status: 500 });
    }

    return Response.json({
      productSku,
      slugUsed: slug,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});