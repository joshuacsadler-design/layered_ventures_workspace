// INTERNAL CATALOG HELPERS (NOT CALLABLE AS HTTP ENDPOINTS)
// This file exports helpers for use by other backend functions only
// DO NOT add Deno.serve() - this is a library module, not an endpoint

/**
 * Ensures default mount offerings exist
 * Uses service role - no auth checks (called from authorized contexts only)
 */
export async function ensureMountDefaultsSR(base44) {
  const DEFAULTS = [
    { key: 'PURESHADOW_NONE', label: 'Print Only (No Mount)', sort_order: 0, price_addon: 0 },
    { key: 'PURESHADOW_FLOAT', label: 'Pure Shadow Float Mount', sort_order: 1, price_addon: 60 },
    { key: 'PURESHADOW_MAGNETIC', label: 'Pure Shadow Magnetic', sort_order: 2, price_addon: 45 },
    { key: 'PURESHADOW_STANDOFF', label: 'Pure Shadow Standoff', sort_order: 3, price_addon: 50 },
  ];

  const created = [];
  const skipped = [];

  for (const def of DEFAULTS) {
    const existing = await base44.asServiceRole.entities.MountOffering.filter({ key: def.key });
    if (existing.length > 0) {
      skipped.push(def.key);
      continue;
    }

    const skuData = await reserveSequentialSkuSR(base44, {
      namespace: `SKU:PM-MOUNT:${def.key}`,
      entity_type: 'MountOffering',
    });

    await base44.asServiceRole.entities.MountOffering.create({
      key: def.key,
      sku: skuData.sku,
      label: def.label,
      sort_order: def.sort_order,
      price_addon: def.price_addon,
      active: true,
    });

    created.push(def.key);
  }

  return { created, skipped };
}

/**
 * Reserves a sequential SKU for a given namespace
 * Uses service role - no auth checks (called from authorized contexts only)
 */
export async function reserveSequentialSkuSR(base44, { namespace, entity_type, category, slug }) {
  // Support both new (namespace) and legacy (category) interfaces
  const actualNamespace = namespace || `SKU:${category}:${slug}`;
  
  if (!actualNamespace) {
    throw new Error('namespace is required');
  }

  let registry = await base44.asServiceRole.entities.CodeRegistry.filter({ namespace: actualNamespace });
  
  if (registry.length === 0) {
    registry = [await base44.asServiceRole.entities.CodeRegistry.create({
      namespace: actualNamespace,
      next_seq: 1,
    })];
  }

  const seq = registry[0].next_seq;
  await base44.asServiceRole.entities.CodeRegistry.update(registry[0].id, {
    next_seq: seq + 1,
  });

  const parts = actualNamespace.split(':');
  const prefix = parts[1] || category || 'PM';
  
  const sku = `${prefix}-${seq.toString().padStart(3, '0')}`;

  await base44.asServiceRole.entities.CodeReservation.create({
    code: sku,
    type: 'SKU',
    namespace: actualNamespace,
    meta: { entity_type: entity_type || 'Unknown', seq },
  });

  return { sku };
}

/**
 * Reserves a random unique coupon code
 * Uses service role - no auth checks (called from authorized contexts only)
 */
export async function reserveRandomCouponCodeSR(base44, { discount_type }) {
  if (!discount_type) {
    throw new Error('discount_type is required');
  }

  const prefixMap = {
    'PERCENT': 'PM-PCT-',
    'AMOUNT': 'PM-AMT-',
    'FREE_SHIPPING': 'PM-SHIP-',
  };

  const prefix = prefixMap[discount_type] || 'PM-';
  const namespace = `COUPON:${prefix}`;

  let attempts = 0;
  let code = null;

  while (!code && attempts < 100) {
    const token = randomToken(8);
    const candidate = prefix + token;

    const existing = await base44.asServiceRole.entities.CodeReservation.filter({ code: candidate });
    if (existing.length === 0) {
      await base44.asServiceRole.entities.CodeReservation.create({
        code: candidate,
        type: 'COUPON',
        namespace,
      });
      code = candidate;
    }

    attempts++;
  }

  if (!code) {
    throw new Error('Failed to generate unique coupon code');
  }

  return { code };
}

/**
 * Logs an audit entry
 * Uses service role - no auth checks (called from authorized contexts only)
 */
export async function logAuditSR(base44, { entity_type, entity_id, action, user_id, before_state, after_state, notes }) {
  await base44.asServiceRole.entities.AuditLog.create({
    entity_type: entity_type || 'Unknown',
    entity_id: entity_id || null,
    action: action || 'UPDATE',
    user_id: user_id || null,
    before_state: before_state || null,
    after_state: after_state || null,
    notes: notes || '',
    timestamp: new Date().toISOString(),
  });

  return { ok: true };
}

function randomToken(length = 8) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}