import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { orderItemId, notes, rating, printerProfile, settingsJson, size, material, photoFiles } = await req.json();

    if (!orderItemId) {
      return Response.json({ error: 'Missing orderItemId' }, { status: 400 });
    }

    // Get item to extract size and material if not provided
    const items = await base44.asServiceRole.entities.OrderItem.filter({ id: orderItemId });
    if (items.length === 0) {
      return Response.json({ error: 'Order item not found' }, { status: 404 });
    }
    const item = items[0];

    // Create print log
    const printLog = await base44.asServiceRole.entities.PrintLog.create({
      order_item: orderItemId,
      size: size || item.size || '',
      material: material || item.material || '',
      printer_profile: printerProfile || null,
      settings_json: settingsJson || {},
      result_notes: notes || '',
      rating: rating || null,
      created_by_user_id: user.id,
    });

    // Create photo records if provided (photoFiles should be array of URLs from prior uploads)
    if (photoFiles && Array.isArray(photoFiles) && photoFiles.length > 0) {
      for (const photoUrl of photoFiles) {
        await base44.asServiceRole.entities.PrintLogPhoto.create({
          print_log_id: printLog.id,
          file_url: photoUrl,
          caption: null,
        });
      }
    }

    // Log audit
    await base44.functions.invoke('logAudit', {
      action: 'PRINT_LOG_ADDED',
      entity_type: 'PrintLog',
      entity_id: printLog.id,
      details: { order_item_id: orderItemId },
    });

    return Response.json({ success: true, log_id: printLog.id });
  } catch (error) {
    console.error('Error adding print log:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});