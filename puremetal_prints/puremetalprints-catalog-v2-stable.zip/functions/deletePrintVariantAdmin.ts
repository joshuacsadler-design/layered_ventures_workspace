import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { print_variant_id } = await req.json();
    if (!print_variant_id) {
      return Response.json({ error: 'print_variant_id required' }, { status: 400 });
    }

    await base44.asServiceRole.entities.PrintVariant.update(print_variant_id, {
      active: false,
      show_in_shop: false,
      in_stock: false
    });

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});