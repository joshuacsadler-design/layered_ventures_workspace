import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const body = await req.json();
    const { 
      id, 
      product_id, 
      size, 
      standard_price_dollars, 
      reserve_enabled, 
      reserve_price_dollars, 
      show_reserve_upsell, 
      active, 
      show_in_shop, 
      in_stock, 
      stock_mode, 
      sort_order 
    } = body;

    // Convert dollars to cents
    const standard_price_cents = Math.round((standard_price_dollars || 0) * 100);
    let reserve_price_cents = null;
    
    if (reserve_enabled) {
      if (!reserve_price_dollars || reserve_price_dollars <= 0) {
        return Response.json({ error: 'Reserve price required when reserve enabled' }, { status: 400 });
      }
      reserve_price_cents = Math.round(reserve_price_dollars * 100);
    }

    const data = {
      product_id,
      size,
      standard_price_cents,
      reserve_enabled: !!reserve_enabled,
      reserve_price_cents,
      show_reserve_upsell: reserve_enabled ? !!show_reserve_upsell : false,
      active: active !== false,
      show_in_shop: show_in_shop !== false,
      in_stock: in_stock !== false,
      stock_mode: stock_mode || 'HIDE',
      sort_order: sort_order || 0
    };

    let variant;
    if (id) {
      variant = await base44.asServiceRole.entities.PrintVariant.update(id, data);
    } else {
      variant = await base44.asServiceRole.entities.PrintVariant.create(data);
    }

    return Response.json({ success: true, variant });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});