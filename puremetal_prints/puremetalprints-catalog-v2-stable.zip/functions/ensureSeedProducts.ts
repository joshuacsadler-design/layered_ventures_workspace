import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== "admin") return Response.json({ error: "Forbidden" }, { status: 403 });

    const sku = "PM-METAL";
    const existing = await base44.asServiceRole.entities.Product.filter({ sku });
    const product =
      existing[0] ??
      (await base44.asServiceRole.entities.Product.create({
        sku,
        name: "Metal Print",
        type: "print",
        active: true,
        show_in_shop: true,
        shop_sort_order: 0,
        short_description: "Infused dye-sublimation aluminum print.",
        description: "Upload your image, choose size and mount, and we'll infuse it onto premium aluminum."
      }));

    const desiredVariants = [
      { size: "6x8",  standard_price: 20, reserve_enabled: false, reserve_price: null, reserve_upsell_enabled: true, sort_order: 0 },
      { size: "8x10", standard_price: 30, reserve_enabled: false, reserve_price: null, reserve_upsell_enabled: true, sort_order: 1 },
      { size: "8x12", standard_price: 40, reserve_enabled: true,  reserve_price: 60,   reserve_upsell_enabled: true, sort_order: 2 },
    ];

    const existingVariants = await base44.asServiceRole.entities.PrintVariant.filter({ product_id: product.id });
    const allowedSizes = new Set(desiredVariants.map(v => v.size));

    for (const v of existingVariants) {
      if (!allowedSizes.has(v.size) && v.active) {
        await base44.asServiceRole.entities.PrintVariant.update(v.id, { active: false });
      }
    }

    for (const dv of desiredVariants) {
      const found = await base44.asServiceRole.entities.PrintVariant.filter({ product_id: product.id, size: dv.size });
      if (found[0]) {
        await base44.asServiceRole.entities.PrintVariant.update(found[0].id, { ...dv, active: true });
      } else {
        await base44.asServiceRole.entities.PrintVariant.create({ product_id: product.id, ...dv, active: true });
      }
    }

    const desiredMounts = [
      { key: "PRINT_ONLY", label: "Print Only", standalone_price: 0,  sort_order: 0, active: true, description: "No mount. Print only." },
      { key: "PURESHADOW_STD", label: "PureShadow (Standard)", standalone_price: 7, sort_order: 1, active: true, description: "Standard PureShadow mount." },
      { key: "PURESHADOW_BLACK_MAG", label: "PureShadow Black (Magnetic)", standalone_price: 10, sort_order: 2, active: true, description: "Black magnetic PureShadow mount." },
    ];
    const allowedKeys = new Set(desiredMounts.map(m => m.key));
    const existingMounts = await base44.asServiceRole.entities.MountOffering.list();

    for (const m of existingMounts) {
      if (!allowedKeys.has(m.key) && m.active) {
        await base44.asServiceRole.entities.MountOffering.update(m.id, { active: false });
      }
    }

    for (const dm of desiredMounts) {
      const found = await base44.asServiceRole.entities.MountOffering.filter({ key: dm.key });
      if (found[0]) {
        await base44.asServiceRole.entities.MountOffering.update(found[0].id, dm);
      } else {
        await base44.asServiceRole.entities.MountOffering.create(dm);
      }
    }

    return Response.json({ ok: true, product_id: product.id });
  } catch (e) {
    return Response.json({ error: e?.message ?? "Unknown error", stack: e?.stack }, { status: 500 });
  }
});