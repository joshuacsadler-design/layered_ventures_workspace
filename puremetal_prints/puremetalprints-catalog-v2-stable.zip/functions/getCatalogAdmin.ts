import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const allProducts = await base44.asServiceRole.entities.Product.list('-shop_sort_order');
    
    // Filter out archived legacy print products
    const products = allProducts.filter(p => {
      if (p.type === 'print' && p.sku !== 'PM-METAL') return false;
      return true;
    });
    
    const printProduct = products.find(p => p.type === 'print' && p.sku === 'PM-METAL') || null;
    
    let printVariants = [];
    if (printProduct) {
      printVariants = await base44.asServiceRole.entities.PrintVariant.filter({ product_id: printProduct.id });
      printVariants.sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));
    }

    const mounts = await base44.asServiceRole.entities.MountOffering.list('sort_order');
    
    const services = products.filter(p => p.type === 'service');
    
    const allPrices = await base44.asServiceRole.entities.ProductPrice.list('sort_order');
    const productPrices = allPrices;

    // Build service prices map
    const servicePricesByProductId = {};
    for (const price of allPrices) {
      const product = products.find(p => p.id === price.product_id);
      if (product && product.type === 'service') {
        if (!servicePricesByProductId[price.product_id]) {
          servicePricesByProductId[price.product_id] = [];
        }
        servicePricesByProductId[price.product_id].push(price);
      }
    }

    return Response.json({
      products,
      printProduct,
      printVariants,
      mounts,
      services,
      productPrices,
      servicePricesByProductId
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});