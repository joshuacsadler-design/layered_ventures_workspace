import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const { kind, product_id, quantity } = body || {};
    const qty = Math.max(1, Number(quantity || 1));

    // Ensure draft order
    let draftOrders = await base44.asServiceRole.entities.Order.filter({ user_id: user.id, status: "DRAFT" });
    let order = draftOrders[0];
    if (!order) {
      order = await base44.asServiceRole.entities.Order.create({
        user_id: user.id,
        status: "DRAFT",
        subtotal: 0,
        tax: 0,
        shipping: 0,
        total: 0,
      });
    }

    // PRINT ADD (from Customizer)
    if (kind === "print") {
      const { size, tier, mount_key, gallery_image_id, gallery_pricing_applied } = body;

      if (!product_id || !size || !tier || !mount_key) {
        return Response.json({ error: "product_id, size, tier, mount_key required for print" }, { status: 400 });
      }

      const products = await base44.asServiceRole.entities.Product.filter({ id: product_id });
      const product = products[0];
      if (!product || product.type !== "print" || product.purchase_flow !== "CUSTOMIZER") {
        return Response.json({ error: "Invalid product for print add" }, { status: 400 });
      }
      if (!product.active || !product.show_in_shop) {
        return Response.json({ error: "Product not available" }, { status: 409 });
      }

      const variants = await base44.asServiceRole.entities.PrintVariant.filter({ product_id, size });
      const variant = variants[0];
      if (!variant || !variant.active || !variant.show_in_shop || !variant.in_stock) {
        return Response.json({ error: "Size temporarily unavailable." }, { status: 409 });
      }

      // Get price in cents (support both old standard_price and new standard_price_cents)
      let unit_price_cents = variant.standard_price_cents ?? (variant.standard_price ? Math.round(variant.standard_price * 100) : null);
      let effective_tier = "standard";

      if (!unit_price_cents) {
        return Response.json({ error: "Price not configured for this size" }, { status: 500 });
      }

      if (tier === "reserve") {
        const reserve_price_cents = variant.reserve_price_cents ?? (variant.reserve_price ? Math.round(variant.reserve_price * 100) : null);
        if (!variant.reserve_enabled || !reserve_price_cents) {
          return Response.json({ error: "Reserve not available for this size" }, { status: 400 });
        }
        unit_price_cents = reserve_price_cents;
        effective_tier = "reserve";
      }

      const mounts = await base44.asServiceRole.entities.MountOffering.filter({ key: mount_key });
      const mount = mounts[0];
      if (!mount || !mount.active || !mount.included_with_prints || !mount.in_stock) {
        return Response.json({ error: "Mount temporarily unavailable." }, { status: 409 });
      }

      let final_unit_price_cents = unit_price_cents;
      let pricing_source = "STANDARD";
      let discount_pct = null;
      let gallery_id = null;

      // GALLERY PRICING
      if (gallery_pricing_applied && gallery_image_id) {
        const galleryItems = await base44.asServiceRole.entities.GalleryImage.filter({ id: gallery_image_id });
        const galleryItem = galleryItems[0];

        if (!galleryItem || !galleryItem.is_active) {
          return Response.json({ error: "Gallery item not found or inactive" }, { status: 404 });
        }

        if (
          galleryItem.configured_size !== size ||
          galleryItem.configured_tier !== tier ||
          galleryItem.configured_mount_key !== mount_key ||
          (galleryItem.configured_quantity ?? 1) !== qty
        ) {
          return Response.json({ error: "Gallery pricing only valid for the original configuration" }, { status: 400 });
        }

        discount_pct = galleryItem.gallery_discount_pct ?? 15;
        const discount_multiplier = 1 - (discount_pct / 100);
        final_unit_price_cents = Math.round(unit_price_cents * discount_multiplier);
        pricing_source = "GALLERY";
        gallery_id = gallery_image_id;
      }

      const line_total_cents = final_unit_price_cents * qty;

      const item = await base44.asServiceRole.entities.OrderItem.create({
        order_id: order.id,
        kind: "print",
        product_id: product.id,
        print_variant_id: variant.id,
        sku: product.sku,
        title: product.name,
        quantity: qty,
        unit_price_cents: final_unit_price_cents,
        line_total_cents,
        size,
        tier: effective_tier,
        mount_key,
        gallery_image_id: gallery_id,
        gallery_pricing_applied: !!gallery_pricing_applied,
        gallery_discount_pct: discount_pct,
        pricing_source,
        status: "PENDING",
      });

      return Response.json({ ok: true, order_id: order.id, order_item_id: item.id });
    }

    // NON-PRINT ADD (from Shop direct)
    if (kind === "product") {
      const { product_price_id } = body;

      if (!product_id || !product_price_id) {
        return Response.json({ error: "product_id and product_price_id required" }, { status: 400 });
      }

      const products = await base44.asServiceRole.entities.Product.filter({ id: product_id });
      const product = products[0];
      if (!product || product.type === "print") {
        return Response.json({ error: "Invalid product for direct add" }, { status: 400 });
      }
      if (product.purchase_flow !== "DIRECT_CART") {
        return Response.json({ error: "Product must use DIRECT_CART purchase_flow" }, { status: 400 });
      }
      if (!product.active || !product.show_in_shop) {
        return Response.json({ error: "Product not available" }, { status: 409 });
      }
      if (product.in_stock === false) {
        return Response.json({ error: "Temporarily unavailable." }, { status: 409 });
      }

      const prices = await base44.asServiceRole.entities.ProductPrice.filter({ id: product_price_id });
      const productPrice = prices[0];
      if (!productPrice || productPrice.product_id !== product_id) {
        return Response.json({ error: "Invalid price option" }, { status: 400 });
      }
      if (!productPrice.active || !productPrice.in_stock) {
        return Response.json({ error: "Temporarily unavailable." }, { status: 409 });
      }

      const unit_price_cents = productPrice.price_cents;
      
      if (!unit_price_cents && unit_price_cents !== 0) {
        return Response.json({ error: "Price not configured" }, { status: 500 });
      }

      const line_total_cents = unit_price_cents * qty;

      const item = await base44.asServiceRole.entities.OrderItem.create({
        order_id: order.id,
        kind: "product",
        product_id: product.id,
        product_price_id: productPrice.id,
        sku: productPrice.sku,
        title: `${product.name}${productPrice.label ? ` - ${productPrice.label}` : ''}`,
        quantity: qty,
        unit_price_cents,
        line_total_cents,
        status: "PENDING",
      });

      return Response.json({ ok: true, order_id: order.id, order_item_id: item.id });
    }

    // SERVICE ADD
    if (kind === "service") {
      const { product_price_id } = body;

      if (!product_id) {
        return Response.json({ error: "product_id required" }, { status: 400 });
      }

      const products = await base44.asServiceRole.entities.Product.filter({ id: product_id });
      const product = products[0];
      if (!product || product.type !== "service") {
        return Response.json({ error: "Invalid product for service add" }, { status: 400 });
      }
      if (product.purchase_flow !== "DIRECT_CART") {
        return Response.json({ error: "Product must use DIRECT_CART purchase_flow" }, { status: 400 });
      }
      if (!product.active || !product.show_in_shop) {
        return Response.json({ error: "Product not available" }, { status: 409 });
      }
      if (product.in_stock === false) {
        return Response.json({ error: "Temporarily unavailable." }, { status: 409 });
      }

      let unit_price_cents;
      let priceTitle = product.name;

      if (product.tiered_enabled) {
        if (!product_price_id) {
          return Response.json({ error: "product_price_id required for tiered service" }, { status: 400 });
        }
        const prices = await base44.asServiceRole.entities.ProductPrice.filter({ id: product_price_id });
        const productPrice = prices[0];
        if (!productPrice || productPrice.product_id !== product_id) {
          return Response.json({ error: "Invalid price option" }, { status: 400 });
        }
        if (!productPrice.active || !productPrice.in_stock) {
          return Response.json({ error: "Temporarily unavailable." }, { status: 409 });
        }
        unit_price_cents = productPrice.price_cents || productPrice.unit_price_cents;
        if (productPrice.tier_label || productPrice.label) {
          priceTitle = `${product.name} - ${productPrice.tier_label || productPrice.label}`;
        }
      } else {
        if (!product.flat_price_cents || product.flat_price_cents <= 0) {
          return Response.json({ error: "Price not configured" }, { status: 500 });
        }
        unit_price_cents = product.flat_price_cents;
      }

      if (!unit_price_cents && unit_price_cents !== 0) {
        return Response.json({ error: "Price not configured" }, { status: 500 });
      }

      const line_total_cents = unit_price_cents * qty;

      const item = await base44.asServiceRole.entities.OrderItem.create({
        order_id: order.id,
        kind: "service",
        product_id: product.id,
        product_price_id: product_price_id || null,
        sku: product.sku,
        title: priceTitle,
        quantity: qty,
        unit_price_cents,
        line_total_cents,
        status: "PENDING",
      });

      return Response.json({ ok: true, order_id: order.id, order_item_id: item.id });
    }

    return Response.json({ error: "Invalid kind. Must be 'print', 'product', or 'service'" }, { status: 400 });
  } catch (e) {
    return Response.json({ error: e?.message ?? "Unknown error", stack: e?.stack }, { status: 500 });
  }
});