import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const body = await req.json();
    let { type, name, sku, purchase_flow, ...rest } = body;

    // Enforce type-based rules
    if (type === 'print') {
      purchase_flow = 'CUSTOMIZER';
      rest.in_stock = true;
    } else {
      purchase_flow = 'DIRECT_CART';
    }

    // Auto-generate SKU if missing
    if (!sku) {
      const count = (await base44.asServiceRole.entities.Product.list()).length;
      sku = `PM-${type.toUpperCase()}-${String(count + 1).padStart(4, '0')}`;
    }

    const product = await base44.asServiceRole.entities.Product.create({
      sku,
      name: name || 'Untitled Product',
      type,
      purchase_flow,
      active: true,
      show_in_shop: true,
      in_stock: true,
      stock_mode: 'HIDE',
      shop_sort_order: 0,
      ...rest
    });

    return Response.json({ success: true, product });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});