import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Authentication required' }, { status: 401 });
    }

    const { orderId, reason } = await req.json();
    if (!orderId || !reason) {
      return Response.json({ error: 'orderId and reason required' }, { status: 400 });
    }

    // Verify ownership
    const orders = await base44.entities.Order.filter({ id: orderId, user_id: user.id });
    if (orders.length === 0) {
      return Response.json({ error: 'Order not found' }, { status: 404 });
    }

    const order = orders[0];

    // Check for existing pending request (enforce single pending request)
    const existingRequests = await base44.asServiceRole.entities.CancellationRequest.filter({ 
      order_id: orderId, 
      status: 'PENDING' 
    });
    if (existingRequests.length > 0) {
      return Response.json({ 
        error: 'A cancellation request is already pending for this order' 
      }, { status: 400 });
    }

    // Check if any item is in production (cancellation locked)
    const items = await base44.entities.OrderItem.filter({ order_id: orderId });
    const inProduction = items.some(item => item.cancellation_locked || item.status === 'IN_PRODUCTION');

    if (inProduction) {
      return Response.json({ 
        error: 'Order cannot be cancelled - production has already started' 
      }, { status: 400 });
    }

    // Determine if prep fee applies (if status beyond DRAFT)
    const prepFeeApplies = !['DRAFT', 'UPLOADED'].includes(order.status);

    // Create cancellation request
    await base44.asServiceRole.entities.CancellationRequest.create({
      order_id: orderId,
      requested_by_user_id: user.id,
      reason: reason,
      status: 'PENDING',
      prep_fee_applies: prepFeeApplies,
      admin_response: null,
      responded_at: null,
    });

    // Update order status
    await base44.asServiceRole.entities.Order.update(orderId, { status: 'CANCELLATION_REQUESTED' });

    // Audit log
    await base44.functions.invoke('logAudit', {
      action: 'CANCELLATION_REQUESTED',
      entity_type: 'Order',
      entity_id: orderId,
      user_id: user.id,
      before_state: { status: order.status },
      after_state: { status: 'CANCELLATION_REQUESTED', prep_fee_applies: prepFeeApplies },
      notes: `Client requested cancellation: ${reason}`,
    });

    // Notify admin
    await base44.asServiceRole.integrations.Core.SendEmail({
      to: 'admin@puremetalprints.pro',
      subject: `Cancellation Request for Order ${order.order_number}`,
      body: `Client ${user.full_name} has requested cancellation for order ${order.order_number}.

Reason: ${reason}

Prep Fee Applies: ${prepFeeApplies ? 'Yes ($15)' : 'No'}

Please review and respond in the admin portal.`,
    });

    return Response.json({ 
      success: true, 
      prep_fee_applies: prepFeeApplies,
      message: prepFeeApplies 
        ? 'Cancellation request submitted. A $15 prep fee will apply if approved.' 
        : 'Cancellation request submitted.',
    });
  } catch (error) {
    console.error('Request cancellation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});