import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== "admin") return Response.json({ error: "Forbidden" }, { status: 403 });

    const body = await req.json();
    const { id, patch } = body || {};
    if (!id || !patch) return Response.json({ error: "id and patch required" }, { status: 400 });

    // Guard: if reserve_enabled is false, clear reserve_price
    const safePatch = { ...patch };
    if (safePatch.reserve_enabled === false) safePatch.reserve_price = null;

    const updated = await base44.asServiceRole.entities.PrintVariant.update(id, safePatch);
    return Response.json({ ok: true, variant: updated });
  } catch (e) {
    return Response.json({ error: e?.message ?? "Unknown error", stack: e?.stack }, { status: 500 });
  }
});