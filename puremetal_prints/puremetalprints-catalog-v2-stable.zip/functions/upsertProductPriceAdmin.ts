import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const body = await req.json();
    const { id, product_id, sku, label, price_dollars, active, in_stock, stock_mode, sort_order } = body;

    if (!product_id) {
      return Response.json({ error: 'product_id required' }, { status: 400 });
    }

    const price_cents = Math.round((price_dollars || 0) * 100);

    if (id) {
      // Update existing
      const updated = await base44.asServiceRole.entities.ProductPrice.update(id, {
        label,
        price_cents,
        active: active !== undefined ? active : true,
        in_stock: in_stock !== undefined ? in_stock : true,
        stock_mode: stock_mode || 'HIDE',
        sort_order: sort_order || 0
      });
      return Response.json({ success: true, price: updated });
    } else {
      // Create new - check if default already exists
      const existing = await base44.asServiceRole.entities.ProductPrice.filter({ 
        product_id,
        sku: sku || `${product_id}-DEFAULT`
      });

      if (existing.length > 0) {
        // Update the existing one
        const updated = await base44.asServiceRole.entities.ProductPrice.update(existing[0].id, {
          label: label || 'Default',
          price_cents,
          active: true,
          in_stock: true,
          stock_mode: 'HIDE'
        });
        return Response.json({ success: true, price: updated });
      } else {
        // Create new
        const created = await base44.asServiceRole.entities.ProductPrice.create({
          product_id,
          sku: sku || `${product_id}-DEFAULT`,
          label: label || 'Default',
          price_cents,
          active: true,
          in_stock: true,
          stock_mode: 'HIDE',
          sort_order: 0
        });
        return Response.json({ success: true, price: created });
      }
    }
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});