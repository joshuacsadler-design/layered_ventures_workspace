import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { order_item_id } = await req.json();
    
    if (!order_item_id) {
      return Response.json({ error: 'order_item_id required' }, { status: 400 });
    }

    // Update OrderItem to clear analyzer status (don't delete historical data)
    await base44.asServiceRole.entities.OrderItem.update(order_item_id, {
      analyzer_status: 'READY',
      last_analysis_job_id: null,
      last_analysis_result_id: null
    });

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});