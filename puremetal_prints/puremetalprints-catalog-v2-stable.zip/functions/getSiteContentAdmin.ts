import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const siteContent = await base44.asServiceRole.entities.SiteContent.list();
    const contentMap = {};
    siteContent.forEach(sc => {
      contentMap[sc.key] = sc.value;
    });

    const heroImages = await base44.asServiceRole.entities.GalleryImage.filter({ is_active: true });
    heroImages.sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));

    const announcements = await base44.asServiceRole.entities.Announcement.list('-created_date');

    return Response.json({
      siteContent: contentMap,
      heroImages,
      announcements
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});