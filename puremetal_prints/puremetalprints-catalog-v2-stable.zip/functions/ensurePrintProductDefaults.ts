import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import { reserveSequentialSkuSR } from './_internal_catalog.js';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    // Ensure product exists
    const products = await base44.asServiceRole.entities.Product.filter({ type: 'print' });
    let product;

    if (products.length === 0) {
      const skuData = await reserveSequentialSkuSR(base44, {
        category: 'PM-METAL',
        slug: 'METALPRINT',
        entity_type: 'Product',
      });

      product = await base44.asServiceRole.entities.Product.create({
        sku: skuData.sku,
        name: 'Metal Print',
        type: 'print',
        description: 'Premium dye-sublimation aluminum prints by PureMetal.',
        active: true,
      });
    } else {
      product = products[0];
    }

    // Ensure 6 variants
    const variants = [
      { size: '6x8', tier: 'standard', price: 20 },
      { size: '8x10', tier: 'standard', price: 30 },
      { size: '8x12', tier: 'standard', price: 40 },
      { size: '6x8', tier: 'reserve', price: 40 },
      { size: '8x10', tier: 'reserve', price: 50 },
      { size: '8x12', tier: 'reserve', price: 60 },
    ];

    const created = [];
    const updated = [];

    for (const v of variants) {
      const variant_key = `${v.size}-${v.tier}`;
      const existing = await base44.asServiceRole.entities.ProductPrice.filter({
        product_id: product.id,
        variant_key,
      });

      if (existing.length > 0) {
        await base44.asServiceRole.entities.ProductPrice.update(existing[0].id, {
          price: v.price,
          active: true,
        });
        updated.push(variant_key);
      } else {
        const sizeCode = v.size.toUpperCase().replace('x', 'X');
        const tierCode = v.tier === 'standard' ? 'STANDARD' : 'RESERVE';
        const sku = `${product.sku}-${sizeCode}-${tierCode}`;

        await base44.asServiceRole.entities.ProductPrice.create({
          product_id: product.id,
          variant_key,
          sku,
          size: v.size,
          tier: v.tier,
          price: v.price,
          active: true,
        });
        created.push(variant_key);
      }
    }

    return Response.json({
      ok: true,
      product: {
        id: product.id,
        sku: product.sku,
        name: product.name,
      },
      variants: {
        created,
        updated,
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});