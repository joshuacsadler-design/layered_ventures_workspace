import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { itemId, newStatus } = await req.json();

    if (!itemId || !newStatus) {
      return Response.json({ error: 'Missing itemId or newStatus' }, { status: 400 });
    }

    const validStatuses = ['PENDING', 'IN_PROOFING', 'PROOF_DELIVERED', 'APPROVED', 'IN_PRODUCTION', 'COMPLETED'];
    if (!validStatuses.includes(newStatus)) {
      return Response.json({ error: 'Invalid status' }, { status: 400 });
    }

    // Fetch item
    const items = await base44.asServiceRole.entities.OrderItem.filter({ id: itemId });
    if (items.length === 0) {
      return Response.json({ error: 'Item not found' }, { status: 404 });
    }
    const item = items[0];

    // Validation: Cannot move to IN_PRODUCTION without PRINT_READY
    if (newStatus === 'IN_PRODUCTION') {
      const files = await base44.asServiceRole.entities.File.filter({ order_item_id: itemId });
      const hasPrintReady = files.some(f => f.kind === 'PRINT_READY');
      if (!hasPrintReady) {
        return Response.json({ error: 'Cannot start production without PRINT_READY file' }, { status: 400 });
      }
    }

    // Trigger notification when entering production
    if (newStatus === 'IN_PRODUCTION' && item.status !== 'IN_PRODUCTION') {
      // Get order and client for notification
      const orders = await base44.asServiceRole.entities.Order.filter({ id: item.order_id });
      if (orders.length > 0) {
        const order = orders[0];
        const clients = await base44.asServiceRole.entities.Client.filter({ id: order.client_id });
        if (clients.length > 0) {
          const client = clients[0];
          await base44.functions.invoke('sendNotification', {
            recipientEmail: client.email,
            recipientName: client.full_name,
            notificationType: 'PRODUCTION_STARTED',
            data: { orderNumber: order.order_number },
          });
        }
      }
    }

    // Lock cancellation when moving to IN_PRODUCTION
    const cancellationLocked = newStatus === 'IN_PRODUCTION' || newStatus === 'COMPLETED';

    // Update item
    await base44.asServiceRole.entities.OrderItem.update(itemId, {
      status: newStatus,
      cancellation_locked: cancellationLocked,
    });

    // Update order status based on all items
    const allItems = await base44.asServiceRole.entities.OrderItem.filter({ order_id: item.order_id });
    
    let orderStatus = item.order_id;
    if (allItems.every(i => i.id === itemId ? newStatus === 'COMPLETED' : i.status === 'COMPLETED')) {
      // All items completed - order ready for shipping
      orderStatus = 'IN_PRODUCTION'; // Will become COMPLETED after shipping
    } else if (allItems.some(i => i.id === itemId ? newStatus === 'IN_PRODUCTION' : i.status === 'IN_PRODUCTION')) {
      orderStatus = 'IN_PRODUCTION';
    }

    await base44.asServiceRole.entities.Order.update(item.order_id, {
      status: orderStatus,
    });

    // Log audit
    await base44.functions.invoke('logAudit', {
      action: 'ITEM_STATUS_UPDATED',
      entity_type: 'OrderItem',
      entity_id: itemId,
      details: { old_status: item.status, new_status: newStatus },
    });

    return Response.json({ success: true });
  } catch (error) {
    console.error('Error updating item status:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});