import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Authentication required' }, { status: 401 });
    }

    const { orderId, message } = await req.json();
    if (!orderId || !message) {
      return Response.json({ error: 'orderId and message required' }, { status: 400 });
    }

    // Verify ownership
    const orders = await base44.entities.Order.filter({ id: orderId, user_id: user.id });
    if (orders.length === 0) {
      return Response.json({ error: 'Order not found' }, { status: 404 });
    }

    const order = orders[0];

    // Cannot request changes if already in production
    if (order.status === 'IN_PRODUCTION' || order.status === 'COMPLETED') {
      return Response.json({ error: 'Changes cannot be requested after production has started' }, { status: 400 });
    }

    // Reset order status to NEEDS_REVIEW
    await base44.asServiceRole.entities.Order.update(orderId, { 
      status: 'NEEDS_REVIEW',
      notes: (order.notes || '') + `\n\nClient change request: ${message}`,
    });

    // Audit log
    await base44.asServiceRole.entities.AuditLog.create({
      entity_type: 'Order',
      entity_id: orderId,
      action: 'change_request',
      user_id: user.id,
      before_state: { status: order.status },
      after_state: { status: 'NEEDS_REVIEW' },
      notes: `Client requested changes: ${message}`,
    });

    // Notify admin
    await base44.asServiceRole.integrations.Core.SendEmail({
      to: 'admin@puremetalprints.pro',
      subject: `Change Request for Order ${order.order_number}`,
      body: `Client ${user.full_name} has requested changes to order ${order.order_number}.\n\nMessage: ${message}`,
    });

    return Response.json({ success: true });
  } catch (error) {
    console.error('Request changes error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});