import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const allProducts = await base44.asServiceRole.entities.Product.list();
    const legacyPatterns = ['PRINT-', '6x8', '8x10', '8x12', 'Metal Print'];
    
    const legacyProducts = allProducts.filter(p => {
      if (p.type !== 'print') return false;
      if (p.sku === 'PM-METAL') return false;
      
      const matchesPattern = legacyPatterns.some(pattern => 
        p.sku.includes(pattern) || (p.name && p.name.includes(pattern))
      );
      
      return matchesPattern;
    });

    const archivedSkus = [];
    for (const product of legacyProducts) {
      const newDesc = product.description 
        ? `${product.description} [ARCHIVED legacy size product — replaced by PrintVariant]`
        : '[ARCHIVED legacy size product — replaced by PrintVariant]';
      
      await base44.asServiceRole.entities.Product.update(product.id, {
        active: false,
        show_in_shop: false,
        purchase_flow: 'CUSTOMIZER',
        description: newDesc
      });
      
      archivedSkus.push(product.sku);
    }

    // Ensure PM-METAL is active
    const pmMetal = allProducts.find(p => p.sku === 'PM-METAL');
    if (pmMetal) {
      await base44.asServiceRole.entities.Product.update(pmMetal.id, {
        active: true,
        show_in_shop: true
      });
    }

    return Response.json({
      success: true,
      archived_count: archivedSkus.length,
      archived_skus: archivedSkus,
      kept: 'PM-METAL'
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});