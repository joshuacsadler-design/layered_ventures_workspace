import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const formData = await req.formData();
    const file = formData.get('file');
    const orderItemId = formData.get('orderItemId');
    const sourceFileId = formData.get('sourceFileId');

    if (!file || !orderItemId) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Get order item
    const items = await base44.asServiceRole.entities.OrderItem.filter({ id: orderItemId });
    if (items.length === 0) {
      return Response.json({ error: 'Order item not found' }, { status: 404 });
    }
    const item = items[0];

    // Enforce: item must be APPROVED and have selected proof
    if (item.status !== 'APPROVED') {
      return Response.json({ error: 'Item must be approved before uploading print-ready file' }, { status: 400 });
    }

    const proofs = await base44.asServiceRole.entities.Proof.filter({ order_item_id: orderItemId, is_selected: true });
    if (proofs.length === 0) {
      return Response.json({ error: 'Item must have a selected proof before uploading print-ready file' }, { status: 400 });
    }

    // Check if PRINT_READY already exists (prevent overwrite)
    const existingPrintReady = await base44.asServiceRole.entities.File.filter({ 
      order_item_id: orderItemId, 
      kind: 'PRINT_READY' 
    });
    if (existingPrintReady.length > 0) {
      return Response.json({ error: 'Print-ready file already exists. Cannot overwrite.' }, { status: 400 });
    }

    // Upload the PRINT_READY file
    const { file_url } = await base44.integrations.Core.UploadFile({ file });

    // Create File record
    const printReadyFile = await base44.asServiceRole.entities.File.create({
      order_item_id: orderItemId,
      kind: 'PRINT_READY',
      file_url: file_url,
      filename: file.name,
      source_file_id: sourceFileId || null,
      is_delivered_to_client: false,
      metadata: { uploaded_by: user.id },
    });

    // Log audit
    await base44.functions.invoke('logAudit', {
      action: 'PRINT_READY_UPLOADED',
      entity_type: 'File',
      entity_id: printReadyFile.id,
      details: { order_item_id: orderItemId, filename: file.name },
    });

    return Response.json({ 
      success: true, 
      file_id: printReadyFile.id,
      file_url: file_url,
    });
  } catch (error) {
    console.error('Error uploading PRINT_READY:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});