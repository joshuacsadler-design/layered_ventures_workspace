import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { product_id, size, tier, price, active = true } = await req.json();

    if (!product_id || !tier || price === undefined) {
      return Response.json({ error: 'product_id, tier, and price are required' }, { status: 400 });
    }

    const product = await base44.asServiceRole.entities.Product.get(product_id);
    if (!product) {
      return Response.json({ error: 'Product not found' }, { status: 404 });
    }

    const sizeValue = size || 'na';
    const variant_key = `${sizeValue}-${tier}`;

    const existing = await base44.asServiceRole.entities.ProductPrice.filter({
      product_id,
      variant_key,
    });

    let variant;
    if (existing.length > 0) {
      variant = existing[0];
      await base44.asServiceRole.entities.ProductPrice.update(variant.id, {
        price,
        active,
      });
      variant = { ...variant, price, active };
    } else {
      const sizeCode = size ? size.toUpperCase().replace('x', 'X') : 'NA';
      const tierCode = tier.toUpperCase();
      const variantSku = `${product.sku}-${sizeCode}-${tierCode}`;

      variant = await base44.asServiceRole.entities.ProductPrice.create({
        product_id,
        variant_key,
        sku: variantSku,
        size: size || null,
        tier,
        price,
        active,
      });
    }

    return Response.json({
      ok: true,
      variant: {
        id: variant.id,
        variant_key: variant.variant_key,
        sku: variant.sku || '',
        size: variant.size,
        tier: variant.tier,
        price: variant.price,
        active: variant.active,
      },
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});