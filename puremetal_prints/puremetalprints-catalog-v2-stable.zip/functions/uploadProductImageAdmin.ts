import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== "admin") return Response.json({ error: "Forbidden" }, { status: 403 });

    const body = await req.json();
    const { product_id, file_id } = body || {};
    if (!product_id || !file_id) return Response.json({ error: "product_id and file_id required" }, { status: 400 });

    const updated = await base44.asServiceRole.entities.Product.update(product_id, { image_file_id: file_id });
    return Response.json({ ok: true, product: updated });
  } catch (e) {
    return Response.json({ error: e?.message ?? "Unknown error", stack: e?.stack }, { status: 500 });
  }
});