import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { proofId } = await req.json();
    if (!proofId) {
      return Response.json({ error: 'proofId required' }, { status: 400 });
    }

    // Get proof
    const proofs = await base44.asServiceRole.entities.Proof.filter({ id: proofId });
    if (proofs.length === 0) {
      return Response.json({ error: 'Proof not found' }, { status: 404 });
    }

    const proof = proofs[0];

    // Get order item to find order
    const items = await base44.asServiceRole.entities.OrderItem.filter({ id: proof.order_item_id });
    if (items.length === 0) {
      return Response.json({ error: 'Order item not found' }, { status: 404 });
    }

    const orderItem = items[0];

    // Get order
    const orders = await base44.asServiceRole.entities.Order.filter({ id: orderItem.order_id });
    if (orders.length === 0) {
      return Response.json({ error: 'Order not found' }, { status: 404 });
    }
    const order = orders[0];

    // Check if order was already APPROVED - if so, reset to PROOF_DELIVERED
    const wasApproved = order.status === 'APPROVED';
    let notificationType = 'PROOF_DELIVERED';

    if (wasApproved) {
      // Reset order and all items to PROOF_DELIVERED
      await base44.asServiceRole.entities.Order.update(orderItem.order_id, { status: 'PROOF_DELIVERED' });
      
      // Reset all items to PROOF_DELIVERED and clear selected proofs
      const allItems = await base44.asServiceRole.entities.OrderItem.filter({ order_id: orderItem.order_id });
      for (const item of allItems) {
        await base44.asServiceRole.entities.OrderItem.update(item.id, { status: 'PROOF_DELIVERED' });
        
        // Clear selected proofs for this item
        const itemProofs = await base44.asServiceRole.entities.Proof.filter({ order_item_id: item.id, is_selected: true });
        for (const p of itemProofs) {
          await base44.asServiceRole.entities.Proof.update(p.id, { is_selected: false });
        }
      }
      
      notificationType = 'PROOF_OPTION_ADDED';
    } else {
      // Normal delivery flow
      await base44.asServiceRole.entities.Order.update(orderItem.order_id, { status: 'PROOF_DELIVERED' });
      await base44.asServiceRole.entities.OrderItem.update(orderItem.id, { status: 'PROOF_DELIVERED' });
    }

    // Mark proof as delivered
    await base44.asServiceRole.entities.Proof.update(proofId, {
      is_delivered: true,
      delivered_at: new Date().toISOString(),
    });

    // Update file as delivered to client
    await base44.asServiceRole.entities.File.update(proof.file_id, {
      is_delivered_to_client: true,
    });

    // Send notification to client
    const clients = await base44.asServiceRole.entities.Client.filter({ id: order.client_id });
    if (clients.length > 0) {
      const client = clients[0];
      await base44.functions.invoke('sendNotification', {
        recipientEmail: client.email,
        recipientName: client.full_name,
        notificationType: notificationType,
        data: { orderNumber: order.order_number },
      });
    }

    // Audit log
    await base44.functions.invoke('logAudit', {
      action: wasApproved ? 'PROOF_OPTION_ADDED_RESET_APPROVAL' : 'PROOF_DELIVERED',
      entity_type: 'Proof',
      entity_id: proofId,
      user_id: user.id,
      after_state: { is_delivered: true, reset_approval: wasApproved },
      notes: wasApproved ? 'Admin delivered new proof - reset approval and selections' : 'Admin delivered proof to client',
    });

    return Response.json({ success: true });
  } catch (error) {
    console.error('Deliver proof error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});