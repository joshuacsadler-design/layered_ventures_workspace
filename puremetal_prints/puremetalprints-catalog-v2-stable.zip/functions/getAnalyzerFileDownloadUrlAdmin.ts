import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { file_id } = await req.json();
    
    if (!file_id) {
      return Response.json({ error: 'file_id required' }, { status: 400 });
    }

    // Use CreateFileSignedUrl integration (15 min expiry)
    const resp = await base44.integrations.Core.CreateFileSignedUrl({
      file_uri: file_id,
      expires_in: 900
    });

    return Response.json({ ok: true, url: resp.signed_url });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});