import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { requestId, approved, adminResponse } = await req.json();
    if (!requestId || typeof approved !== 'boolean') {
      return Response.json({ error: 'requestId and approved required' }, { status: 400 });
    }

    // Get cancellation request
    const requests = await base44.asServiceRole.entities.CancellationRequest.filter({ id: requestId });
    if (requests.length === 0) {
      return Response.json({ error: 'Request not found' }, { status: 404 });
    }

    const request = requests[0];

    // Update request
    await base44.asServiceRole.entities.CancellationRequest.update(requestId, {
      status: approved ? 'APPROVED' : 'DENIED',
      admin_response: adminResponse || null,
      responded_at: new Date().toISOString(),
    });

    const order = (await base44.asServiceRole.entities.Order.filter({ id: request.order_id }))[0];

    if (approved) {
      // Apply prep fee if applicable
      if (request.prep_fee_applies) {
        await base44.asServiceRole.entities.Order.update(request.order_id, {
          status: 'CANCELLED',
          prep_fee_charged: true,
          subtotal: 15,
          total: 15,
        });
      } else {
        await base44.asServiceRole.entities.Order.update(request.order_id, {
          status: 'CANCELLED',
        });
      }
    } else {
      // Return to previous state (NEEDS_REVIEW is safe default)
      await base44.asServiceRole.entities.Order.update(request.order_id, {
        status: 'NEEDS_REVIEW',
      });
    }

    // Audit log
    await base44.asServiceRole.entities.AuditLog.create({
      entity_type: 'CancellationRequest',
      entity_id: requestId,
      action: 'cancellation_response',
      user_id: user.id,
      after_state: { approved, admin_response: adminResponse },
      notes: `Admin ${approved ? 'approved' : 'denied'} cancellation request`,
    });

    // Notify client
    const client = (await base44.asServiceRole.entities.Client.filter({ id: order.client_id }))[0];
    if (client) {
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: client.email,
        subject: `Cancellation Request ${approved ? 'Approved' : 'Denied'} - Order ${order.order_number}`,
        body: `Hello ${client.full_name},

Your cancellation request for order ${order.order_number} has been ${approved ? 'approved' : 'denied'}.

${adminResponse ? `Admin note: ${adminResponse}` : ''}

${approved && request.prep_fee_applies ? 'A $15 prep fee has been applied to your order total.' : ''}

Thank you,
PureMetal Prints`,
      });
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error('Respond to cancellation error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});